% dynamic tests

ins = 20:1:900;

c = 1;

a = 200;
b = 50;

rr = c *( (a+ins) ./ (b+ins) );

figure(59)
plot(ins, rr)