clear all
close all

dat = load('BC003_pre_400it_ADAPT_version4.mat');
% dat = load('BC003_pre_400it_ADAPT_version4.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

figure()
yyaxis left
plot(result(1).idt, result(1).idd(:,2))
hold on
errorbar(data.ref.glucose_TTR.src.time,  data.ref.glucose_TTR.src.val, data.ref.glucose_TTR.src.std, '.', 'MarkerSize', 15)
yyaxis right
plot(result(1).idt, user_input.options.runADAPT.weight(:,2))