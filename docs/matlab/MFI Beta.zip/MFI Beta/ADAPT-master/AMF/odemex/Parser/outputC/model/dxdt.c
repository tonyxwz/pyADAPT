#include "../dxdt.h"



int rhs( realtype t, N_Vector y, N_Vector ydot, void *f_data ) {

	struct mData *data = ( struct mData * ) f_data;

	realtype BW , FFA , FFA_prod_Id , FFA_prod_nId , FFA_upt_Id , FFAb , Gb , IS , I_deg , I_inf , I_prod , Ib , MM_glucose , TTR_fix , TTR_var , V_F , V_G , V_I , V_Y , bolus_total , dxdt , glu1 , glu2 , glu3 , glu_RA , glu_RD , glu_inf_tracee , glu_inf_tracer , glu_prod_nId , glu_upt_Id , glu_upt_nId , glucose , glucose_BOLUS , glucose_FIX , glucose_TTR , glucose_VAR , glucose_tracee , glucose_tracer , gly1 , gly2 , gly_RA , gly_RD , gly_inf_tracee , gly_inf_tracer , gly_prod_Id , gly_prod_nId , gly_upt_nId , glycerol , glycerol_BOLUS , glycerol_FIX , glycerol_TTR , glycerol_tracee , glycerol_tracer , ins1 , insulin , insulinAct , insulinAct2 , k1 , k2 , k3 , k4 , p0 , p10 , p12 , p13 , p14 , p15 , p2 , p4 , p8 , v_f , v_g , v_i , v_y ;

	realtype *stateVars;
	realtype *ydots;

	stateVars = NV_DATA_S(y);
	ydots = NV_DATA_S(ydot);

	
	glu1 =interpolate( &data->u[35], &data->u[0],35,t,1);
	glu2 =interpolate( &data->u[74], &data->u[70],4,t,1);
	glu3 =interpolate( &data->u[83], &data->u[78],5,t,1);
	gly1 =interpolate( &data->u[92], &data->u[88],4,t,1);
	gly2 =interpolate( &data->u[101], &data->u[96],5,t,1);
	ins1 =interpolate( &data->u[113], &data->u[106],7,t,1);
	
	Gb =4.375;
	Ib =57.3333;
	MM_glucose =180.182;
	TTR_fix =1;
	TTR_var =0.0087;
	BW =121;
	FFAb =756.5043;
	v_g =0.15;
	v_i =0.1;
	v_y =0.34;
	v_f =0.1;
	
	glucose_tracer =stateVars[0];
	glucose_tracee =stateVars[1];
	insulin =stateVars[2];
	insulinAct =stateVars[3];
	insulinAct2 =stateVars[4];
	FFA =stateVars[5];
	glycerol_tracer =stateVars[6];
	glycerol_tracee =stateVars[7];
	bolus_total =stateVars[8];
	
	p0 =data->p[0];
	p2 =data->p[1];
	p4 =data->p[2];
	p8 =data->p[3];
	p10 =data->p[4];
	p12 =data->p[5];
	p13 =data->p[6];
	p14 =data->p[7];
	p15 =data->p[8];
	k1 =data->p[9];
	k2 =data->p[10];
	k3 =data->p[11];
	k4 =data->p[12];
	
	V_G =v_g*BW;
	V_I =v_i*BW;
	V_Y =v_y*BW;
	V_F =v_f*BW;
	glucose_VAR =glu1;
	glucose_FIX =glu2;
	glucose_BOLUS =glu3;
	glycerol_FIX =gly1;
	glycerol_BOLUS =gly2;
	glucose_TTR =glucose_tracer     / (glucose_tracer  +glucose_tracee);
	glycerol_TTR =glycerol_tracer    / (glycerol_tracer +glycerol_tracee);
	glucose =glucose_tracee +glucose_tracer;
	glycerol =glycerol_tracee +glycerol_tracer;
	glu_prod_nId =p0;
	glu_upt_Id =p2*insulinAct*glucose;
	glu_upt_nId =k1*glucose;
	glu_inf_tracer =BW/((MM_glucose+2)*V_G)*(glu1*(TTR_var)+glu2*(TTR_fix)+glu3*(TTR_fix));
	glu_inf_tracee =BW/(MM_glucose*V_G)*(glu1*(1-TTR_var)+glu2*(1-TTR_fix)+glu3*(1-TTR_fix));
	FFA_prod_nId =p4;
	FFA_prod_Id =3 *p8/(k3+insulinAct2);
	FFA_upt_Id =k2*FFA*insulinAct2;
	gly_prod_nId =k4;
	gly_prod_Id =p8/(k3+insulinAct2);
	gly_upt_nId =p10*glycerol;
	gly_inf_tracer =BW/V_Y * (gly1*TTR_fix +gly2*TTR_fix);
	gly_inf_tracee =BW/V_Y * (gly1*(1-TTR_fix) +gly2*(1-TTR_fix));
	I_prod =p12;
	I_inf =1/V_I *ins1;
	I_deg =p13*insulin;
	glu_RA =glu_prod_nId;
	glu_RD =glu_upt_Id +glu_upt_nId;
	gly_RA =gly_prod_nId +gly_prod_Id;
	gly_RD =gly_upt_nId;
	IS =glu_RD /insulin;
	
	ydots[0] = (-glu_upt_Id -glu_upt_nId)*glucose_TTR +glu_inf_tracer;
	ydots[1] = (-glu_upt_Id -glu_upt_nId)*(1-glucose_TTR) +glu_prod_nId +glu_inf_tracee;
	ydots[2] = -I_deg +I_prod +I_inf;
	ydots[3] =p14 *(insulin -insulinAct);
	ydots[4] =p15 *(insulin -insulinAct2);
	ydots[5] =FFA_prod_Id -FFA_upt_Id +FFA_prod_nId;
	ydots[6] = (-gly_upt_nId)*glycerol_TTR +gly_inf_tracer;
	ydots[7] = (-gly_upt_nId)*(1-glycerol_TTR) +gly_prod_Id +gly_prod_nId +gly_inf_tracee;
	ydots[8] =glu3*BW/((MM_glucose+2)*V_G);
	
	


	#ifdef NON_NEGATIVE
		return 0;
	#else
		return 0;
	#endif

};

