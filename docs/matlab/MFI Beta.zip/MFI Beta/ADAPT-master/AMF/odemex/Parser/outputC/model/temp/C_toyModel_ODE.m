function dxdt = C_toyModel_ODE(t,x,p,u,m)


u1 = m.c.u1;
u2 = m.c.u2;

s1 = x(m.s.s1);
s2 = x(m.s.s2);
s3 = x(m.s.s3);
s4 = x(m.s.s4);

k1 = p(m.p.k1);
k2 = p(m.p.k2);
k3 = p(m.p.k3);
k4 = p(m.p.k4);
k5 = p(m.p.k5);

v1 = k1 * u1 * s2;
v2 = k2 * u2 * s3;
v3 = k3 * s1;
v4 = k4 * s1;
v5 = k5 * s4;
ds3dt = v1 - v2;

dxdt(1) = v1 - v3 - v4;
dxdt(2) = -v1 + v2;
dxdt(3) = ds3dt;
dxdt(4) = v4 - v5;

dxdt = dxdt(:);