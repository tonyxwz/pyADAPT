
#include "mex.h"

#define N_DATA 5
#define N_INPUT 1
#define N_PARS 3
#define N_STATES 2
#define N_OBSPARS 2
#define N_ICPARS 1
#define N_OBS 67
#define N_TIME 53
#define SENSDIM 10

void objectiveFn(double *obj, double *s, double *p, double *d, double *u );

