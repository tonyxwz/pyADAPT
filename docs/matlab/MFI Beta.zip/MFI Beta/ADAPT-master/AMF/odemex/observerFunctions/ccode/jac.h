#define CJAC

void jacobian(double *obj, double *s, double *p, double *d, double *u, double *S );

