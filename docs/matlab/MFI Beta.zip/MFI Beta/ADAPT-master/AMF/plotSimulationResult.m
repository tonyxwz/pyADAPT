clear all

dat = load('BC003_pre_normal_simulation.mat');

BC003_pre_result = dat.result_list{2};
BC003_pre_model = dat.result_list{2}.model;
BC003_pre_data = dat.result_list{2}.data;
BC003_pre_link = dat.result_list{2}.link;
BC003_pre_user_input = dat.result_list{2}.user_input;

dat = load('BC003_post_normal_simulation.mat');

BC003_post_result = dat.result_list{2};
BC003_post_model = dat.result_list{2}.model;
BC003_post_data = dat.result_list{2}.data;
BC003_post_link = dat.result_list{2}.link;
BC003_post_user_input = dat.result_list{2}.user_input;

dat = load('BC004_pre_normal_simulation.mat');

BC004_pre_result = dat.result_list{2};
BC004_pre_model = dat.result_list{2}.model;
BC004_pre_data = dat.result_list{2}.data;
BC004_pre_link = dat.result_list{2}.link;
BC004_pre_user_input = dat.result_list{2}.user_input;

dat = load('BC004_post_normal_simulation.mat');

BC004_post_result = dat.result_list{2};
BC004_post_model = dat.result_list{2}.model;
BC004_post_data = dat.result_list{2}.data;
BC004_post_link = dat.result_list{2}.link;
BC004_post_user_input = dat.result_list{2}.user_input;

figure(1)
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% BC003 pre and post INSULIN
subplot(2,2,1) 
hold on

plot(BC003_pre_result.time, BC003_pre_result.x(:, BC003_pre_link.oxdi(1)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.oxdi(1));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.oxdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.states(BC003_pre_link.oxmi(1)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.x(:, BC003_post_link.oxdi(1)))

x1 = BC003_post_data.dd(:, BC003_post_link.oxdi(1));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.oxdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.states(BC003_post_link.oxmi(1)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northwest')

% BC004 pre and post INSULIN
subplot(2,2,2)
hold on

plot(BC004_pre_result.time, BC004_pre_result.x(:, BC004_pre_link.oxdi(1)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.oxdi(1));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.oxdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.states(BC004_pre_link.oxmi(1)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.x(:, BC004_post_link.oxdi(1)))

x1 = BC004_post_data.dd(:, BC004_post_link.oxdi(1));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.oxdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.states(BC004_post_link.oxmi(1)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northwest')
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% BC003 pre and post FFA
subplot(2,2,3)
hold on

plot(BC003_pre_result.time, BC003_pre_result.x(:, BC003_pre_link.oxmi(2)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.oxdi(2));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.oxdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.states(BC003_pre_link.oxmi(2)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.x(:, BC003_post_link.oxmi(2)))

x1 = BC003_post_data.dd(:, BC003_post_link.oxdi(2));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.oxdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.states(BC003_post_link.oxmi(2)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% BC004 pre and post FFA
subplot(2,2,4)
hold on

plot(BC004_pre_result.time, BC004_pre_result.x(:, BC004_pre_link.oxmi(2)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.oxdi(2));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.oxdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.states(BC004_pre_link.oxmi(2)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.x(:, BC004_post_link.oxmi(2)))

x1 = BC004_post_data.dd(:, BC004_post_link.oxdi(2));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.oxdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.states(BC004_post_link.oxmi(2)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

figure(2)
% BC003 pre and post glucose TTR
subplot(2,2,1)
hold on

plot(BC003_pre_result.time, BC003_pre_result.v(:, BC003_pre_link.ofmi(1)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.ofdi(1));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.ofdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.reactions(BC003_pre_link.ofmi(1)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.v(:, BC003_post_link.ofmi(1)))

x1 = BC003_post_data.dd(:, BC003_post_link.ofdi(1));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.ofdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.reactions(BC003_post_link.ofmi(1)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% BC004 pre and post glucose TTR
subplot(2,2,2)
hold on

plot(BC004_pre_result.time, BC004_pre_result.v(:, BC004_pre_link.ofmi(1)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.ofdi(1));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.ofdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.reactions(BC004_pre_link.ofmi(1)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.v(:, BC004_post_link.ofmi(1)))

x1 = BC004_post_data.dd(:, BC004_post_link.ofdi(1));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.ofdi(1));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.reactions(BC004_post_link.ofmi(1)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% BC003 pre and post glycerol TTR
subplot(2,2,3)
hold on

plot(BC003_pre_result.time, BC003_pre_result.v(:, BC003_pre_link.ofmi(2)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.ofdi(2));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.ofdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.reactions(BC003_pre_link.ofmi(2)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.v(:, BC003_post_link.ofmi(2)))

x1 = BC003_post_data.dd(:, BC003_post_link.ofdi(2));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.ofdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.reactions(BC003_post_link.ofmi(2)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% BC004 pre and post glycerol TTR
subplot(2,2,4)
hold on

plot(BC004_pre_result.time, BC004_pre_result.v(:, BC004_pre_link.ofmi(2)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.ofdi(2));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.ofdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.reactions(BC004_pre_link.ofmi(2)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.v(:, BC004_post_link.ofmi(2)))

x1 = BC004_post_data.dd(:, BC004_post_link.ofdi(2));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.ofdi(2));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.reactions(BC004_post_link.ofmi(2)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

figure(3)
% BC003 pre and post glucose
subplot(2,2,1)
hold on

plot(BC003_pre_result.time, BC003_pre_result.v(:, BC003_pre_link.ofmi(3)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.ofdi(3));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.ofdi(3));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.reactions(BC003_pre_link.ofmi(3)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.v(:, BC003_post_link.ofmi(3)))

x1 = BC003_post_data.dd(:, BC003_post_link.ofdi(3));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.ofdi(3));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.reactions(BC003_post_link.ofmi(3)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% BC004 pre and post glucose
subplot(2,2,2)
hold on

plot(BC004_pre_result.time, BC004_pre_result.v(:, BC004_pre_link.ofmi(3)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.ofdi(3));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.ofdi(3));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.reactions(BC004_pre_link.ofmi(3)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.v(:, BC004_post_link.ofmi(3)))

x1 = BC004_post_data.dd(:, BC004_post_link.ofdi(3));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.ofdi(3));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.reactions(BC004_post_link.ofmi(3)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------
% ------------------------------------------------------------------------

% BC003 pre and post glycerol
subplot(2,2,3)
hold on

plot(BC003_pre_result.time, BC003_pre_result.v(:, BC003_pre_link.ofmi(4)))

x1 = BC003_pre_data.dd(:, BC003_pre_link.ofdi(4));
x2 = x1(~isnan(x1));
t1 = BC003_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_pre_data.ds(:, BC003_pre_link.ofdi(4));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_pre_model.reactions(BC003_pre_link.ofmi(4)).name)

errorbar(t2,x2,s2,'o')

plot(BC003_post_result.time, BC003_post_result.v(:, BC003_post_link.ofmi(4)))

x1 = BC003_post_data.dd(:, BC003_post_link.ofdi(4));
x2 = x1(~isnan(x1));
t1 = BC003_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC003_post_data.ds(:, BC003_post_link.ofdi(4));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC003_post_model.reactions(BC003_post_link.ofmi(4)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')

% BC004 pre and post glycerol
subplot(2,2,4)
hold on

plot(BC004_pre_result.time, BC004_pre_result.v(:, BC004_pre_link.ofmi(4)))

x1 = BC004_pre_data.dd(:, BC004_pre_link.ofdi(4));
x2 = x1(~isnan(x1));
t1 = BC004_pre_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_pre_data.ds(:, BC004_pre_link.ofdi(4));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_pre_model.reactions(BC004_pre_link.ofmi(4)).name)

errorbar(t2,x2,s2,'o')

plot(BC004_post_result.time, BC004_post_result.v(:, BC004_post_link.ofmi(4)))

x1 = BC004_post_data.dd(:, BC004_post_link.ofdi(4));
x2 = x1(~isnan(x1));
t1 = BC004_post_data.time;
t2 = t1(~isnan(x1));
s1 = BC004_post_data.ds(:, BC004_post_link.ofdi(4));
s2 = s1(~isnan(x1));
s2(isnan(s2)) = 0;
title(BC004_post_model.reactions(BC004_post_link.ofmi(4)).name)

errorbar(t2,x2,s2,'o')

legend('pre-surgery simulation', 'pre-surgery data', 'post-surgery simulation', 'post-surgery data', 'Location', 'northeast')