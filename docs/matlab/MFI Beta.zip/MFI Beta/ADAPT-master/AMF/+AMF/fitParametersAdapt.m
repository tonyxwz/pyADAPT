function [] = fitParametersAdapt(model, user_input, data, link, result)

import AMF.*

% result = ModelResult();

x0 = [model.states.init];

p0 = result.p0;
p0 = p0(user_input.pidx);

lb = [model.parameters.lb];
lb = lb(user_input.pidx);

ub = [model.parameters.ub];
ub = ub(user_input.pidx);

% t = data.idt;

% t = getTime(user_input, ts); 

t = getFitTime(data);

[pest, sse, resid] = lsqnonlin(@objectiveFunction,(p0), lb, ub, user_input.options.optimset, model, data, link, x0, t, user_input); % Standard parameter estimation, but why do you need a t with 3 values and a separate ts? SOLVED, look at costfunction.

% result.p(ts,:) = result.pcurr;
% result.x(ts,:) = result.xcurr;
% result.v(ts,:) = result.vcurr;
% result.sse(ts) = sse;

% if ~isempty(model.inputs)
%     uvec = model.result.uvec;
%     uvec(model.result.uidx) = model.result.pcurr(model.result.upidx); % Should I change these as well?
%     
%     model.result.u(ts,:) = computeInputs(model, t(end), uvec);
% end

% result.sim_type = 'fitParameters';
% result.sim_date = datestr(datetime);

% result.x0 = x0;
result.p0(user_input.pidx) = pest;

% result.model = model;
% result.user_input = user_input;
% result.data = data;
% result.link = link;
% 
% 
% result.pest = pest;
% result.sse = sse;
% result.resid = resid;
% 
% result.model_name = model.name;
% result.data_name = data.name;

function error = objectiveFunction(pest, model, data, link, x0, t, user_input)

p = [model.parameters.init];
p(user_input.pidx) = pest;    

uvec = model.uvec;
% uvec = result.uvec; %%% MAKE THIS WORK LATER
% uvec(result.uidx) = result.pcurr(result.upidx);

% uvec = []; %%% DELETE LATER

x = computeStates(model, t, x0, p, uvec, user_input); % I think I get why t needs to be a vector. In computeStates the vector is used for an ode solver. By giving an array instead of bounds, I believe the solver will only calculate on the 3 points instead of on a lot on the interval. 
v = computeReactions(model, t, x, p, uvec);

% result.x(ts, :) = x(end,:);
% result.v(ts, :) = v;

% xcurr = result.x(ts, :);
% vcurr = result.v(ts, :); 

% ox = xcurr(find([data.fields.obs]));
% of = vcurr(find([model.reactions.obs]));

ox = x(:, logical(link.oxi));
of = v(:, logical(link.ofi));

sim = [ox of];

% THIS MAKES NO SENSE!? If reactions ARE observable, this would create a
% list with possible repeating points... Would maybe work if in the data
% there was also reaction data as well as state data, and instead of
% [data.oxdi data.ofdi] it would be something like [data.oxdi
% data.ofdi+numberOfStates]

% odi = [data.oxdi data.ofdi];
% 
% dat = result.idd(ts, odi);
% sd = result.ids(ts, odi);

% odi = [find([data.fields.obs])];

odi = [link.oxdi link.ofdi];

% dat = data.idd(:, odi); % Maybe replace with data.idd(ts, odi) 
% sd = data.ids(:, odi);

dat = data.dd(:, odi);
sd = data.ds(:, odi);


error = (sim(:) - dat(:)) ./ sd(:);

% error = [error; zeros(length(p), 1)]; % Why is that? What do the extra zeros do? Doesn't seem to be used anywhere. Answer: This is to make sure that there are at least as much datapoints as there are parameters, so the problem isn't underdefined.


% reg = AMF.regFun(model, t, ts, result, user_input); % What is this? regFun? I know what it does, but why is it added to the cost function? A: The reg function
% % makes sure that the steps taken aren't to big and that fitted parameters
% % actually form trajectories instead of just being perfectly fitted to the
% % data. The reg function returns a value that represents the difference
% % between the currently estimated parameter value and the previous one. If
% % a parameter can be estimated that would make the data fit perfectly but
% % it is very different form the previous parameter value, it has las chance
% % of being choosen by the algorithm as the correct parameter. lab1 (lambda)
% % decides how much this is taken into account. 
% error = [error; reg(:)]; 

if ~isempty(model.functions.reg) % I believe there is not a single case where the reg functions isn't empty, so this is trivial
    error = [error; model.functions.reg(model, model.iStruct, model.dStruct)];
end

mode = 2; % Decide here if you want to change inf's and NaN's with 0's, or delete them from the array

if mode == 1
    error(isnan(error)) = 0; % Quick Note: Funny how here it is done correctly, while in another costfunction the NaN's and Inf's are deleted % Maybe it was done correctly and I'm just an idiot
    error(isinf(error)) = 0;% Initialize
elseif mode == 2
    error = error(~isnan(error));
    error = error(~isinf(error));
end

if length(error) < length(p)
    error = [error; zeros(length(p) - length(error), 1)];
end

end

end