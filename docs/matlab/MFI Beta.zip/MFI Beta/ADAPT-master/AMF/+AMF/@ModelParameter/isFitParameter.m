function filter = isFitParameter(compArray)

filter = logical([compArray.fit]);