classdef ModelParameter < AMF.ModelComponent
    properties
%         fit
        lb
        ub
%         traj
    end
    methods
        function this = ModelParameter(index, name, init, bnd, meta)%fit, expr, bnd, meta)%, traj)
            this = this@AMF.ModelComponent(index, name, meta);

            this.init = init;
            this.val = init;
%             if isa(expr, 'double')
%                 this.init = expr;
%             end
            
%             this.fit = fit;
            
            if isempty(bnd)
                this.lb = 0;
                this.ub = inf;
            else
                this.lb = bnd(1);
                this.ub = bnd(2);
            end
            % Below can only be done when model file is adjusted. For now
            % we do it simple, but in the end we want to adjust this
%             if isempty(traj) %  Added so it can be dictated which parameters will be variable over time
%                 this.traj = 0;
%             end
%             this.traj = 0;
        end
    end
end