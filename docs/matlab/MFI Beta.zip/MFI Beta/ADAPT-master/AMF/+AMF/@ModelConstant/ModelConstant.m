classdef ModelConstant < AMF.ModelComponent
    properties
        dName
    end
    methods
        function this = ModelConstant(index, name, val, dName, meta)
            this = this@AMF.ModelComponent(index, name, meta);
            
            this.val = val;
            this.dName = dName;
        end
    end
end