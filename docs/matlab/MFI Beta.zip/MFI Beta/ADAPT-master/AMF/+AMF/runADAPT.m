function result = runADAPT(model, user_input, data, link)

import AMF.*

t = data.idt;

seed = user_input.options.runADAPT.seed;
numIter = user_input.options.runADAPT.numIter;

% Could potentially be used to changed randomization when randomization
% causes convergence failures. Use 'seed' when preferring optimal
% reproducibility 

% rng('default'); 
rng(seed);
% rng('shuffle');

result_list = [];

% No GUI functionality for optimset, adjust here if wanted instead:
user_input.options.optimset  = optimset('MaxIter',1e3,'Display','off','MaxFunEvals',350,'TolX',1e-8,'TolFun',1e-8);

start_adapt = tic;

for it = 1:numIter
    
    success = 0;
    
    while ~success
%         try % Don't use "try / catch" when trouble shooting
            start_iteration = tic;
            
            % pre-allocate data for result object
            result = ModelResult();
            
            result.sim_type = 'ADAPT';
            result.sim_date = datestr(datetime);
            
            result.model = model;
            result.data = data;
            result.link = link;
            result.user_input = user_input;
            
            result.p = zeros(length(t), length(model.parameters));
            result.x = zeros(length(t), length(model.states));
            result.u = zeros(length(t), length(model.inputs));
            result.v = zeros(length(t), length(model.reactions));
            result.sse = zeros(length(t), 1);
            result.time = t;
            
            result.p0 = [model.parameters.init];
            
            
            model2 = model; % used for object copying
            
            if user_input.options.randPars 
                randomizeParameters(model2, result, user_input);
            end
            
            if user_input.options.randData
                randomizeData(model2, data, result, user_input);
            end
            
            % New addition: input of model simulation instead of interpolated data.
            
            simAsInterpList = user_input.options.runADAPT.simAsInterpList; 
            
            if ~isempty(simAsInterpList)
                
                % object copying
                save('tempData.mat', 'data');
                data2 = load('tempData.mat');
                data2 = data2.data;
                delete('tempData.mat');
                
                [data2.dd, data2.ds] = getFitData(data2); 
                
                % fit parameters for current data sampling
                temp_result = fitParameters(model2, user_input, data2, link);
                
                % object copying
                save('tempModel.mat', 'model2');
                model3 = load('tempModel.mat');
                model3 = model3.model2;
                delete('tempModel.mat');
                
                % set initial parameters
                for pNo = 1:length(temp_result.pest)
                    model3.parameters(pNo).init = temp_result.pest(pNo);
                end

                model3.functions = model2.functions;

                data2.time = data.idt;
                
                % sloppy programming, needed to maintain functionality
                % without altering simulation option settings
                temp_variable = user_input.options.simulate.usePrevP; % save setting
                user_input.options.simulate.usePrevP = 0; % set setting
                
                temp_result2 = simulate(model3, user_input, link, data2); % calculates "simulation as interpolation" data
                 
                % sloppy programming, needed to maintain functionality
                % without altering simulation option settings              
                user_input.options.simulate.usePrevP = temp_variable; % return saved setting
            
                % overwrites interpolation data
                for obs_name = simAsInterpList
                    if isa(model.ref.(obs_name{1}), 'AMF.ModelState')
                        result.idd(:, data.ref.(obs_name{1}).index) = temp_result2.x(:, model.ref.(obs_name{1}).index);
                    elseif isa(model.ref.(obs_name{1}), 'AMF.ModelReaction')
                        result.idd(:, data.ref.(obs_name{1}).index) = temp_result2.v(:, model.ref.(obs_name{1}).index);
                    end
                end
            end
            
            % ---- END ----
            
            % only used when using alternative intitial fitting (no SS
            % time)
            if user_input.options.runADAPT.useAltInitFit
                fitParametersAdapt(model2, user_input, data, link, result) 
            end
            
            resultInitVals      = result.idd(1,:);
            result.x0           = [model2.states.init]; %result.x(1,:);
            result.x0(logical(link.oxi)) = resultInitVals(link.oxdi);
            
            % Run parameter estimation
            % Multi Step ADAPT is discouraged, not working optimally
            if isempty(user_input.options.runADAPT.traj_step2) 
                for ts = 1:length(t)
                    fitTimeStepAdapt(model2, ts, data, link, result, user_input);
                end
            else
                for ts = 1:length(t)
                    fitTimeStepAdaptMultiStep(model2, ts, data, link, result, user_input);
                end
            end
                
 
            elt = toc(start_iteration);
            
            fprintf('Computed trajectory %d [%d] - %.2fs\n', it, 1, elt); %max(model2.result.sse), elt);
            
            % save results
            result_list = [result_list result];
            
            success = 1;
    end
end

elt_total = toc(start_adapt);
fprintf(['Total elapsed time for running ADAPT is ' num2str(elt_total) ' seconds'])

result = result_list;

