function this = loadGroup(this, groupName)

this.activeGroup = groupName;

parseFields(this);
parseFunctions(this);