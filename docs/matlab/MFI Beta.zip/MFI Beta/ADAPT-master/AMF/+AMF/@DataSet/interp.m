function this = interp(this, t, method)

if nargin < 3, method = 'LINEAR'; end % Why would this be here? Either method is 'spline', or method is decided beforehand

interp(this.fields, t, method); % Wait, it calls itself? I guess it calls the interp function from the DataField class, but I don't know why this works like that

parseFunctions(this);

% I think this entire function might not even be used anymore, need to
% check