function this = randomize(this)

randomize(this.fields);

parseFunctions(this);