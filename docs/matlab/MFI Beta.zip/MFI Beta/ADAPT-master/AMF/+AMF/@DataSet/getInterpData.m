function [dd, ds] = getInterpData(this, t, user_input)

% if nargin < 3
%     user_input = 'spline';
% end

[dd, ds] = interp(this.fields, t, user_input);

if ~isempty(this.functions)
    [dd, ds] = this.funcs.func(dd, ds, getDataStruct(this));
end