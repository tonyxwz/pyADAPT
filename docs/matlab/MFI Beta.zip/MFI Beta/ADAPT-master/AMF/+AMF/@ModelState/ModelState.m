classdef ModelState < AMF.ModelComponent
    properties
        dName
        
        derivedODE
        compiledODE
%         initExpr
    end
    methods
        function this = ModelState(index, name, init, dName, expr, meta)
            this = this@AMF.ModelComponent(index, name, meta);

            this.expr = expr;
            this.init = init;
            this.dName = dName;
        end
    end
end