function reg = regFun(model, t, ts, result, user_input)

labArray = user_input.options.runADAPT.labArray;
pcurr = result.p(ts, :);
if ts > 1
    pprev = result.p(ts-1, :);
else
    pprev = result.p0;
end
pinit = result.p0;

labPower = user_input.options.runADAPT.labPower;

dt = t(end) - t(1);


if t(end) == 0
    reg = zeros(1, length(pcurr));
else
    reg = ((pcurr - pprev) ./ pinit).^labPower ./ dt .* labArray(ts-1, :);
end