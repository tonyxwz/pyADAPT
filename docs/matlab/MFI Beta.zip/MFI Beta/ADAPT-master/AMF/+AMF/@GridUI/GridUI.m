classdef GridUI < handle
    properties
        id
        color
        
        controls
        handles
        dim = [0 0]
        scale = 25
    end
    methods
        function this = GridUI(varargin)
        end
    end
end