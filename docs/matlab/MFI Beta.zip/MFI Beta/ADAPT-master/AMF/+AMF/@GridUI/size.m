function dim = size(this)

dim = this.dim * this.scale;