function [val, chi2] = proflik(model, pName, frac, alpha)

import AMF.*

% [~, sse] = fit(model); % This didn't work for me, changed it to below.
% fit(model) gave an output in the form of a struct, not a series of
% variables. Since we are only interested in the variable sse here, we
% first save the struct, and then assign the field to a variable 'sse'

interm = fit(model);
sse = interm.sse;

% end of changed code

p = model.ref.(pName);
p.fit = 0;
parseParameters(model);

popt = model.fitParameters.init;
% popt = p.curr;

val(1) = popt;
chi2(1) = sse;

ref = chi2pdf(1-alpha, 1);

rat = -inf;
ctr = 2;

% while rat <= ref
%     model2 = model;
%     ctr
%     
%     p.curr = popt * (1+frac*(ctr-1)); 
%     disp(['The current parameter value is ' num2str(p.curr)]);
%     % [~, sse] = fit(model); % same changes here as on line 5
%     model2.fitParameters.init = p.curr;
%     
%     interm = fit(model2);
%     sse = interm.sse;
%     display(['SSE in proflik is ' num2str(sse)]);
%     % end of changed code
%     val = [val p.curr];
%     chi2 = [chi2 sse];
%     
%     rat = 2 * log10(sse / chi2(1)); % ??? Why log10 here, and log below? 
%     ctr = ctr + 1;
%     
%     rat
%     ref
% end
% 
% rat = -inf;
% ctr = 2;
% while rat <= ref
%     model2 = model;
%     ctr
% 
%     p.curr = popt * (1-frac*(ctr-1)); % Note the 1-frac instead of 1+frac as seen above
%     disp(['The current parameter value is ' num2str(p.curr)]); 
%     % [~, sse] = fit(model); % same changes here as on line 5
%     model2.fitParameters.init = p.curr;
%     
%     interm = fit(model2);
%     sse = interm.sse;
%     display(['SSE in proflik is ' num2str(sse)]);
%     % end of changed code
%     val = [val p.curr];
%     chi2 = [chi2 sse];
%     
%     rat = 2 * log(sse / chi2(1)); % ??? Why log here, and log10 above?
%     ctr = ctr + 1;
%     
%     rat
%     ref
% end

while rat <= ref
    p.curr = popt * (1+frac*(ctr-1)); 
    % [~, sse] = fit(model); % same changes here as on line 5
    
    interm = fit(model);
    sse = interm.sse;

    % end of changed code
    val = [val p.curr];
    chi2 = [chi2 sse];
    
    rat = 2 * log10(sse / chi2(1)); % ??? Why log10 here, and log below? 
    ctr = ctr + 1;
end

rat = -inf;
ctr = 2;
while rat <= ref
    p.curr = popt * (1-frac*(ctr-1)); % Note the 1-frac instead of 1+frac as seen above
    % [~, sse] = fit(model); % same changes here as on line 5

    interm = fit(model);
    sse = interm.sse;

    % end of changed code
    val = [val p.curr];
    chi2 = [chi2 sse];
    
    rat = 2 * log(sse / chi2(1)); % ??? Why log here, and log10 above?
    ctr = ctr + 1;
end

p.fit = 1;
parseParameters(model);

[val, idx] = sort(val);
chi2 = chi2(idx);

% display
figure;
plot(val, chi2, 'r');
hold on;
[~, idx] = min(chi2);
plot(val(idx), chi2(idx), 'kx', 'MarkerSize', 10, 'LineWidth', 2);

xlabel(p.name);
ylabel('chi2');