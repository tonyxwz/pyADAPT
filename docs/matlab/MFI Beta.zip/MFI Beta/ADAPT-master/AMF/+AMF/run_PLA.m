function result = run_PLA(model, user_input, data, link)

import AMF.*

result = ModelResult();

i = user_input.options.PLA.pNum;

par = [model.parameters.init]; % Q: why is this only 1 value? A: Because in the model m.file only 1 parameter was set to fit
                               % Q2: Why are the values not really the
                               % initial values? A: ???

% t = [data.data.(data.activeGroup).t]'; % This only works for toy, need to think of a way to get it to work for every model and every datagroup
t = [data.time];

x0 = [model.states.init];
x0(logical(link.oxi)) = data.dd(1, link.oxdi); % This should work! Though link.oxi should already by a logical I think
% x0 = data.dd(1,:); % This only works when all data is observable and there are no non-observable states / reactions in the model

func = @(par)costFunctionPLA(par, model, data, link, t, x0, user_input);

[plPar, plRes] = PLA_2(func, par, i, model, user_input);

figure;
plot(plPar, plRes);
title(['Profile likelihood of parameter ' num2str(user_input.options.PLA.pNum)])
xlabel('Parameter value')
ylabel('Fit residual')

% result = {plPar, plRes};

result.sim_type = 'PLA';
result.sim_date = datestr(datetime);

result.plPar = plPar;
result.plRes = plRes;

result.x0 = x0;

result.model = model;
result.user_input = user_input;
result.data = data;
result.link = link;

result.model_name = model.name;
result.data_name = data.name;

end
