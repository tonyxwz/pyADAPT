function result = run_PSA(model, user_input)

import AMF.*

result = ModelResult();

par = [model.parameters.init]; 

t = [0 1000];

x0 = [model.states.init];

uvec = model.uvec;

x = computeStates(model, t, x0, par, uvec, user_input); % Add calculation of model output with par_opt

M0 = x(end);

fac = 0.1; % set pertubation factor for parameter
step = par * fac;

min_step = 0.01;

step(step < min_step) = min_step;

S_pos = zeros(size(par));
S_neg = zeros(size(par));

M_pos = zeros(size(par));
M_neg = zeros(size(par));

for par_n = 1:length(par)
    
    par_SA_pos = par;
    par_SA_pos(par_n) = par(par_n) + step(par_n); % CHANGED; was "par_opt(par_n) * (1 +/- fac)". Didn't work for parameters which equaled 0.
    
    par_SA_neg = par;
    par_SA_neg(par_n) = par(par_n) - step(par_n);
    
    x_pos = computeStates(model, t, x0, par_SA_pos, uvec, user_input); % Add calculation of model output with par_SA
    M_pos(par_n) = x_pos(end);
    
    x_neg = computeStates(model, t, x0, par_SA_neg, uvec, user_input); % Add calculation of model output with par_SA
    M_neg(par_n) = x_neg(end);
     
    % TO-DO: This can be done out of the loop
    S_pos(par_n) = ( (M_pos(par_n) - M0) / M0 ) / ( (par_SA_pos(par_n) - par(par_n)) / par(par_n) );
    S_neg(par_n) = ( (M_neg(par_n) - M0) / M0 ) / ( (par_SA_neg(par_n) - par(par_n)) / par(par_n) );
end

S = (abs(S_pos) + abs(S_neg)) / 2;

figure;
bar(S);
title('Parameter Sensitivity Analysis')
xlabel('Parameters')
ylabel('Sensitivity Coefficient')
xlim([0 length({model.parameters.name})+1])
xticks(1:length({model.parameters.name}))
xticklabels({model.parameters.name})

result.sim_type = 'PSA';
result.sim_date = datestr(datetime);

result.sens = S;

result.model = model;
result.user_input = user_input;

result.model_name = model.name;

end
