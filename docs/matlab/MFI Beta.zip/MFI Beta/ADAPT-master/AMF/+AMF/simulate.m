function result = simulate(model, user_input, link, data)

import AMF.*

result = ModelResult();

if nargin < 3 
    tSpan = user_input.options.simulate.timeSpan;
    t = tSpan(1):(tSpan(end)-tSpan(1))/user_input.options.numTimeSteps:tSpan(end);
    x0 = [model.states.init];
else
%     t = data.time;
    t = data.idt;
    x0 = [model.states.init];
    x0(link.oxi) = data.dd(1, link.oxdi); % This might not always be what you want... 
end

if ~user_input.options.simulate.usePrevP
    p = [model.parameters.init];
else
    p = user_input.options.simulate.prevP;
end

% t = [t(1) t(end)]; % TESTESTTEST

uvec = model.uvec;

result.x = computeStates(model, t, x0, p, uvec, user_input);
result.v = computeReactions(model, t, result.x, p, uvec);

result.sim_type = 'simulate';
result.sim_date = datestr(datetime);

result.model = model;
result.user_input = user_input;
if nargin > 2
    result.data = data;
    result.link = link;
end


% COMMENTED FOR TEST

result.time = t;

% /CFT


% if nargin <3
%     result.time = t(1):(t(end)-t(1))/length(result.x(:,1)):t(end);
% else
%     result.time = t;
% end

% result.time = t;

result.x0 = x0;
result.p0 = p;

result.model_name = model.name;
if nargin > 3
    result.data_name = data.name;
end
