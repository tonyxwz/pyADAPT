function [plPar, plRes] = PLA_2(func, par, i, model, user_input, maxPar, threshold, lb, ub, Optimoptions, minStep, maxStep, minChange, maxChange, nr)
% PLA Profile Likelihood Analysis calculates profile likelihood along parameter nr. i
% - in increasing direction if maxPar > par, with par the calibrated parameter value
% - in decreasing direction if maxPar < par
%
%Assume prefdenotes a calibrated set of parameter of the model. 
%Beginning from pref(i), sample along the profile likelihood in either  
%increasing or decreasing direction of pref(i), by following procedure:
%a. Take a step pstep in either direction of pref(i);
%b. Re-optimize all pref(j~=i) ;
%Repeat the above steps until
%   1) the threshold (based on chi-squared) is exceeded
%   2) or the maximum number of steps nr is reached
%   3) or the boundary of parameter region is reached
%depending on the computational condition
%pstep is chosen in an adaptive manner, taking large steps if the likelihood
%is flat and small steps if the change of the likelihood is steep.
%
%   [plPar,plRes]=PLA(func,par,i,maxPar,threshold,lb,ub,Optimoptions,
%                       minStep,maxStep,minChange,maxChange,nr)
%
% % INPUT
%   - func      : function handle referring to cost function for model fitting (lsqnonlin) 
%   - par       : calibrated parameters
%   - i         : the i-th parameter for PL calculation
%   - maxPar    : max value of i-th parameter
%   - threshold : threshold - chi square distribution
%   - lb        : lower bounds for parameter estimation (lsqnonlin)
%   - ub        : upper bounds for parameter estimation (lsqnonlin)
%   - Optimoptions : options for optimization
%   - minStep   : minimal step factor
%   - maxStep   : maximal step factor
%   - minChange : minimal change of resnorm
%   - maxChange : maximal change of resnorm
%   - nr        : no. of samples in profile likelihood
%
% % OUTPUT
%   - plPar     : vector of values for i-th parameter 
%   - plRes     : vector of corresponding resnorm values (profile likelihood)

import AMF.*



%
% [plPar,plRes]=PLA(func,par,i) uses default values for inputs:
% maxPar = 10*par(i), threshold = chi2inv(0.5,size(par)),
% lb=[], ub=[], Optimoptions=[], minStep=0.01, maxStep, 
% minChange=0.001, maxChange=0.05, nr=100

%History
%02-Mar-2011 Natal van Riel, TU/e

% set default values
% if nargin < 4, maxPar = 10*par(i);end
% if nargin < 5, threshold = chi2inv(0.5,size(par));end   
% if nargin < 6, lb = zeros(size(par)); end
% % if nargin < 6, lb = []; end
% % if nargin < 7, ub = []; end
% if nargin < 7, ub = inf(size(par)); end
% if nargin < 8, Optimoptions=[]; end
% % if nargin < 9, minStep=0.01; end
% % if nargin < 10, maxStep=0.1; end
% if nargin < 9, minStep = 0.001; end
% if nargin < 10, maxStep = 0.01; end
% if nargin < 11, minChange = 0.001; end
% if nargin < 12, maxChange = 0.05; end
% if nargin < 13, nr = 100; end

if nargin <= 5, maxPar = 10*par(i);end
if nargin <= 6, threshold = chi2inv(0.5,size(par));end   
if nargin <= 7, lb = zeros(size(par)); end
% if nargin < 6, lb = []; end
% if nargin < 7, ub = []; end
if nargin <= 8, ub = inf(size(par)); end
if nargin <= 9, Optimoptions = optimset('MaxIter', 1e3, 'Display', 'off', 'MaxFunEvals', 1e5, 'TolX', 1e-8, 'TolFun', 1e-8); end  %[]; end
% if nargin < 9, minStep=0.01; end
% if nargin < 10, maxStep=0.1; end
if nargin <= 10, minStep = 0.001; end
if nargin <= 11, maxStep = 0.01; end
if nargin <= 12, minChange = 0.001; end
if nargin <= 13, maxChange = 0.05; end
if nargin <= 14, nr = 100; end

disp(' ');
disp(['Profile Likelihood calculation for parameter ' int2str(i)]);
disp(' ');

% Optimoptions = optimoptions('lsqnonlin','Display','iter');
% ub = repmat(400,size(par));
% TEMPORARY
Optimoptions     = optimset('MaxIter',1e3,'Display','iter','MaxFunEvals',350,'TolX',1e-8,'TolFun',1e-8);

% par
[par res_test] = lsqnonlin(func, par, lb, ub, Optimoptions); % OLD TRY% Check if upper and lower bounds are same as in ADAPT simulations
% [par res_test] = lsqnonlin(func, par, lb, ub, Optimoptions) % Re-run to see if starting values make a difference
% -------------------------
% NEW TRY

% ts = 1;
% [par, sse, resid] = fitTimeStep(model, ts)
% [par res_test] = lsqnonlin(func, par, lb, ub, Optimoptions)
% END OF NEW TRY
% -------------------------
% set default values % DOING THIS 2 TIMES, not pretty but works for now. Is
% only to set lb, ub and optimOptions for creation of best fitting
% parameters
if nargin < 4, maxPar = 10*par(i);end
if nargin < 5, threshold = chi2inv(0.5,size(par));end   
if nargin < 6, lb = zeros(size(par)); end
% if nargin < 6, lb = []; end
% if nargin < 7, ub = []; end
if nargin < 7, ub = inf(size(par)); end
if nargin < 8, Optimoptions = optimset('MaxIter', 1e3, 'Display', 'off', 'MaxFunEvals', 1e5, 'TolX', 1e-8, 'TolFun', 1e-8); end % []; end
% if nargin < 9, minStep=0.01; end
% if nargin < 10, maxStep=0.1; end
if nargin < 9, minStep=0.001; end
if nargin < 10, maxStep=0.01; end
if nargin < 11, minChange=0.001; end
if nargin < 12, maxChange=0.05; end
if nargin < 13, nr=100; end

% TEMPORARY
Optimoptions     = optimset('MaxIter',1e3,'Display','off','MaxFunEvals',350,'TolX',1e-8,'TolFun',1e-8);

maxPar = 10 * par(i);
% minPar = par(i) - (maxPar - par(i));
% 
% if minPar < 0
%     minPar = 0;
% end
minPar = 0.1 * par(i);

minChange = minChange * threshold;
maxChange = maxChange * threshold;
% %----Choice 1----------%
% minStep = par(i)*minStep;
% maxStep = par(i)*maxStep;
% %----Choice 2---------%
% minStep = abs(par(i)-maxPar) * minStep;
% maxStep = abs(par(i)-maxPar) * maxStep;
%----Choice 3---------%
minStep = max(par(i)*minStep, 0.01);
maxStep = min(par(i)*maxStep, 100);

step = minStep; % Q: Why start at min-step and not max? Or the average?

% specify the direction: 1 increase -1 decrease
% flag = sign(maxPar - par(i)); % CHANGE THIS SO COMPLETE LIKELIHOOD GETS CHECKEN, NOT JUST ABOVE OR BELOW ESTIMATE
                                % Changed! Not necessary anymore. 

% select parameters to be re-optimized
nPar = [par(1:i-1) par(i+1:end)];
if isempty(lb), lb=[]; else, lb = [lb(1:i-1) lb(i+1:end)]; end
if isempty(ub), ub=[]; else, ub = [ub(1:i-1) ub(i+1:end)]; end

% function handle for optimization
optFun = @(nPar, iPar)feval(func, [nPar(1:i-1) iPar nPar(i:end)]); 
% res = sum(func(par).^2);

k_inc = 1;
count_inc = 1; % Lijkt dubbel op met k
plPar_inc(1) = par(i);
plRes_inc(1) = res_test; % was res
step_inc = step;

[x_start, resnorm_start] = lsqnonlin(@(nPar)optFun(nPar, par(i)), nPar(k_inc,:), lb, ub, Optimoptions);

while plPar_inc(end) <= maxPar && count_inc <= nr 
    % take a step along the parameter 
    tempPar = step_inc + plPar_inc(end);

    [x, resnorm] = lsqnonlin(@(nPar)optFun(nPar, tempPar), nPar(k_inc,:), lb, ub, Optimoptions);
    
    % change of the resnorm value
    resChange = resnorm - plRes_inc(end);

    if resnorm - res_test > threshold % was resnorm - res
        break;
    end
     
    if resChange > maxChange 
%         fprintf('resChange was larger than maxChange')
        step_inc = step_inc / 2; 
        step_inc = max(step_inc, minStep);
        %         continue; % LOTS OF ERRORS. Changed it, although it should be
        %         here, look into this!
    elseif resChange < minChange
%         fprintf('resChange was smaller than minChange')
        step_inc = step_inc * 2;
        step_inc = min(step_inc, maxStep);
        %         continue; % LOTS OF ERRORS. Changed it, although it should be
        %         here, look into this!
    end
    if rem(k_inc+1, 10) == 0
        fprintf(['Count increased to ' num2str(k_inc + 1) '\n'])
    end
%     fprintf(['Count increased to ' num2str(k_inc + 1)])
    count_inc = count_inc + 1;
    k_inc = k_inc + 1;
    plPar_inc(k_inc) = tempPar; 
    plRes_inc(k_inc) = resnorm;
    nPar(k_inc,:)= x;
end

k_dec = 1;
count_dec = 1;
plPar_dec(1) = par(i);
plRes_dec(1) = res_test; % was res
step_dec = step;

nPar = [par(1:i-1) par(i+1:end)];

while plPar_dec(end) >= minPar && count_dec <= nr
    % take a step along the parameter 
    tempPar = -step_dec + plPar_dec(end);

    [x, resnorm] = lsqnonlin(@(nPar)optFun(nPar, tempPar), nPar(k_dec,:), lb, ub, Optimoptions);
    
    % change of the resnorm value
    resChange = resnorm - plRes_dec(end);

    if resnorm - res_test > threshold
        break;
    end
     
    if resChange > maxChange 
%         fprintf('resChange was larger than maxChange')
        step_dec = step_dec / 2; 
        step_dec = max(step_dec, minStep);
        %         continue; % LOTS OF ERRORS. Changed it, although it should be
        %         here, look into this!
    elseif resChange < minChange
%         fprintf('resChange was smaller than minChange')
        step_dec = step_dec * 2;
        step_dec = min(step_dec, maxStep);
        %         continue; % LOTS OF ERRORS. Changed it, although it should be
        %         here, look into this!
    end
    if rem(k_dec+1, 10) == 0
        fprintf(['Count increased to ' num2str(k_dec + 1) '\n'])
    end
%     fprintf(['Count increased to ' num2str(k_dec + 1)])
    count_dec = count_dec + 1;
    k_dec = k_dec + 1;
    plPar_dec(k_dec) = tempPar; 
    plRes_dec(k_dec) = resnorm;
    nPar(k_dec,:)= x;
end

plPar = [flip(plPar_dec) par(i) plPar_inc];
plRes = [flip(plRes_dec) resnorm_start plRes_inc];

% plPar = [flip(plPar_dec) plPar_inc];
% plRes = [flip(plRes_dec) plRes_inc];

% plPar
% plRes

end
