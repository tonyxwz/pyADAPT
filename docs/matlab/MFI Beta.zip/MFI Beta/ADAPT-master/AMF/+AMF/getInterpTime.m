function t = getInterpTime(data, user_input, ts)

if nargin < 3, ts = 0; end

t = data.time(1) : (data.time(end) - data.time(1)) / user_input.options.numTimeSteps : data.time(end);

if ts > 0 % If not 0 or negative
    SSTime = user_input.options.SSTime; % This is 1000 in some models
    
    if ts > 1 % If bigger than 1 
        t = [t(ts-1) ; (t(ts-1) + t(ts)) / 2; t(ts)];
    else % If exactly 1
        t0 = t(ts) - SSTime; % So this is weird. Since t(ts) == t(1) == this.predictor.val(1). But then why the - SStime which makes it -1000 in some models? 
        t = [t0 ; (t0 + t(ts)) / 2 ; t(ts)]; % For the first step this is [-1000; -500; 0]
    end
end

t = t(:);