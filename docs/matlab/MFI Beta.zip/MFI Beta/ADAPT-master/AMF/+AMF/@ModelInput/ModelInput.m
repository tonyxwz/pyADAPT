classdef ModelInput < AMF.ModelComponent
    properties
        type
        func
        predictor
        parameters
        method
        
        initVal
        initTime
        
        args
        dName
        pidx
    end
    methods
        function this = ModelInput(index, name, type, args, dName, method, meta)
            this = this@AMF.ModelComponent(index, name, meta);
            
            this.type = type;
            this.args = args;
            this.dName = dName;
            this.method = method;
        end
    end
end