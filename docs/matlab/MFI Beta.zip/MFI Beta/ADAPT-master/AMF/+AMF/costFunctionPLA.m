function error = costFunctionPLA(par, model, data, link, t, x0, user_input)

% par_temp = [model.parameters.init];
% par_temp(user_input.pidx) = par;
% p = model.result.pcurr;

% p = par_temp;
p = par;

uvec = model.uvec;

% uvec = model.result.uvec;
% uvec(model.result.uidx) = model.result.pcurr(model.result.upidx);

x = computeStates(model, t, x0, p, uvec, user_input);
v = computeReactions(model, t, x, p, uvec);

% model.result.xcurr = x; 
% model.result.vcurr = v;

% ox = x(:,model.result.oxi);
% of = v(:,model.result.ofi);

% ox = x(:, find([data.fields.obs]));
% of = v(:, find([model.reactions.obs]));
ox = x(:, logical(link.oxi));
of = v(:, logical(link.ofi));

sim = [ox of];

odi = [link.oxdi link.ofdi]; % MAKE ADJUSTMENTS FROM HERE

dat = data.dd(:,odi);
sd = data.ds(:,odi);

error = (sim(:) - dat(:)) ./ sd(:);

if ~isempty(model.functions.reg)
    error = [error; model.functions.reg(model, model.iStruct, model.dStruct)];
end

mode = 1; % Decide here if you want to change inf's and NaN's with 0's, or delete them from the array

if mode == 1
    error(isnan(error)) = 0; % Quick Note: Funny how here it is done correctly, while in another costfunction the NaN's and Inf's are deleted % Maybe it was done correctly and I'm just an idiot
    error(isinf(error)) = 0;% Initialize
elseif mode == 2
    error = error(~isnan(error));
    error = error(~isinf(error));
end

if length(error) < length(p)
    error = [error; zeros(length(p) - length(error), 1)];
end

end