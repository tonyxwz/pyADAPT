function filter = isObservable(compArray)

filter = logical([compArray.obs]);