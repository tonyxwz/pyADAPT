function this = plot(this)

plot(this.time, this.curr, 'b');