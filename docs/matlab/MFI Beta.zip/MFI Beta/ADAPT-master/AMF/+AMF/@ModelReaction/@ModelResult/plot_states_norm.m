function this = plot_states_norm(this)

