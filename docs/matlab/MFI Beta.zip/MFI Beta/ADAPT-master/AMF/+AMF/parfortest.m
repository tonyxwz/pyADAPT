for i = 1:10
    i
end

parfor i = 11:20
    i
end