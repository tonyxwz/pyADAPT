function d1 = calc_weights(t1, t2, ratio, Va, norm, w)

temp = zeros(size(t2));

for i = 1:length(t1)
    
    lowt = find(t1(i) >= t2, 1, 'last');
    hight = find(t1(i) <= t2, 1, 'first');
    
    if t2(lowt) == t1(i)
        temp(lowt) = 1;
    else
        temp(lowt) = 1;
        temp(hight) = 1;
    end
end

b1 = length(t1);
b2 = length(find(temp));

a = length(t2) - b2;

Vb = (ratio * a - b2) * Va / b1;

d1 = repmat(Va, size(t2));

for i = 1:length(t1)
    
    lowt = find(t1(i) >= t2, 1, 'last');
    hight = find(t1(i) <= t2, 1, 'first');
    
    if t2(lowt) == t1(i)
        d1(lowt) = d1(lowt) + Vb;
    else
        d1(lowt) = d1(lowt) + (t2(hight)-t1(i)) * Vb;
        d1(hight) = d1(hight) + (t1(i)-t2(lowt)) * Vb;
    end
end

if norm == 1
    d1 = d1/(sum(d1));
end

d1 = d1*w;


% bar(t2,d1)