function [pest, sse, resid] = fitTimeStep(model, ts)

setTimeStep(model, ts); % Sets model.currTimeStep to ts (not sure why you need a separate function for that)

model.result.pprev = model.result.pcurr; % Why does this work for the first iteration? I guess that model.result.pcurr has already been set somewhere in the initialization?
% Checked it: In the model class the model.result.pcurr is set:
% "this.result.pcurr = [this.parameters.init];" So model.result.pcurr gets overwritten every single time the fit is run, and after the simulation there will only be the last calculated parameters. 
% So where is the this.parameters.init set?
% This is set in the model class as well. 

x0 = model.result.xcurr; % Same as comments above 
p0 = model.result.pcurr(model.result.pidx); % " "
lb = model.result.lb(model.result.pidx); % " "
ub = model.result.ub(model.result.pidx); % " "

t = getTime(model, ts); % Now this is a weird one... See getTime.m for my thoughts on it. 
% Anyway, what it does is give a column vector t with the previous t, then
% the (curr_t + prev_t) / 2 and then the current t. 

% model.options.optimset.Display = 'iter';

[pest, sse, resid] = lsqnonlin(@objectiveFunction,(p0), lb, ub, model.options.optimset, model, x0, t, ts); % Standard parameter estimation, but why do you need a t with 3 values and a separate ts? SOLVED, look at costfunction.

model.result.p(ts,:) = model.result.pcurr;
model.result.x(ts,:) = model.result.xcurr;
model.result.v(ts,:) = model.result.vcurr;
model.result.sse(ts) = sse;

if ~isempty(model.inputs)
    uvec = model.result.uvec;
    uvec(model.result.uidx) = model.result.pcurr(model.result.upidx);
    
    model.result.u(ts,:) = computeInputs(model, t(end), uvec);
end

function error = objectiveFunction(pest, model, x0, t, ts)

model.result.pcurr(model.result.pidx) = pest;
p = model.result.pcurr;

uvec = model.result.uvec;
uvec(model.result.uidx) = model.result.pcurr(model.result.upidx);

x = computeStates(model, t, x0, p, uvec); % I think I get why t needs to be a vector. In computeStates the vector is used for an ode solver. By giving an array instead of bounds, I believe the solver will only calculate on the 3 points instead of on a lot on the interval. 
v = computeReactions(model, t(end), x(end,:), p, uvec);

model.result.xcurr = x(end,:);
model.result.vcurr = v;

ox = model.result.xcurr(model.result.oxi);
of = model.result.vcurr(model.result.ofi);

sim = [ox of];

odi = [model.result.oxdi model.result.ofdi];

dat = model.result.idd(ts,odi);
sd = model.result.ids(ts,odi);

error = (sim(:) - dat(:)) ./ sd(:);

error = [error; zeros(length(p), 1)]; % Why is that? What do the extra zeros do? Doesn't seem to be used anywhere. 

reg = AMF.regFun(model, t); % What is this? regFun? I know what it does, but why is it added to the cost function? A: The reg function
% makes sure that the steps taken aren't to big and that fitted parameters
% actually form trajectories instead of just being perfectly fitted to the
% data. The reg function returns a value that represents the difference
% between the currently estimated parameter value and the previous one. If
% a parameter can be estimated that would make the data fit perfectly but
% it is very different form the previous parameter value, it has las chance
% of being choosen by the algorithm as the correct parameter. lab1 (lambda)
% decides how much this is taken into account. 
error = [error; reg(:)]; 

if ~isempty(model.functions.reg) % I believe there is not a single case where the reg functions isn't empty, so this is trivial
    error = [error; model.functions.reg(model, model.iStruct, model.dStruct)];
end

error(isnan(error)) = 0; % Quick Note: Funny how here it is done correctly, while in another costfunction the NaN's and Inf's are deleted 
error(isinf(error)) = 0;