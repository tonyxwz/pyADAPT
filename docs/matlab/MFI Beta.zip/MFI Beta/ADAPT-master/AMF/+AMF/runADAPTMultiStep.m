function result = runADAPTMultiStep(model, user_input, data, link)

import AMF.*

t = data.idt;

seed = user_input.options.runADAPT.seed;
numIter = user_input.options.runADAPT.numIter;

% rng('default'); 
rng(seed);
% rng('shuffle');

% Calculate array of lambda values for time and parameter depending reg
% function

input_data = ones(length(model.inputs), length(t));

for i = 1:length(model.inputs)
    tI = model.inputs(i).initTime;
    yI = model.inputs(i).initVal;
    
    input_data(i,:) = interp1(tI, yI, t);
end

input_data = input_data ./ (max(input_data, [], 2));
dIdt = sum(abs(diff(input_data, 1, 2)));

labA = user_input.options.runADAPT.labA;
labB = user_input.options.runADAPT.labB;

% labArray = labA +  dIdt' .* labB;
labArray = labA ./  (1 + dIdt' .* labB); % This is very simplistic for numerous reasons, but it might be intresting to see the effects. 


user_input.options.runADAPT.labArray = labArray;

% Calculate weights for cost function depending on data point availability

no_obs = length(link.oxdi) + length(link.ofdi);

weight = ones(length(t), no_obs);

if link.oxdi
    for i = 1:length(link.oxdi)
        t1 = data.fields(link.oxdi(i)).src.time;
        t2 = t;
        ratio = 2;
        Va = 1;
        norm = 0;
        w = 1;
        
        weight(:,i) = calc_weights(t1, t2, ratio, Va, norm, w);
    end
end

if link.ofdi
    for j = 1:length(link.ofdi)
        t1 = data.fields(link.ofdi(j)).src.time;
        t2 = t;
        ratio = 2;
        Va = 1;
        norm = 0;
        w = 1;
        
        weight(:,length(link.oxdi)+j) = calc_weights(t1, t2, ratio, Va, norm, w);
    end
end

user_input.options.runADAPT.weight = weight;

% result.u(1, :) = [model.inputs.init];
% result.v(1,:) = [model.reactions.init];

% fitTimeStep(model, 1) % Why am I doing this?
result_list = [];

% TEMPORARILY 

user_input.options.optimset  = optimset('MaxIter',1e3,'Display','off','MaxFunEvals',350,'TolX',1e-8,'TolFun',1e-8);

start_adapt = tic;

for it = 1:numIter
    
    success = 0;
    
    while ~success
%         try
            start_iteration = tic;
            
            % pre-allocate
            result = ModelResult();
            
            result.sim_type = 'ADAPT';
            result.sim_date = datestr(datetime);
            
            result.model = model;
            result.data = data;
            result.link = link;
            result.user_input = user_input;
            
            result.p = zeros(length(t), length(model.parameters));
            result.x = zeros(length(t), length(model.states));
            result.u = zeros(length(t), length(model.inputs));
            result.v = zeros(length(t), length(model.reactions));
            result.sse = zeros(length(t), 1);
            result.time = t;
            
            result.p0 = [model.parameters.init];
            
            
            model2 = model; % parfor fix % Did I do this? No idea, should check with the original files, otherwise I'm not sure why this needs to be done
            
            if user_input.options.randPars
                randomizeParameters(model2, result, user_input);
            end
            
            if user_input.options.randData
                randomizeData(model2, data, result, user_input);
            end
            
            % Added for input of model simulation instead of interpolated data.
            % This is not randomized, probably want to work on that ** Now it
            % is!
            
            save('tempData.mat', 'data');
            data2 = load('tempData.mat');
            data2 = data2.data;
            delete('tempData.mat');
            
            [data2.dd, data2.ds] = getFitData(data2); % data2.ds == data.ds for a non investigated reason, should look into that
            
            temp_result = fitParameters(model2, user_input, data2, link);
            
            save('tempModel.mat', 'model2');
            model3 = load('tempModel.mat');
            model3 = model3.model2;
            delete('tempModel.mat');
            
            for pNo = 1:length(temp_result.pest)
                model3.parameters(pNo).init = temp_result.pest(pNo);
            end
            
            model3.functions = model2.functions;
            
            data2.time = data.idt;
            temp_result2 = simulate(model3, user_input, link, data2);
            
            temp_val_x = 1;
            temp_val_f = [];
            
            result.idd(:, link.oxdi(temp_val_x)) = temp_result2.x(:, [link.oxmi(temp_val_x)]);
            result.idd(:, link.ofdi(temp_val_f)) = temp_result2.v(:, [link.ofmi(temp_val_f)]);
            
            % result.ids = temp_result2... Or just leave it like that? Will
            % work fine to start of with I think...
            
            % ---- END ----
            
            resultInitVals      = result.idd(1,:);
            result.x0           = [model.states.init]; %result.x(1,:);
            result.x0(logical(link.oxi)) = resultInitVals(link.oxdi);
            
            for ts = 1:length(t)
                fitTimeStepAdaptMultiStep(model2, ts, data, link, result, user_input);
            end
            
            elt = toc(start_iteration);
            
            fprintf('Computed trajectory %d [%d] - %.2fs\n', it, 1, elt); %max(model2.result.sse), elt);
            
            result_list = [result_list result];
            
            success = 1;
        
%         catch er
%             fprintf(['Not able to solve for iteration ' num2str(it) '. Trying new randomization.\n'])
%             seed = seed +1; 
%             rng(seed);
%             rng(ceil(rand(1)*100));
%             
%             fprintf(er.identifier)
%             fprintf(er.message)
%         end
    end
end

elt_total = toc(start_adapt);
fprintf(['Total elapsed time for running ADAPT is ' num2str(elt_total) ' seconds'])

% result = AMF.ModelResult(model, result);

% resultStr = sprintf('%s_%s_%s__%d_%d', user_input.options.savePrefix, model.name, data.activeGroup, user_input.options.runADAPT.numIter, user_input.options.numTimeSteps);
% save([user_input.resultsDir, resultStr], 'result');

result = result_list;

% for it = 1:numIter
%     it
%     
%     success = 0;
%     
%     while ~success
%         ts = 1;
%         try
%             start_iteration = tic;
%             
%             % pre-allocate
%             result = ModelResult();
%             
%             result.p = zeros(length(t), length(model.parameters));
%             result.x = zeros(length(t), length(model.states));
%             result.u = zeros(length(t), length(model.inputs));
%             result.v = zeros(length(t), length(model.reactions));
%             result.sse = zeros(length(t), 1);
%             result.time = t;
%             
%             result.p0 = [model.parameters.init];
%             
%             
%             model2 = model; % parfor fix % Did I do this? No idea, should check with the original files, otherwise I'm not sure why this needs to be done
%             
%             if user_input.options.randPars
%                 randomizeParameters(model2, result, user_input);
%             end
%             
%             if user_input.options.randData
%                 randomizeData(model2, data, result, user_input);
%             end
%             
%             resultInitVals      = result.idd(1,:);
%             result.x0           = [model.states.init]; %result.x(1,:);
%             result.x0(logical(link.oxi)) = resultInitVals(link.oxdi);
%             
%             for ts = 1:length(t)
%                 ts
%                 fitTimeStepAdapt(model2, ts, data, link, result, user_input);
%             end
%             
%             elt = toc(start_iteration);
%             
%             success = 1;
%         catch
%             fprintf(['Program failed at iteration ' num2str(it) ', at timestep ' num2str(ts) '\n'])
%         end
%     end
% 
%     fprintf('Computed trajectory %d [%d] - %.2fs\n', it, 1, elt); %max(model2.result.sse), elt);
%     
%     result_list = [result_list result];
% end
% 
% elt_total = toc(start_adapt);
% fprintf(['Total elapsed time for running ADAPT is ' num2str(elt_total) ' seconds'])
% 
% % result = AMF.ModelResult(model, result);
% 
% resultStr = sprintf('%s_%s_%s__%d_%d', user_input.options.savePrefix, model.name, data.activeGroup, user_input.options.numIter, user_input.options.numTimeSteps);
% save([user_input.resultsDir, resultStr], 'result');
% 
% result = result_list;