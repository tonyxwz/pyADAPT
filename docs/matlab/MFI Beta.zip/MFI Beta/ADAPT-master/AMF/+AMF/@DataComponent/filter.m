function fieldArr = filter(fieldArr, func)

fieldArr = fieldArr(func(fieldArr));