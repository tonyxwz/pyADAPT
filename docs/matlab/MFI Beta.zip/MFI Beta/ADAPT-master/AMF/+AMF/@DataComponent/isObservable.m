function filter = isObservable(fieldArr)

filter = logical([fieldArr.obs]);