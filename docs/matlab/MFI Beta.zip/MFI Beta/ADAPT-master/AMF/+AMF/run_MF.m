%% initialize
clear all
close all

import AMF.*

model_name = 'toyModel'; 
data_name = 'toyData';
% dataGroup = 1;


useMEX = 1;

model = Model(model_name, useMEX);
data = DataSet(data_name);

% dataGroupName = data.groups{dataGroup};

data.time = getFitTime(data);
[data.dd, data.ds] = getFitData(data);

user_input.time = [0 10];
user_input.SSTime = 1000;
user_input.x = ones(size([model.states]));
user_input.p = [model.parameters.init];
user_input.useMEX = useMEX;

% default options
user_input.options.optimset     = optimset('MaxIter',1e3,'Display','off','MaxFunEvals',1e5,'TolX',1e-8,'TolFun',1e-8);
user_input.options.odeTol       = [1e-12 1e-12 100];
user_input.options.useMex       = 0;
user_input.options.parScale     = [2 -2];
user_input.options.numIter      = 10;
user_input.options.lab1         = .1; 
user_input.options.seed         = 1;
user_input.options.numTimeSteps = 100;
user_input.options.SSTime       = 1000;
user_input.options.savePrefix   = '';
user_input.options.randPars     = 1;
user_input.options.randData     = 1;
user_input.options.interpMethod = 'linear';
user_input.options.savePrefix   = [''];

user_input.par_fit_num = 1;

user_input.compileDir = 'temp/';
user_input.resultsDir = 'results/';

user_input.pidx = logical(ones(size(model.parameters)));
user_input.traj = logical(ones(size(model.parameters)));

% TEST

user_input.pidx(5) = 0;
user_input.traj([1 3 5]) = 0;

% /TEST

if ~exist(user_input.compileDir, 'dir')
    mkdir(user_input.compileDir);
    addpath(user_input.compileDir);
end

if ~exist(user_input.resultsDir, 'dir')
    mkdir(user_input.resultsDir);
    addpath(user_input.resultsDir);
end

parseAll(model);
compileAll(model, user_input);

% interpolate data (not randomized)



data.idt = getTime(user_input);

[idd, ids] = getInterpData(data, data.idt);

data.idd = idd;
data.ids = ids;

link = initiateExperiment(model, data);

resultArray = {};

result1 = simulate(model, user_input, link, data); %, link);

result2 = runADAPT(model, data, user_input); %, link);

for p = 1:length(model.parameters)
    figure(p)
    hold on
    
    for it = 1:user_input.options.numIter
        plot(result2(it).p(:,p))
    end
end

 
run_PLA(model, data, link, user_input); %

run_PSA(model, user_input); % 