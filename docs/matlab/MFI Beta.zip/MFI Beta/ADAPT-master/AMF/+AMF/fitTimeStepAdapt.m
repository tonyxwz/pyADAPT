function [pest, sse, resid] = fitTimeStepAdapt(model, ts, data, link, result, user_input)

import AMF.*

% addition for "fit / constant / trajectory" parameters
if ts == 1
    x0 = result.x0;
    
    result.p(ts, :) = result.p0;
    
    p0 = result.p0;
    p0 = p0(user_input.pidx);
    
    lb = [model.parameters.lb];
    lb = lb(user_input.pidx); 
    
    ub = [model.parameters.ub];
    ub = ub(user_input.pidx); 
else  
    x0 = result.x(ts-1, :);
    
    result.p(ts, :) = result.p(ts-1, :);
    
    p0 = result.p(ts-1, :);
    p0 = p0(user_input.traj);
    
    lb = [model.parameters.lb];
    lb = lb(user_input.traj); 
    
    ub = [model.parameters.ub];
    ub = ub(user_input.traj); 
end

t = getInterpTime(data, user_input, ts);

[pest, sse, resid] = lsqnonlin(@objectiveFunction,(p0), lb, ub, user_input.options.optimset, model, data, link, x0, t, ts, result, user_input); % Standard parameter estimation, but why do you need a t with 3 values and a separate ts? SOLVED, look at costfunction.

result.sse(ts) = sse;
result.resid(ts,:) = resid;


function error = objectiveFunction(pest, model, data, link, x0, t, ts, result, user_input)


if user_input.options.runADAPT.useAltInitFit
    % % NEW WAY, used when initial parameters where fitted in "runADAPT"
    if ts == 1
        p = result.p(ts, :);
        p(ts, user_input.pidx) = pest;
    else
        result.p(ts, user_input.traj) = pest;
        p = result.p(ts, :);
    end
else

    % OLD WAY
    if ts == 1
        result.p(ts, user_input.pidx) = pest;
    else
        result.p(ts, user_input.traj) = pest;
    end

    p = result.p(ts, :);
end


x = computeStates(model, t, x0, p, model.uvec, user_input); 
v = computeReactions(model, t(end), x(end,:), p, model.uvec);

result.x(ts, :) = x(end,:);
result.v(ts, :) = v;

xcurr = result.x(ts, :);
vcurr = result.v(ts, :); 

ox = xcurr(:, logical(link.oxi));
of = vcurr(:, logical(link.ofi));

sim = [ox of];

odi = [link.oxdi link.ofdi];

dat = result.idd(ts, odi);
sd = result.ids(ts, odi);


error = (sim(:) - dat(:)) ./ sd(:);

% Addition of weights to cost-function

if user_input.options.runADAPT.use_weights && ts ~= 1

    w = user_input.options.runADAPT.weight(ts, odi)';

    error = error .* w;
end

error = [error; zeros(length(p), 1)]; 

reg = AMF.regFun(model, t, ts, result, user_input); 

error = [error; reg(:)]; 

if ~isempty(model.functions.reg) 
    error = [error; model.functions.reg(model, model.iStruct, model.dStruct)];
end

error(isnan(error)) = 0; 
error(isinf(error)) = 0;

