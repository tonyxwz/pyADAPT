function error = objectiveFunction1(par, model, data, link, t, x0, user_input)

% par_temp = [model.parameters.init];
% par_temp(user_input.pidx) = par;
% p = model.result.pcurr;

% p = par_temp;
p = par;

uvec = [];

% uvec = model.result.uvec;
% uvec(model.result.uidx) = model.result.pcurr(model.result.upidx);

x = computeStates(model, t, x0, p, uvec, user_input);
v = computeReactions(model, t, x, p, uvec);

% model.result.xcurr = x; 
% model.result.vcurr = v;

% ox = x(:,model.result.oxi);
% of = v(:,model.result.ofi);

ox = x(:, find([data.fields.obs]));
of = v(:, find([model.reactions.obs]));

sim = [ox of];

odi = [link.oxdi link.ofdi]; % MAKE ADJUSTMENTS FROM HERE

dat = data.idd(:,odi);
sd = data.ids(:,odi);

error = (sim(:) - dat(:)) ./ sd(:);

error = [error; zeros(length(p), 1)];

if ~isempty(model.functions.reg)
    error = [error; model.functions.reg(model, model.iStruct, model.dStruct)];
end

% error = error(~isnan(error));
% error = error(~isinf(error));

error(isnan(error)) = 0;
error(isinf(error)) = 10^99;

end