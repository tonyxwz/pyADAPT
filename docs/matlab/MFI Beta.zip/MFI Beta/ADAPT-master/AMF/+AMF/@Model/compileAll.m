function compileAll(this, user_input)

clear mex

compileDir = user_input.compileDir;
useMEX = user_input.useMEX;

compileODE(this, compileDir);
compileODEMex(this, compileDir);
compileInputs(this, compileDir);
compileReactions(this, compileDir, useMEX);

if useMEX
    compileMex(this, compileDir);
end

addpath(compileDir);