function this = setTimeStep(this, ts)

this.currTimeStep = ts;