function [] = randomizeParameters(this, result, user_input)

% This does not take the lower and upper bounds into account at all, might be a good addition 
% Preferably this uses smax and smin to calculate minimum values for each
% parameter based on the inital value, or gets intervals between upper and
% lower bounds.

% traj_idx = find(user_input.traj); % shouldn't this be pidx? 
traj_idx = find(user_input.pidx); 

np = length(traj_idx);

smax = user_input.options.parScale(1); 
smin = user_input.options.parScale(2);
rand_p = 10.^((smax-smin)*rand(np,1)+smin);

% for i = 1:np
%     result.p0(traj_idx(i)) = rand_p(i);
% end

for i = 1:np
    result.p0(traj_idx(i)) = result.p0(traj_idx(i)) * rand_p(i);
end
