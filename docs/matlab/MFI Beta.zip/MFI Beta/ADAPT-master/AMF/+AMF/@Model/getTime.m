function t = getTime(user_input, ts)

if nargin < 2, ts = 0; end

t = user_input.time(1) : (user_input.time(end) - user_input.time(1)) / user_input.numTimeSteps : user_input.time(end);

if ts > 0 % If not 0 or negative
    SSTime = user_input.SSTime; % This is 1000 in some models
    
    if ts > 1 % If bigger than 1 
        t = [t(ts-1) ; (t(ts-1) + t(ts)) / 2; t(ts)];
    else % If exactly 1
        t0 = t(ts) - SSTime; % So this is weird. Since t(ts) == t(1) == this.predictor.val(1). But then why the - SStime which makes it -1000 in some models? 
        t = [t0 ; (t0 + t(ts)) / 2 ; t(ts)]; % For the first step this is [-1000; -500; 0]
    end
end

t = t(:);