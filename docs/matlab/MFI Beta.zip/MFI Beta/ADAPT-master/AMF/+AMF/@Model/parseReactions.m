function this = parseReactions(this)

%