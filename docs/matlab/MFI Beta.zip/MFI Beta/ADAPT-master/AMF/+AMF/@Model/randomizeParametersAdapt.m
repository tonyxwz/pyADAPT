function pcurr = randomizeParametersAdapt(this)

% This does not take the lower and upper bounds into account at all, might be a good addition 

traj_idx = find(this.result.traj);

np = length(traj_idx);

smax = this.options.parScale(1); 
smin = this.options.parScale(2);
pcurr = 10.^((smax-smin)*rand(np,1)+smin);

for i = 1:np
    this.parameters(traj_idx(i)).init = pcurr(i);
    this.parameters(traj_idx(i)).curr = pcurr(i);
end

this.result.pcurr = [this.parameters.init];
this.result.pinit = [this.parameters.init];