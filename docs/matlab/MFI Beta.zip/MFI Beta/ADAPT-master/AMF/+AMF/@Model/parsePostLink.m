function this = parsePostLink(this, data, user_input)

parseConstants(this, data);
parseStates(this, data, user_input);
parseInputsPostLink(this, data);

