function this = parseParameters(this)

for comp = this.parameters
    
    if isa(comp.init, 'char')
        sourcePar = this.ref.(comp.init); % THIS IS ALL FOR NOW DUE TO THE TIEMANN MODEL, THIS ALL SHOULD BE REMOVED AT ONE POINT!!!
        comp.init = sourcePar.init; % This whole thing is to (as far as I can see) copy parameter values. Not sure why this is necessary.
        comp.val = comp.init;
    end
end
