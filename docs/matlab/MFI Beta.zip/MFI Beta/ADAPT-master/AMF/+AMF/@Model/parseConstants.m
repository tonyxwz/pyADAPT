function this = parseConstants(this, data)

if isempty(this.constants)
    return
end

for comp = this.constants
    
    if ~isempty(comp.dName)
        comp.val = data.ref.(comp.dName).src.val(1);
    end
%     switch class(comp.expr)
%         
%         case 'char'
% %             if isempty(data)
% %                 error('Can not obtain constant value from dataset.');
% %             end
%             
% %             comp.val = data.ref.(comp.expr).src.val(1);
%             comp.val = 1;
%             
%         case 'double'
%             comp.val = comp.expr;
%             
%     end

end