function [] = randomizeData(model, data, result, user_input)

import AMF.*

randomize(data);

% t = getTime(user_input);
t = data.idt;

% [idd, ids] = getInterpData(data, t, 'spline'); % Shouldn't I use some of the options to decide if the functions should use splines?
[idd, ids] = getInterpData(data, t, user_input); % Shouldn't I use some of the options to decide if the functions should use splines? % CORRECTION: IT DOES


result.idt = t;
result.idd = idd;
result.ids = ids;