function x = computeStates(this, t, x0, p, uvec, user_input)

useMEX = user_input.useMEX;
options = user_input.options;

% t = [t(1) t(end)]; % TESTTESTTEST!

if ~useMEX
    mStruct = this.mStruct;
    [~, x] = ode15s(this.functions.ODE, t, x0, options.odeTol, p, uvec, mStruct);
else
    [~, x] = this.functions.ODEC(t, x0, p, uvec, options.odeTol);
    x = x';
end