function this = parsePreLink(this)

parseParameters(this); % At the moment only for Tiemann Model, might want to remove later, but for this moment it works and has no negative effects on other models. 
parseInputsPreLink(this);
