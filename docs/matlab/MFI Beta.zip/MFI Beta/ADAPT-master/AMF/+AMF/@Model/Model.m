classdef Model < handle
    properties
        name 
        specification
        
        compilePrefix 
        
        functions 
        
        template 
        list
        ref
        
        predictors
        constants
        inputs
        parameters
        states
        reactions
        
        observableStates
        observableReactions
        observableStatesData
        observableReactionsData
        observables
        
        mStruct
        iStruct
        
        uidx
        upidx
        uvec
    end
    
    methods
        function this = Model(modelFile, useMEX) % useMEX was added as input variable, par_num as well
            this.name = modelFile;
            this.specification = feval(modelFile, useMEX);

            this.compilePrefix = ['C_', this.name];
                    
            this.functions.ODE = str2func([this.compilePrefix, '_ODE']);
            this.functions.ODEMex = str2func([this.compilePrefix, '_ODEMEX']);
            this.functions.ODEC = str2func([this.compilePrefix, '_ODEC']);
            this.functions.reactions = str2func([this.compilePrefix, '_REACTIONS']);
            this.functions.inputs = str2func([this.compilePrefix, '_INPUTS']);
            this.functions.reg = [];
            this.functions.err = @AMF.errFun;
            this.functions.errStep = @AMF.errFunStep;
            
            pwd
            
            addComponents(this, 'PREDICTOR', this.specification, @AMF.ModelPredictor);
            addComponents(this, 'CONSTANTS', this.specification, @AMF.ModelConstant);
            addComponents(this, 'INPUTS', this.specification, @AMF.ModelInput);
            addComponents(this, 'PARAMETERS', this.specification, @AMF.ModelParameter);
            addComponents(this, 'STATES', this.specification, @AMF.ModelState);
            addComponents(this, 'REACTIONS', this.specification, @AMF.ModelReaction);
            
            % component list
            this.list = struct2cell(this.ref); % See if either model.list or model.ref can be removed
            
            % component groups
            this.predictors = getAll(this, 'predictor');
            this.constants = getAll(this, 'constants');
            this.inputs = getAll(this, 'inputs');
            this.parameters = getAll(this, 'parameters');
            this.states = getAll(this, 'states');
            this.reactions = getAll(this, 'reactions');
          
            uidx = [];
            upidx = [];
            uvec = []; 
        end
    end
end