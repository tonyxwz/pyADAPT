function this = parseStates(this, data, user_input)

[dd, ~] = getInterpData(data, 0, user_input);
d = getDataStruct(data);

for comp = this.states
    
    if ~isempty(comp.dName)
        comp.init = dd(d.d.(comp.dName));
    end
%     if isa(comp.initExpr, 'char')
%         dataCompName = comp.initExpr;
%         comp.init = dd(d.d.(dataCompName));
%     end
end

% this.result.xinit = [this.states.init];
% this.result.xcurr = [this.states.init];