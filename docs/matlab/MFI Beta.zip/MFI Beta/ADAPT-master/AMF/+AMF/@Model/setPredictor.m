function this = setPredictor(this, name)

this.predictor = this.ref.(name);
% parseAll(this);