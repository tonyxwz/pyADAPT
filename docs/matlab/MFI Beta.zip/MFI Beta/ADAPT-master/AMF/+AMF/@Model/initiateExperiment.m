function link = initiateExperiment(model, data)

observables = filter(data, @isObservable);

link.oxi = zeros(size(model.states));
link.oxdi = zeros(size(model.states));
link.oxmi = zeros(size(model.states));

link.ofi = zeros(size(model.reactions));
link.ofdi = zeros(size(model.reactions));
link.ofmi = zeros(size(model.reactions));

for i = 1:length(observables)
    df = observables{i};
    name = df.name;
    
    modelIdx = model.ref.(name).index;
    dataIdx = df.index;
    
    if isa(model.ref.(name), 'AMF.ModelState')
        link.oxi(modelIdx) = 1;
        link.oxdi(modelIdx) = dataIdx;
        link.oxmi(modelIdx) = modelIdx;
    elseif isa(model.ref.(name), 'AMF.ModelReaction')
        link.ofi(modelIdx) = 1;
        link.ofdi(modelIdx) = dataIdx; 
        link.ofmi(modelIdx) = modelIdx;
    end
end

link.oxdi = nonzeros(link.oxdi)';
link.ofdi = nonzeros(link.ofdi)';

link.oxmi = nonzeros(link.oxmi)';
link.ofmi = nonzeros(link.ofmi)';

link.oxi = logical(link.oxi);
link.ofi = logical(link.ofi);

link.dStruct = getDataStruct(data); % This should probably be stored in the data object, since it's constant


% link.oxi = zeros(size(model.states));
% link.oxdi = [];
% 
% link.ofi = zeros(size(model.reactions));
% link.ofdi = [];
% 
% for i = 1:length(observables)
%     df = observables{i};
%     name = df.name;
%     
% %     model.ref.(name).obs = 1;
% %     model.ref.(name).dataIdx = df.index;
%     
%     if isa(model.ref.(name), 'AMF.ModelState')
%         link.oxi(i) = 1;
%         link.oxdi = [link.oxdi df.index];
%     elseif isa(model.ref.(name), 'AMF.ModelReaction')
%         link.ofi(i) = 1;
%         link.ofdi = [link.ofdi df.index];        
%     end
%     
% %     link.(name).obs = 1;
% %     link.(name).dataIdx = df.index;
% end

% save observable indices (states, reactions corresponding data)
% link.oxi = logical([model.states.obs]);
% link.ofi = logical([model.reactions.obs]);
% link.oxdi = [model.states.dataIdx];
% link.ofdi = [model.reactions.dataIdx];

%
% dt = getFitTime(this.dataset);
% [dd, ds] = getFitData(this.dataset);
% 
% this.result.dt = dt(:);
% this.result.dd = dd;
% this.result.ds = ds;

% link.dStruct = getDataStruct(data);