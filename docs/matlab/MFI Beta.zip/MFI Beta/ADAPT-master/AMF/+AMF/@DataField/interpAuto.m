function [val, std] = interpAuto(field, t)

% val = pchip(field.src.time, field.curr.val, t);
std = pchip(field.src.time, field.curr.std, t);

region_start = [];
region_end = []; 

t_src = field.src.time;

diff_t = diff(t_src'); % diff iterates over time and calculates the difference between 
% element and the next one (if there is one), resulting in O (n-1) 
threshold = mean(diff_t); % mean iterates over diff_t and sums up all elements, and
% finally divides by the number of elements, resulting in O (n)

region_map = diff_t > threshold; % iterates over the length of diff_time and compares
% each element via a constant time comparison, resulting in O (n-1)


padded_rm = [1 region_map 1];

last_found = 1;

 for i = 1 : (length(padded_rm) -2) % for loop iterates n times
     % only one of the statements below will be run, and each will take
     % constant time
    if last_found == 1
        if padded_rm(i) && ~padded_rm(i+1) && ~padded_rm(i+2)

            region_start(end+1) = i;
            last_found = 0;
        end
    end
    
    if last_found == 0
        if ~padded_rm(i) && ~padded_rm(i+1) && padded_rm(i+2) 

            region_end(end+1) = i+1;
            last_found = 1;
        end
    end
 end       
 
 region_array = [region_start ; region_end];
 
 y = field.curr.val;
 y2 = y;
 
 p = field.smooth;

for j = 1:size(region_array,2) % iterations m times, where m is the number
    % of regions found
    ind1 = region_array(1,j); 
    ind2 = region_array(2,j);
    
    % interpolation takes polynomial time
    y2(ind1:ind2) = csaps(t_src(ind1:ind2), y(ind1:ind2), p, t_src(ind1:ind2));
end % maximum time is m * (n/m)^2 = n^2/m. Since m is always smaller than n
    % this results in O (n^2)

% interpolation takes polynomial time, O (n^2)
val = pchip(t_src, y2, t);