function fieldArr = randomize(fieldArr)

for field = fieldArr
    if ~isempty(field.src.std)
        
        if field.src.val == field.src.std
            field.curr.val = field.src.val + 0.1 * randn(size(field.src.val)) .* field.src.std; % ADDED 21-09-2017
        else
            field.curr.val = field.src.val + randn(size(field.src.val)) .* field.src.std;
        end
        
        genSpline(field);
    end
end