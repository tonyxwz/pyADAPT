function [val, std] = interpSpline(field, t)

% if isempty(field.ppform) % got rid of this to make sure GUI works, should
% test effect on runtime at one point, but I reckon  effect is minimal.
genSpline(field);
% end

val = ppval(field.ppform, t)';

if any(field.curr.std)
    std = sqrt(interp1(field.src.time, field.curr.std .^ 2, t, 'linear','extrap'))';
else
    std = val;  % Added to make sure that there always is a std array. Should be revised, though!
%     std = [];
end