function fieldArr = genSpline(fieldArr)

for i = 1:length(fieldArr)
    field = fieldArr(i);

    if isConstant(field)
        continue
    end

    t   = field.src.time;
    dd  = field.curr.val;
    ds  = field.curr.std;
    smooth = field.smooth; % I don't believe this effects the currents model, but should be changed later on so that the smoothness of user_input is used
    % something like:
    % smooth = user_input.options.runADAPT.interpStyle(field.index) % will
    % also need to add user_input to function inputs
    w   = (1 ./ ds ).^2;

    if (sum(isinf(w))==0)
%         field.ppform = csaps(t,dd,smooth,[],w);

        % !!! Weights from standard deviations are NOT included in this current version !!!
        
        field.ppform = csaps(t,dd,smooth,[]); 
    else
        field.ppform = csaps(t,dd,smooth,[]);
    end
end