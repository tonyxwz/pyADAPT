function [val, std] = interpHermite(field, t)

val = pchip(field.src.time, field.curr.val, t);
std = pchip(field.src.time, field.curr.std, t);