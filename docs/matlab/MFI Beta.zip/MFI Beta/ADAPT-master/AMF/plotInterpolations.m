clear all
close all

dat = load('BC003_pre_400it_ADAPT_version1_without_errors.mat');
% dat = load('BC003_pre_400it_ADAPT_version4.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

figure()
plot(result(1).idt, result(1).idd(:,5))
hold on
errorbar(data.data.BC003pre.ins_time, data.data.BC003pre.ins_conc, data.data.BC003pre.ins_std, ...
    '.', 'MarkerSize', 15, 'MarkerEdgeColor', 'black', 'Color', 'black', 'MarkerFaceColor', 'black')
hold off