function result = runTest(model, user_input, data, link)
%% Uses input from the GUI to run a desired program and returns the result to the GUI workspace

import AMF.*

lambdaList = [0 0.01 0.1 0.3];
smoothnessList = [0.1 0.5 0.9 1]; 
numTimeStepsList = [10 100 1000 3000]; 

lambdaResultList = {};

for lambda = lambdaList
    
    user_input.options.lab1 = lambda;
    result = runADAPT(model, user_input, data, link); 
    
    lambdaResultList{end+1} = result;
    
end

subNum = 1;
for rslt = lambdaResultList
    rslt2 = rslt{1};
    
    figure(1)
    subplot(2,2,subNum)
    hold on
    for it = 1:user_input.options.numIter
        plot(rslt2(it).p(:,1)) % the :,1 means that the first parameter is taken in every aspect, might want to change this, or make it variable / changable
    end
    hold off
    
    subNum = subNum +1;
end

smoothnessResultList = {};

for smoothness = smoothnessList
    
    for i = 1:length(data.fields)
        data.fields(i).smooth = smoothness;
    end
    
    result = runADAPT(model, user_input, data, link); 
    
    smoothnessResultList{end+1} = result;
    
end

subNum = 1;
for rslt = smoothnessResultList
    rslt2 = rslt{1};

    figure(2)
    subplot(2,2,subNum)
    hold on
    for it = 1:user_input.options.numIter
        plot(rslt2(it).p(:,1)) % the :,1 means that the first parameter is taken in every aspect, might want to change this, or make it variable / changable
    end
    hold off
    
    subNum = subNum +1;
end

numTimeStepsResultList = {};

for numTimeSteps = numTimeStepsList
    
    user_input.options.numTimeSteps = numTimeSteps;
    
    data.idt = getTime(user_input);

    [idd, ids] = getInterpData(data, data.idt);

    data.idd = idd;
    data.ids = ids;
    
    result = runADAPT(model, user_input, data, link); 
    
    numTimeStepsResultList{end+1} = result;
    
end

subNum = 1;
for rslt = numTimeStepsResultList
    rslt2 = rslt{1};
    
    figure(3)
    subplot(2,2,subNum)
    hold on
    for it = 1:user_input.options.numIter
        plot(rslt2(it).p(:,1)) % the :,1 means that the first parameter is taken in every aspect, might want to change this, or make it variable / changable
    end
    hold off
    
    subNum = subNum +1;
end
