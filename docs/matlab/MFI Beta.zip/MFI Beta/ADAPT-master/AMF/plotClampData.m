data = load('Data.mat');

data2 = data.BC003pre;

glu_time = data2.glu_time;
glu_conc = data2.glu_conc;

glu_ttr_time = data2.glu_time2;
glu_ttr = data2.glu_ttr;

gly_time = data2.gly_time;
gly_conc = data2.gly_conc;

gly_ttr_time = data2.gly_time2;
gly_ttr = data2.gly_ttr;

FFA_time = data2.FFA_time;
FFA_conc = data2.FFA_conc;

ins_time = data2.ins_time;
ins_conc = data2.ins_conc;

figure()

subplot(2,3,1)

scatter(ins_time, ins_conc)

subplot(2,3,2)

scatter(glu_time, glu_conc)

subplot(2,3,3)

scatter(glu_ttr_time, glu_ttr)

subplot(2,3,4)

scatter(gly_time, gly_conc)

subplot(2,3,5)

scatter(gly_ttr_time, gly_ttr)

subplot(2,3,6)

scatter(FFA_time, FFA_conc)

