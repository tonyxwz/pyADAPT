clear all
close all

% dat = load('BC003_pre_400it_ADAPT_version1_without_errors.mat');
dat = load('BC003_pre_400it_ADAPT_version1_final.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

tic 

no_it = user_input.options.runADAPT.numIter;

for p = 1:length(model.parameters)
    figure(p)
    hold on
    
    for it = 1:user_input.options.runADAPT.numIter
        plot(result(it).time, result(it).p(:,p), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])
    end
    
    title(['Parameter ', model.parameters(p).name])
    xlabel('Time [min]')
%     ylabel('Parameter value')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
    
    saveas(gcf,['small_figure_' model.parameters(p).name '.jpg'])
end

no_states = length(model.states);
no_reactions = length(model.reactions);

for cur_x = 1:no_states
    
    figure()
    hold on
    
    for it = 1:no_it        
        plot(result(it).time, result(it).x(:, cur_x), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])       
    end
    
    title(model.states(cur_x).name)
    xlabel('Time [min]')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
    
    saveas(gcf,['small_figure_' model.states(cur_x).name '.jpg'])
end

for cur_v = 1:no_reactions
    
    figure()
    hold on
    
    for it = 1:no_it
        
        plot(result(it).time, result(it).v(:, cur_v), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])

    end
    
    title(model.reactions(cur_v).name)
    xlabel('Time [min]')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
    
    saveas(gcf,['small_figure_' model.reactions(cur_v).name '.jpg'])
end


% PLOT OBSERVABLE STATES
no_obs_states = length(link.oxdi);

if no_obs_states > 0
    
    figure
    hold on
    
    no_it = user_input.options.runADAPT.numIter;
    
    
    for x = 1:no_obs_states
        cur_state = link.oxmi(x);
        cur_data = link.oxdi(x);
        
        for it = 1:no_it
            subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
            hold on                     
            plot(result(it).time, result(it).x(:, cur_state), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])                      
        end
        x1 = data.dd(:, cur_data);
        x2 = x1(~isnan(x1));
        t1 = data.time;
        t2 = t1(~isnan(x1));
        s1 = data.ds(:, cur_data);
        s2 = s1(~isnan(x1));
        s2(isnan(s2)) = 0;
        errorbar(t2,x2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'black', 'Color', 'black', 'MarkerEdgeColor', 'black', 'MarkerSize', 25, 'LineWidth', 2)
        
        %                     title(['State ' num2str(cur_state)])
        title(model.states(cur_state).name)
        xlabel('Time [min]')
        ylabel('Concentration')
        
        set(findall(gcf,'-property','FontSize'),'FontSize',30)
        
%         saveas(gcf,['small_figure_' model.states(cur_state).name '.jpg'])
    end
end

if no_obs_states > 0
    
    no_it = user_input.options.runADAPT.numIter;
    
    
    for x = 1:no_obs_states
        figure()
        hold on
        cur_state = link.oxmi(x);
        cur_data = link.oxdi(x);
        
        for it = 1:no_it
%             subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
            hold on                     
            plot(result(it).time, result(it).x(:, cur_state), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])                      
        end
        x1 = data.dd(:, cur_data);
        x2 = x1(~isnan(x1));
        t1 = data.time;
        t2 = t1(~isnan(x1));
        s1 = data.ds(:, cur_data);
        s2 = s1(~isnan(x1));
        s2(isnan(s2)) = 0;
        errorbar(t2,x2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'black', 'Color', 'black', 'MarkerEdgeColor', 'black', 'MarkerSize', 25, 'LineWidth', 2)
        
        %                     title(['State ' num2str(cur_state)])
        title(model.states(cur_state).name)
        xlabel('Time [min]')
%         ylabel('Concentration')
        
        set(findall(gcf,'-property','FontSize'),'FontSize',30)
        
        saveas(gcf,['small_figure_' model.states(cur_state).name '.jpg'])
    end
end

% PLOT OBSERVABLE REACTIONS
no_obs_reactions = length(link.ofdi);

if no_obs_reactions > 0
    
    figure
    hold on
    
    for v = 1:no_obs_reactions
        cur_reaction = link.ofmi(v);
        cur_data = link.ofdi(v);
        for it = 1:no_it
            subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
            hold on                             
            plot(result(it).time, result(it).v(:, cur_reaction), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])            
        end
        
        v1 = data.dd(:, cur_data);
        v2 = v1(~isnan(v1));
        t1 = data.time;
        t2 = t1(~isnan(v1));
        s1 = data.ds(:, cur_data);
        s2 = s1(~isnan(v1));
        s2(isnan(s2)) = 0;
        errorbar(t2,v2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'black', 'Color', 'black', 'MarkerEdgeColor', 'black', 'MarkerSize', 25, 'LineWidth', 2)
        
        %                     title(['Reaction ' num2str(cur_reaction)])
        title(model.reactions(cur_reaction).name)
        xlabel('Time [min]')
        %                     ylabel('Concentration')
        
        set(findall(gcf,'-property','FontSize'),'FontSize',30)
    end
end

if no_obs_reactions > 0
        
    for v = 1:no_obs_reactions
        
        figure()
        hold on
        cur_reaction = link.ofmi(v);
        cur_data = link.ofdi(v);
        for it = 1:no_it
%             subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
%             hold on                             
            plot(result(it).time, result(it).v(:, cur_reaction), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])            
        end
        
        v1 = data.dd(:, cur_data);
        v2 = v1(~isnan(v1));
        t1 = data.time;
        t2 = t1(~isnan(v1));
        s1 = data.ds(:, cur_data);
        s2 = s1(~isnan(v1));
        s2(isnan(s2)) = 0;
        errorbar(t2,v2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'black', 'Color', 'black', 'MarkerEdgeColor', 'black', 'MarkerSize', 25, 'LineWidth', 2)
        
        %                     title(['Reaction ' num2str(cur_reaction)])
        title(model.reactions(cur_reaction).name)
        xlabel('Time [min]')
        %                     ylabel('Concentration')
        
        set(findall(gcf,'-property','FontSize'),'FontSize',30)
        
        saveas(gcf,['small_figure_' model.reactions(cur_reaction).name '.jpg'])
    end
end


toc