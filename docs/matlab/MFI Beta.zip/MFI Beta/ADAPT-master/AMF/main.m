%% MFI Main Program
% Runs exactly the same programs as MFI, but without using the GUI.
% Improves flexibility at the cost of simplicity

import AMF.*

%% Set user input

% default options
user_input.time                 = [0 10];
user_input.SSTime               = 1000;
user_input.useMEX               = 1;
user_input.options.odeTol       = [1e-12 1e-12 100];
user_input.options.optimset     = optimset('MaxIter',1e3,'Display','notify','MaxFunEvals',350,'TolX',1e-8,'TolFun',1e-8);
user_input.options.parScale     = [1 -1];
user_input.options.numIter      = 20;
user_input.options.lab1         = 0.1;
user_input.options.seed         = 1;
user_input.options.numTimeSteps = 100;
user_input.options.SSTime       = 1000; % double
user_input.options.savePrefix   = '';
user_input.options.randPars     = 1;
user_input.options.randData     = 1;
user_input.options.interpMethod = 'linear';
user_input.options.savePrefix   = [''];

% general options
user_input.par_fit_num = 1; % TO-DO

user_input.compileDir = 'temp/'; % TO-DO
user_input.resultsDir = 'results/'; % TO-DO

% function specific options
user_input.options.simulate.useData = 1;
user_input.options.simulate.timeSpan = [0 10];

user_input.options.pla.pNum = 1;

user_input.options.runADAPT.seed = 1;
user_input.options.runADAPT.lab1 = 0.1;
user_input.options.runADAPT.numIter = 20;

user_input.options.PLA.pNum = 1;
user_input.options.PSA = [];
user_input.options.fit = [];

user_input.options.simulate.useData = 0;
user_input.options.simulate.usePrevP = 0;
user_input.options.simulate.prevP = [];
user_input.options.simulate.timeSpan = [0 10];

%% Load model

% Use this if you want to select the file from your folders
% modelFilename = uigetfile('*.m','Select file');
% modelName = modelFilename(1:end-2);

% Use this if you want to use the name of the file
modelName = 'fianneModel';

model = feval(modelName, user_input.useMEX);

parNames = {model.PARAMETERS{:,1}};

constantParameterIndex = 1:length(parNames);
fitParameterIndex = [];
variableParameterIndex = [];

model = Model(modelName, user_input.useMEX);

parsePreLink(model);

model.iStruct = getInputStruct(model);
model.mStruct = getInputStructMex(model);

compileAll(model, user_input);

%% Load Data

% Use this if you want to select the file from your folders
% dataFilename = uigetfile('*.m','Select file');
% dataName = dataFilename(1:end-2);

% Use this if you want to use the name of the file
dataName = 'fianneData';

data = DataSet(dataName);

data.idt = getInterpTime(data, user_input);

[idd, ids] = getInterpData(data, data.idt);

data.idd = idd;
data.ids = ids;

%% Link model & data

link = initiateExperiment(model, data);

parsePostLink(model, data);

iStruct = getInputStruct(model);
model.mStruct = getInputStructMex(model);

compileAll(model, user_input);

%% Change data group
% Only use this when you do not want dataGroupNum 1 to be active. Don't
% forget to change dataGroupNum from 1 to desired datagroup number.

% dataGroupNum = 1; % Change to desired data group number
% dataGroupName = data.groups{dataGroupNum};
%
% loadGroup(data, dataGroupName)
%
% % Set time, data and standard deviation
% data.time = getFitTime(data);
% [data.dd, data.ds] = getFitData(data);
%
% % Calculate interpolated data and standard deviation
% data.idt = getInterpTime(data, user_input);
% [idd, ids] = getInterpData(data, data.idt);
% data.idd = idd;
% data.ids = ids;

%% Simulations

% Change the two lines below so that you get a logical array that appoints
% which parameters should be fitted AND trajectories (pidx) and which should be trajectories
% (traj). Constant parameters should be zero in both arrays.
user_input.pidx = logical(ones(size(model.parameters))); % e.g. logical([0 0 1 0 0 1 1]) N.B.: Make sure that every 1 in 'traj' is also a 1 in pidx
user_input.traj = logical(ones(size(model.parameters))); % e.g. logical([0 0 0 0 0 1 0])

% Simulate the model

if user_input.options.simulate.useData
    result{1} = simulate(model, user_input, link, data);
else
    result{1} = simulate(model, user_input);
end

% figure;
% plot(result{1}.time, result{1}.x)
% title('Model states')
% xlabel('Time [s]')
% ylabel('States [-]')
% legend('show')
% 
% figure;
% plot(result{1}.time, result{1}.v)
% title('Model reactions')
% xlabel('Time [s]')
% ylabel('Reaction rate [-]')
% legend('show')

if user_input.options.simulate.useData
    
    oxi = find(link.oxi);
    ofi = find(link.ofi);
    
    dim = ceil(sqrt(length(link.oxdi) + length(link.ofdi)));
    
    figure;
    hold on
    
    for n = 1 : length(link.oxdi)
        
        x1 = data.dd(:, link.oxdi(n));
        x2 = x1(~isnan(x1));
        t1 = data.time;
        t2 = t1(~isnan(x1));
        s1 = data.ds(:, link.oxdi(n));
        s2 = s1(~isnan(x1));
        s2(isnan(s2)) = 0;
        
        subplot(dim, dim, n)
        hold on
        plot(result{1}.time, result{1}.x(:, oxi(n)))
        errorbar(t2,x2,s2,'o')
        hold off
    end
    
    for m = 1 : length(link.ofdi)
        
        x1 = data.dd(:, link.ofdi(m));
        x2 = x1(~isnan(x1));
        t1 = data.time;
        t2 = t1(~isnan(x1));
        s1 = data.ds(:, link.ofdi(m));
        s2 = s1(~isnan(x1));
        s2(isnan(s2)) = 0;
        
        subplot(dim, dim, m+n)
        hold on
        plot(result{1}.time, result{1}.v(:, ofi(m)))
        errorbar(t2,x2,s2,'o')
        hold off
    end
    
    hold off
end

% Runs ADAPT
% if isempty(find(user_input.traj,1))
%     fprintf('Please select at least one parameter to be variable over time before running ADAPT.\n')
%     return
% else
%     result{2} = runADAPT(model, user_input, data, link);
%     
%     for p = 1:length(model.parameters)
%         figure() % figure(p)
%         hold on
%         
%         for it = 1:user_input.options.numIter
%             plot(result{2}(it).p(:,p))
%         end
%         
%         title(['Parameter value over time (',num2str(p),' [-])'])
%         xlabel('Time [s]')
%         ylabel('Parameter value')
%         
%         hold off
%     end
% end

% Performs the parameter sensitivity analysis
% result{3} = run_PSA(model, user_input);

% Performs the profile likelihood analysis
% result{4} = run_PLA(model, user_input, data, link);

% Performs a simple parameter fit to the model
% [pest, sse, ~] = fitParameters(model, user_input, data, link);
% result{5} = {pest, sse};

%% Create your own function!

% Copy and paste, change things, alter data or conditions, and make
% something interesting!

% par_x{1} = 1.0e+03 * [0.1268    0.0318    0.0093    0.0005    0.2838    0.4803    0.1025    0.0091    0.2781    1.0625]; % MEX = 1, mode = 1
% par_x{2} = 1.0e+03 * [0.0815    0.0178    0.0084    0.0009    0.2740    0.4636    0.1055    0.0091    0.2601    1.0271]; % MEX = 1, mode = 2
% par_x{3} =           [23.1969   20.2124    6.9725    0.5123  278.8145  515.9145  101.5357   11.4135  266.7376  751.6258]; % MEX = 0, mode = 2
% par_x{4} =           [47.2995   20.4056    6.9962    0.5193  238.0581  520.5597  106.0012   10.9045  218.8892  879.2806]; % MEX = 0, mode = 1
% 
% for par = par_x
%     
%     par = par{1};
%     
%     for i = 1:length(model.parameters)
%         model.parameters(i).init = par(i);
%     end
% 
%     if user_input.options.simulate.useData
%         result{1} = simulate(model, user_input, link, data);
%     else
%         result{1} = simulate(model, user_input);
%     end
% 
%     figure;
%     plot(result{1}.time, result{1}.x)
%     title('Model states')
%     xlabel('Time [s]')
%     ylabel('States [-]')
%     legend('show')
% 
%     figure;
%     plot(result{1}.time, result{1}.v)
%     title('Model reactions')
%     xlabel('Time [s]')
%     ylabel('Reaction rate [-]')
%     legend('show')
% 
%     if user_input.options.simulate.useData
% 
%         oxi = find(link.oxi);
%         ofi = find(link.ofi);
% 
%         dim = ceil(sqrt(length(link.oxdi) + length(link.ofdi)));
% 
%         figure;
%         hold on
% 
%         for n = 1 : length(link.oxdi)
% 
%             x1 = data.dd(:, link.oxdi(n));
%             x2 = x1(~isnan(x1));
%             t1 = data.time;
%             t2 = t1(~isnan(x1));
%             s1 = data.ds(:, link.oxdi(n));
%             s2 = s1(~isnan(x1));
%             s2(isnan(s2)) = 0;
% 
%             subplot(dim, dim, n)
%             hold on
%             plot(result{1}.time, result{1}.x(:, oxi(n)))
%             errorbar(t2,x2,s2,'o')
%             hold off
%         end
% 
%         for m = 1 : length(link.ofdi)
% 
%             x1 = data.dd(:, link.ofdi(m));
%             x2 = x1(~isnan(x1));
%             t1 = data.time;
%             t2 = t1(~isnan(x1));
%             s1 = data.ds(:, link.ofdi(m));
%             s2 = s1(~isnan(x1));
%             s2(isnan(s2)) = 0;
% 
%             subplot(dim, dim, m+n)
%             hold on
%             plot(result{1}.time, result{1}.v(:, ofi(m)))
%             errorbar(t2,x2,s2,'o')
%             hold off
%         end
% 
%         hold off
%     end
%     
% end