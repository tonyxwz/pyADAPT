clear all
close all

dat = load('BC004_post_40it_ADAPT_version1.mat');
% dat = load('BC003_pre_400it_ADAPT_version4.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

arr = [];
% 30 = RA , 31 = RD
% 17 = infusion 18 = infusion

source_time = [];
source_val = [];
source_std = [];

SoSE = 0;

for j = 1:length(link.oxmi)
    
    temp_arr = [];
    for i = 1:user_input.options.runADAPT.numIter
        temp_arr(:,i) = result(i).x(:,link.oxmi(j));
    end
    mean_temp_arr = mean(temp_arr,2);
    
    arr(:,j) = mean_temp_arr;
    
    source_time = data.list{link.oxdi(j)}.src.time;
    source_val = data.list{link.oxdi(j)}.src.val;
    source_std = data.list{link.oxdi(j)}.src.std;
    
    temp_interp = interp1(data.idt, mean_temp_arr, source_time);
    SoSE = SoSE + sum((temp_interp - source_val).^2);
end

for k = 1:length(link.ofmi)
    
    temp_arr = [];
    for i = 1:user_input.options.runADAPT.numIter
        temp_arr(:,i) = result(i).v(:,link.ofmi(k));
    end
    mean_temp_arr = mean(temp_arr,2);
    
    arr(:,j+k) = mean_temp_arr;
    
    source_time = data.list{link.ofdi(k)}.src.time;
    source_val = data.list{link.ofdi(k)}.src.val;
    source_std = data.list{link.ofdi(k)}.src.std;
    
    temp_interp = interp1(data.idt, mean_temp_arr, source_time);
    SoSE = SoSE + sum((temp_interp - source_val).^2);
end

SoSE