clear all
close all

% dat = load('BC003_pre_50it_ADAPT_version4.mat');
dat = load('BC003_pre_50it_ADAPT_version4.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

tic 

color_map = [0:(1/length(data.idt)):1]'.*[0.5 1 1];


plot_list_p = [1 2 3 4 5 6 7 8 9 10 11 13];
fig_list_p = [1 1 1 1 2 2 2 2 3 3 3 0 3];
pos_list_p = [1 2 3 4 1 2 3 4 1 2 3 0 4];

% for p = 1:length(model.parameters)
% for p = plot_list_p
%     figure(fig_list_p(p))
%     subplot(2,2, pos_list_p(p))
%     %     figure(p)
%     
%     min_p = [];
%     max_p = [];
%     for it = 1:user_input.options.runADAPT.numIter
%         min_p(it) = min(result(it).p(:,p));
%         max_p(it) = max(result(it).p(:,p));
%     end
%     
%     max_p = max(max_p);
%     min_p = min(min_p);
%     
%     y_scale = [min_p max_p];
%     x_scale = [data.idt(1) data.idt(end)];
%     
%     M = zeros(length(data.idt)+1);
%     
%     for it = 1:user_input.options.runADAPT.numIter
%         temp_M = zeros(length(data.idt)+1);
%         try
%             for t_ind = 1:length(data.idt)
%                 temp_val = result(it).p(t_ind,p);
%                 temp_ind = floor( length(data.idt) * (temp_val - min_p) / (max_p - min_p))+1;
%                 %                 if temp_ind == 0
%                 %                     temp_ind = 1;
%                 %                 end
%                 %                 if temp_ind > 101
%                 %                     temp_ind = 101;
%                 %                 end
%                 temp_M(t_ind, temp_ind) = 1;
%             end
%             
%             M = M + temp_M;
%         catch
%         end
%     end
%     M = rot90(M);
%     M = flipud(M);
%     M = M*2;
%     imagesc(x_scale, y_scale, M)
%     set(gca,'YDir','normal')
%     %     colormap(1-color_map)
%     colormap('parula')
%     
%     title(model.parameters(p).name)
%     xlabel('Time [min]')
%     ylabel('Parameter value [-]')
%     
%     set(findall(gcf,'-property','FontSize'),'FontSize',18)
% end

for p = 1:length(model.parameters)
    figure(p)
%     subplot(2,2, pos_list_p(p))
    %     figure(p)
    
    min_p = [];
    max_p = [];
    for it = 1:user_input.options.runADAPT.numIter
        min_p(it) = min(result(it).p(:,p));
        max_p(it) = max(result(it).p(:,p));
    end
    
    max_p = max(max_p);
    min_p = min(min_p);
    
    y_scale = [min_p max_p];
    x_scale = [data.idt(1) data.idt(end)];
    
    M = zeros(length(data.idt)+1);
    
    for it = 1:user_input.options.runADAPT.numIter
        temp_M = zeros(length(data.idt)+1);
        try
            for t_ind = 1:length(data.idt)
                temp_val = result(it).p(t_ind,p);
                temp_ind = floor( length(data.idt) * (temp_val - min_p) / (max_p - min_p))+1;
                %                 if temp_ind == 0
                %                     temp_ind = 1;
                %                 end
                %                 if temp_ind > 101
                %                     temp_ind = 101;
                %                 end
                temp_M(t_ind, temp_ind) = 1;
            end
            
            M = M + temp_M;
        catch
        end
    end
    M = rot90(M);
    M = flipud(M);
    M = M*2;
    imagesc(x_scale, y_scale, M)
    set(gca,'YDir','normal')
    %     colormap(1-color_map)
    colormap('parula')
    
    title(model.parameters(p).name)
    xlabel('Time [min]')
    ylabel('Parameter value')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
end

for q = 1:length(model.states)
    figure(p+q)
    
    min_p = [];
    max_p = [];
    for it = 1:user_input.options.runADAPT.numIter
        min_p(it) = min(result(it).x(:,q));
        max_p(it) = max(result(it).x(:,q));
    end
    
    max_p = max(max_p);
    min_p = min(min_p);
    
    y_scale = [min_p max_p];
    x_scale = [data.idt(1) data.idt(end)];
    
    M = zeros(length(data.idt)+1);
     
    for it = 1:user_input.options.runADAPT.numIter
        temp_M = zeros(length(data.idt)+1);
        try
            for t_ind = 1:length(data.idt)
                temp_val = result(it).x(t_ind,q);
                temp_ind = floor( length(data.idt) * (temp_val - min_p) / (max_p - min_p))+1;
%                 if temp_ind == 0
%                     temp_ind = 1;
%                 end
%                 if temp_ind > 101
%                     temp_ind = 101;
%                 end
                temp_M(t_ind, temp_ind) = 1;
            end
        
            M = M + temp_M; 
        catch
        end
    end
    M = rot90(M);
    M = flipud(M);
    M = M*2;
    imagesc(x_scale, y_scale, M)
    set(gca,'YDir','normal')
%     colormap(1-color_map)
    colormap('parula')
    
    title(model.states(q).name)
    xlabel('Time [min]')
    ylabel('Concentration')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
end

for j = 1:length(link.oxmi)
    model_ind = link.oxmi(j);
    data_ind = link.oxdi(j);
    figure(p+model_ind)
    hold on
    
    x1 = data.dd(:, data_ind);
    x2 = x1(~isnan(x1));
    t1 = data.time;
    t2 = t1(~isnan(x1));
    s1 = data.ds(:, data_ind);
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    title(model.states(model_ind).name)

    errorbar(t2,x2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'white', 'Color', 'white', 'MarkerEdgeColor', 'white', 'MarkerSize', 25, 'LineWidth', 2)
    hold off
end
    
for r = 1:length(model.reactions)
    figure(p+q+r)
    
    min_p = [];
    max_p = [];
    for it = 1:user_input.options.runADAPT.numIter
        min_p(it) = min(result(it).v(:,r));
        max_p(it) = max(result(it).v(:,r));
    end
    
    max_p = max(max_p);
    min_p = min(min_p);
    
    y_scale = [min_p max_p];
    x_scale = [data.idt(1) data.idt(end)];
    
    M = zeros(length(data.idt)+1);
     
    for it = 1:user_input.options.runADAPT.numIter
        temp_M = zeros(length(data.idt)+1);
        try
            for t_ind = 1:length(data.idt)
                temp_val = result(it).v(t_ind,r);
                temp_ind = floor( length(data.idt) * (temp_val - min_p) / (max_p - min_p))+1;
%                 if temp_ind == 0
%                     temp_ind = 1;
%                 end
%                 if temp_ind > 101
%                     temp_ind = 101;
%                 end
                temp_M(t_ind, temp_ind) = 1;
            end
        
            M = M + temp_M; 
        catch
        end
    end
    M = rot90(M);
    M = flipud(M);
    M = M*2;
    imagesc(x_scale, y_scale, M)
    set(gca,'YDir','normal')
%     colormap(1-color_map)
    colormap('parula')
    
    title(model.reactions(r).name)
    xlabel('Time [min]')
    ylabel('Flux / Concentration []')
    
    set(findall(gcf,'-property','FontSize'),'FontSize',30)
end

for k = 1:length(link.ofmi)
    model_ind = link.ofmi(k);
    data_ind = link.ofdi(k);
    
    figure(p+q+model_ind)
    hold on
    
    x1 = data.dd(:, data_ind);
    x2 = x1(~isnan(x1));
    t1 = data.time;
    t2 = t1(~isnan(x1));
    s1 = data.ds(:, data_ind);
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    title(model.reactions(model_ind).name)

    errorbar(t2,x2,s2, 'LineStyle', 'none', 'Marker', '.', 'MarkerFaceColor', 'white', 'Color', 'white', 'MarkerEdgeColor', 'white', 'MarkerSize', 25, 'LineWidth', 2)
    hold off
end