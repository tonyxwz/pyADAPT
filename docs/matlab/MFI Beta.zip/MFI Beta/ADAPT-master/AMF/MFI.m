function varargout = MFI(varargin)
% MFI MATLAB code for MFI.fig
%      MFI, by itself, creates a new MFI or raises the existing
%      singleton*.
%
%      H = MFI returns the handle to a new MFI or the handle to
%      the existing singleton*.
%
%      MFI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MFI.M with the given input arguments.
%
%      MFI('Property','Value',...) creates a new MFI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MFI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MFI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MFI

% Last Modified by GUIDE v2.5 15-Sep-2017 15:46:01

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MFI_OpeningFcn, ...
                   'gui_OutputFcn',  @MFI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MFI is made visible.
function MFI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MFI (see VARARGIN)

% Choose default command line output for MFI
handles.output = hObject;

% Extra input

handles.model = [];
handles.data = [];
handles.link = [];

handles.result_list = {};
handles.saved = 1;


% Default ADAPT and simulation user inputs 
% ==========================================
user_input.time = [0 10]; % currently no effect
user_input.useMEX = get(handles.useMexCheckBox, 'Value');

% default options
user_input.options.odeTol       = [1e-12 1e-12 100];
user_input.options.optimset     = optimset('MaxIter',1e3,'Display','iter','MaxFunEvals',1000,'TolX',1e-8,'TolFun',1e-8); 
user_input.options.useMex       = get(handles.useMexCheckBox, 'Value');
user_input.options.parScale     = [1 -1];
user_input.options.seed         = 1;
user_input.options.numTimeSteps = str2num(get(handles.timeStepsEditText, 'string'));
user_input.options.SSTime       = 1000;
user_input.options.savePrefix   = '';
user_input.options.randPars     = 1; 
user_input.options.randData     = 1;
user_input.options.interpMethod = 'linear';
user_input.options.savePrefix   = [''];

user_input.par_fit_num = 1;  

user_input.compileDir = 'temp/'; 
user_input.resultsDir = 'results/'; 

% set all initial ADAPT options
user_input.options.runADAPT.seed = 1;
user_input.options.runADAPT.labArray = [];
user_input.options.runADAPT.labAValue = 0.1;
user_input.options.runADAPT.labBValue = 0;
user_input.options.runADAPT.labA = [];
user_input.options.runADAPT.labB = [];
user_input.options.runADAPT.numIter = 20;
user_input.options.runADAPT.weight = []; 
user_input.options.runADAPT.use_weights = 1;
user_input.options.runADAPT.interpStateNames = {};
user_input.options.runADAPT.simStateNames = {};
user_input.options.runADAPT.interpStyle = {};
user_input.options.runADAPT.simAsInterpList = {};
user_input.options.runADAPT.parStep1Names = {};
user_input.options.runADAPT.parStep2Names = {};
user_input.options.runADAPT.obsStep1Names = {};
user_input.options.runADAPT.obsStep2Names = {};
user_input.options.runADAPT.useAltInitFit = 0;
user_input.options.runADAPT.labPower = 1;
user_input.options.runADAPT.oxdi_step1 = [];
user_input.options.runADAPT.ofdi_step1 = [];
user_input.options.runADAPT.oxmi_step1 = [];
user_input.options.runADAPT.ofmi_step1 = [];
user_input.options.runADAPT.traj_step1 = [];
user_input.options.runADAPT.traj_step2 = [];

% additional function options
user_input.options.PLA.pNum = 1;
user_input.options.PSA = [];
user_input.options.fit = [];

% regular simulation options
user_input.options.simulate.useData = 0;
user_input.options.simulate.usePrevP = 0;
user_input.options.simulate.prevP = [];
user_input.options.simulate.timeSpan = [0 10];

user_input.options.rePlotData.index = 1;

user_input.smoothness_eps = [];
user_input.smoothness_h = [];
user_input.smoothness_temp_h = user_input.smoothness_h;

user_input.temp_p = [];

handles.user_input = user_input;
% ==========================================

set(handles.simulationPanel,'selectedobject',handles.simulateRadioButton)

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MFI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = MFI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% OLD FUNCTION, does not work in current version!

% --- Executes on button press in testButton.
function testButton_Callback(hObject, eventdata, handles)
% hObject    handle to testButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% 
% handles.user_input.options.numIter = 5;
% 
% handles.user_input.pidx = logical(zeros(size(handles.model.parameters)));
% handles.user_input.traj = logical(zeros(size(handles.model.parameters)));
% 
% handles.user_input.pidx(handles.fitParameterIndex) = 1;
% handles.user_input.pidx(handles.variableParameterIndex) = 1;
% handles.user_input.traj(handles.variableParameterIndex) = 1;
% 
% result = runTest(handles.model, handles.user_input, handles.data, handles.link);
% 
% handles.user_input.options.numIter = str2num(get(handles.iterationsEditText, 'string'));
% 
% handles.user_input.options.labAValue = str2num(get(handles.lambdaEditText, 'string'));
% handles.user_input.options.numTimeSteps = str2num(get(handles.timeStepsEditText, 'string'));
% for i = 1:length(handles.data.fields)
%     handles.data.fields(i).smooth = str2num(get(handles.smoothnessEdit, 'string'));
% end
% 
% 
% guidata(hObject, handles);

% MAIN RUN BUTTON, executes currently selected function (simulate, ADAPT,
% PLA, PSA or fit)

% --- Executes on button press in runButton.
function runButton_Callback(hObject, eventdata, handles)
% hObject    handle to runButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

import AMF.*

% set parameter fit options
handles.user_input.pidx = logical(zeros(size(handles.model.parameters)));
handles.user_input.traj = logical(zeros(size(handles.model.parameters)));

handles.user_input.pidx(handles.fitParameterIndex) = 1;
handles.user_input.pidx(handles.variableParameterIndex) = 1;
handles.user_input.traj(handles.variableParameterIndex) = 1;

% set current function
currentSimulation = get(handles.simulationPanel, 'SelectedObject');
option = currentSimulation.Callback;

handles.user_input.options.numTimeSteps = str2num(get(handles.timeStepsEditText, 'string'));

if option == '1;'
    % Simulates the model
    fprintf('Starting simulation of the model\n')
    
    if handles.user_input.options.simulate.useData
        result = simulate(handles.model, handles.user_input, handles.link, handles.data);
    else
        result = simulate(handles.model, handles.user_input); 
    end
    
    figure;
    plot(result.time, result.x)
    title('Model states')
    xlabel('Time [-]')
    ylabel('Concentration [-]')
    legend('show')
    
    figure;
    plot(result.time, result.v)
    title('Model reactions')
    xlabel('Time [-]')
    ylabel('Reaction rate [-]')
    legend('show')
    
    if handles.user_input.options.simulate.useData
        
        oxi = find(handles.link.oxi);
        ofi = find(handles.link.ofi);
        
        dim = ceil(sqrt(length(handles.link.oxdi) + length(handles.link.ofdi)));
        
        figure;
        hold on
        
        for n = 1 : length(handles.link.oxdi)
            
            x1 = handles.data.dd(:, handles.link.oxdi(n));
            x2 = x1(~isnan(x1));
            t1 = handles.data.time;
            t2 = t1(~isnan(x1));
            s1 = handles.data.ds(:, handles.link.oxdi(n));
            s2 = s1(~isnan(x1));
            s2(isnan(s2)) = 0;
            
            subplot(dim, dim, n)
            hold on
            plot(result.time, result.x(:, oxi(n)))
            errorbar(t2,x2,s2,'o')
            title(handles.model.states(handles.link.oxmi(n)).name)
        end
        
        for m = 1 : length(handles.link.ofdi)
            
            x1 = handles.data.dd(:, handles.link.ofdi(m));
            x2 = x1(~isnan(x1));
            t1 = handles.data.time;
            t2 = t1(~isnan(x1));
            s1 = handles.data.ds(:, handles.link.ofdi(m));
            s2 = s1(~isnan(x1));
            s2(isnan(s2)) = 0;
                        
            subplot(dim, dim, m+n)
            hold on
            plot(result.time, result.v(:, ofi(m)))
            errorbar(t2,x2,s2,'o') 
            title(handles.model.reactions(handles.link.ofmi(m)).name)
        end
    end
    
    
end

if option == '2;'
    % Runs ADAPT
    fprintf('Starting ADAPT\n')
    
    if isempty(find(handles.user_input.traj,1))
        fprintf('Please select at least one parameter to be variable over time before running ADAPT.\n')
        return
    else
        result = runADAPT(handles.model, handles.user_input, handles.data, handles.link);
        
        % PLOT PARAMETER TRAJECTORIES
        
        for p = 1:length(handles.model.parameters)
            figure(p)
            hold on
            
            for it = 1:handles.user_input.options.runADAPT.numIter
                plot(result(it).time, result(it).p(:,p))
            end
            
            title(['Parameter value over time (', handles.model.parameters(p).name, ' [-])'])
            xlabel('Time [-]')
            ylabel('Parameter value')
        end
        
        % PLOT OBSERVABLE STATES
        no_obs_states = length(handles.link.oxdi);
        
        if no_obs_states > 0
            
            figure
            hold on

            no_it = handles.user_input.options.runADAPT.numIter;

            for it = 1:no_it

                for x = 1:no_obs_states
                    subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
                    hold on

                    cur_state = handles.link.oxmi(x);
                    cur_data = handles.link.oxdi(x);

                    plot(result(it).time, result(it).x(:, cur_state), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])

                    x1 = handles.data.dd(:, cur_data);
                    x2 = x1(~isnan(x1));
                    t1 = handles.data.time;
                    t2 = t1(~isnan(x1));
                    s1 = handles.data.ds(:, cur_data);
                    s2 = s1(~isnan(x1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,x2,s2,'ok')

                    title(handles.model.states(cur_state).name)
                    xlabel('Time [-]')
                    ylabel('Concentration')
                end
            end
        end
        
        % PLOT OBSERVABLE REACTIONS
        no_obs_reactions = length(handles.link.ofdi);
        
        if no_obs_reactions > 0
            
            figure
            hold on

            for it = 1:no_it

                for v = 1:no_obs_reactions
                    subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
                    hold on

                    cur_reaction = handles.link.ofmi(v);
                    cur_data = handles.link.ofdi(v);

                    plot(result(it).time, result(it).v(:, cur_reaction), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])

                    v1 = handles.data.dd(:, cur_data);
                    v2 = v1(~isnan(v1));
                    t1 = handles.data.time;
                    t2 = t1(~isnan(v1));
                    s1 = handles.data.ds(:, cur_data);
                    s2 = s1(~isnan(v1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,v2,s2,'ok')

                    title(handles.model.reactions(cur_reaction).name)
                    xlabel('Time [min]')
                end
            end
        end
        
        no_states = length(handles.model.states);
        no_reactions = length(handles.model.reactions);
        
        for cur_x = 1:no_states
            
            figure()
            hold on
            
            for it = 1:no_it
                
                plot(result(it).time, result(it).x(:, cur_x), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])
                
                title(handles.model.states(cur_x).name)
                xlabel('Time [min]')
            end
        end
        
        for cur_v = 1:no_reactions
            
            figure()
            hold on
            
            for it = 1:no_it
                
                plot(result(it).time, result(it).v(:, cur_v), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])
                
                title(handles.model.reactions(cur_v).name)
                xlabel('Time [min]')
            end 
        end
                
    end  
end    

if option == '3;'
    % Performs the parameter sensitivity analysis
    fprintf('Starting parameter sensitivty analysis\n')
    
    result = run_PSA(handles.model, handles.user_input);
end

if option == '4;'
    % Performs the profile likelihood analysis
    fprintf('Starting profile likelihood analysis\n')
    
    result = run_PLA(handles.model, handles.user_input, handles.data, handles.link); 
end

if option == '5;'
    % Fits the model to the data
    fprintf('Starting fitting model to data\n')
    
    result = fitParameters(handles.model, handles.user_input, handles.data, handles.link);
    
    result.pest
end

% If the a simulation has been run, edit the result list and alter the save/not-saved parameter
handles.result_list{end+1} = result;
handles.saved = 0;

guidata(hObject, handles);

% SAVE BUTTON, saves all results into MAT file

% --- Executes on button press in saveButton.
function saveButton_Callback(hObject, eventdata, handles)
% hObject    handle to saveButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Save the result list to a mat file

% opens save window
[filename, pathname] = uiputfile(...
 {'*.mat'},...
 'Save as');

% saves data, or prevents error when canceled
if filename == 0
    return
else
    result_list = handles.result_list;

    save([pathname filename], 'result_list');
    
    handles.saved = 1;
end

guidata(hObject, handles);

% LOAD BUTTON, loads previsouly saved mat file for re-plotting data or user
% fitted parameters for simulations (additionaly, want to add function to
% load user-input) 

% --- Executes on button press in loadButton.
function loadButton_Callback(hObject, eventdata, handles)
% hObject    handle to loadButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.saved
    choice = questdlg('You have not saved your current results, are you sure you want to load and overwrite the current results?', ...
        'Are you sure you want to load?', ...
        'Yes','No','No');
    % Handle response
    switch choice
        case 'Yes'
            [FileName,PathName,FilterIndex] = uigetfile('.mat');
            
            temp_rl = load([PathName FileName]);
            handles.result_list = temp_rl.result_list;
            
        case 'No'
            return
    end
else
    [FileName,PathName,FilterIndex] = uigetfile('.mat');
    
    if FileName == 0
        return
    else
        temp_rl = load([PathName FileName]);
        handles.result_list = temp_rl.result_list;
    end
end

guidata(hObject, handles);

function timeStepsEditText_Callback(hObject, eventdata, handles)
% hObject    handle to timeStepsEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of timeStepsEditText as text
%        str2double(get(hObject,'String')) returns contents of timeStepsEditText as a double


% --- Executes during object creation, after setting all properties.
function timeStepsEditText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to timeStepsEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function ssTimeEditText_Callback(hObject, eventdata, handles)
% hObject    handle to ssTimeEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ssTimeEditText as text
%        str2double(get(hObject,'String')) returns contents of ssTimeEditText as a double


% --- Executes during object creation, after setting all properties.
function ssTimeEditText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ssTimeEditText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% SELECT MODEL, opens window to select model

% --- Executes on button press in selectModelButton.
function selectModelButton_Callback(hObject, eventdata, handles)
% hObject    handle to selectModelButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
import AMF.*

% open window

modelFilename = uigetfile('*.m','Select file');

% prevent error when loading is cancelled
if modelFilename == 0
    return
end

% create model
modelName = modelFilename(1:end-2);

% get all required data and overwrite default or pre-existing user-inputs
useMEX = get(handles.useMexCheckBox, 'Value');

model = feval(modelName, useMEX);

parNames = {model.PARAMETERS{:,1}};

set(handles.dataGroupListBox, 'Value', 1);

handles.constantParameterIndex = 1:length(parNames);
handles.fitParameterIndex = [];
handles.variableParameterIndex = [];

handles.model_name = modelName;
handles.parameterNames = parNames;
handles.constantParameterNames = parNames;

set(handles.currentModelText, 'string', ['Selected model: ' modelName]);

model = Model(modelName, useMEX);

handles.model = model;

% parse data, retrieve inputs and compile

parsePreLink(handles.model);

handles.model.iStruct = getInputStruct(handles.model);
handles.model.mStruct = getInputStructMex(handles.model);

compileAll(handles.model, handles.user_input);

% set user inputs
labA = zeros(size(parNames));
labA(:) = handles.user_input.options.runADAPT.labAValue;

labB = zeros(size(parNames));
labB(:) = handles.user_input.options.runADAPT.labBValue;

handles.user_input.options.runADAPT.labA = labA;
handles.user_input.options.runADAPT.labB = labB;

handles.user_input.options.runADAPT.interpStateNames = {handles.model.states.name};
handles.user_input.options.runADAPT.simStateNames = {};

set(handles.linkText, 'string', 'No Link established!');
set(handles.linkText, 'ForegroundColor', 'r'); 

guidata(hObject, handles);

% LOAD DATA, loads the data file

% --- Executes on button press in selectDataButton.
function selectDataButton_Callback(hObject, eventdata, handles)
% hObject    handle to selectDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
import AMF.*

dataFilename = uigetfile('*.m','Select file');

if dataFilename == 0
    return
end

dataName = dataFilename(1:end-2);

set(handles.dataGroupListBox, 'Value', 1);
set(handles.currentDataText, 'string', ['Selected data: ' dataName]);

data = feval(dataName);

set(handles.dataGroupListBox, 'string', data.GROUPS);

handles.data = DataSet(dataName);

handles.data.idt = getInterpTime(handles.data, handles.user_input);

% calculated automatic default interpolation values (cubic splines with
% automatic smoothness determination)
for comp = handles.data.fields
    
    smooth_edit = 3;

    xi = comp.src.time;
    
    if numel(xi)-1 < 1
        continue
    end

    epsilon = ((xi(end)-xi(1))/(numel(xi)-1))^3/16;
    p = 1/(1+epsilon * 10^(smooth_edit-3));

    comp.smooth =  p;
    
    handles.user_input.smoothness_eps(comp.index) = epsilon;
    handles.user_input.smoothness_h(comp.index) = 3;
end

handles.user_input.options.runADAPT.interpStyle = cell(1,length(handles.data.fields));
handles.user_input.options.runADAPT.interpStyle(:) = {'spline'};

[idd, ids] = getInterpData(handles.data, handles.data.idt, handles.user_input);

handles.data.idd = idd;
handles.data.ids = ids;

set(handles.linkText, 'string', 'No Link established!');
set(handles.linkText, 'ForegroundColor', 'r'); 

guidata(hObject, handles);

% LINK BUTTON, sets up the link between the model and data needed to know
% all observable indices in model and data object

% --- Executes on button press in linkButton.
function linkButton_Callback(hObject, eventdata, handles)
% hObject    handle to linkButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if isempty(handles.data)
    msgbox('No data selected', 'Error','error');
    return
end

handles.link = initiateExperiment(handles.model, handles.data);

% parse and compile additional information when both model AND data are
% loaded 

parsePostLink(handles.model, handles.data, handles.user_input);

handles.model.iStruct = getInputStruct(handles.model);
handles.model.mStruct = getInputStructMex(handles.model);

compileAll(handles.model, handles.user_input);

% pre-set weights to 1, and all 2-step ADAPT options to step1
no_obs = length(handles.link.oxdi) + length(handles.link.ofdi);
handles.user_input.options.runADAPT.weight = ones(length(handles.data.idt), no_obs);
handles.user_input.options.runADAPT.labArray = handles.user_input.options.runADAPT.labA.*ones(1, length(handles.data.idt))';

handles.obsNames = {handles.data.fields([handles.link.oxdi handles.link.ofdi]).name};
handles.interpObsNames = {handles.data.fields([handles.link.oxdi handles.link.ofdi]).name};
handles.simObsNames = {};
handles.interpObsIndex = 1:length([handles.link.oxdi handles.link.ofdi]);
handles.simObsIndex  = [];

handles.parNames = {handles.model.parameters.name};

handles.parStep1Names = {handles.model.parameters.name};
handles.parStep2Names = {};
handles.obsStep1Names = {handles.data.fields([handles.link.oxdi handles.link.ofdi]).name};
handles.obsStep2Names = {};
handles.parStep1Index = 1:length({handles.model.parameters.name});
handles.parStep2Index = [];
handles.obsStep1Index = 1:length({handles.data.fields([handles.link.oxdi handles.link.ofdi]).name});
handles.obsStep2Index = [];

set(handles.linkText, 'string', 'Link established!');
set(handles.linkText, 'ForegroundColor', 'k'); 

guidata(hObject, handles);

% CLEAR BUTTON, clears all results from result list

% --- Executes on button press in clearButton.
function clearButton_Callback(hObject, eventdata, handles)
% hObject    handle to clearButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

import AMF.*

handles.model = Model(handles.model.name, handles.user_input.useMEX);

parsePreLink(handles.model);

handles.model.iStruct = getInputStruct(handles.model);
handles.model.mStruct = getInputStructMex(handles.model);

compileAll(handles.model, handles.user_input);

set(handles.linkText, 'string', 'No Link established!');
set(handles.linkText, 'ForegroundColor', 'r'); 

handles.link = [];

guidata(hObject, handles);


% --- Executes on selection change in dataGroupListBox.
function dataGroupListBox_Callback(hObject, eventdata, handles)
% hObject    handle to dataGroupListBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns dataGroupListBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from dataGroupListBox


% --- Executes during object creation, after setting all properties.
function dataGroupListBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dataGroupListBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in useMexCheckBox.
function useMexCheckBox_Callback(hObject, eventdata, handles)
% hObject    handle to useMexCheckBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.user_input.useMEX = get(handles.useMexCheckBox, 'Value');

guidata(hObject, handles);


% --- Executes on button press in dataGroupButton.
function dataGroupButton_Callback(hObject, eventdata, handles)
% hObject    handle to dataGroupButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
import AMF.*

dataGroupNum = get(handles.dataGroupListBox, 'Value');
dataGroupName = handles.data.groups{dataGroupNum};

loadGroup(handles.data, dataGroupName)

% Set time, data and standard deviation
handles.data.time = getFitTime(handles.data);
[handles.data.dd, handles.data.ds] = getFitData(handles.data);

% Calculate interpolated data and standard deviation
handles.user_input.options.numTimeSteps = str2num(get(handles.timeStepsEditText, 'string'));

handles.data.idt = getInterpTime(handles.data, handles.user_input);

for comp = handles.data.fields
    
    smooth_edit = 3;

    xi = comp.src.time;
    
    if numel(xi)-1 < 1
        continue
    end

    epsilon = ((xi(end)-xi(1))/(numel(xi)-1))^3/16;
    p = 1/(1+epsilon * 10^(smooth_edit-3));

    comp.smooth =  p;
    
    handles.user_input.smoothness_eps(comp.index) = epsilon;
    handles.user_input.smoothness_h(comp.index) = 3;
end

handles.user_input.options.runADAPT.interpStyle = cell(1,length(handles.data.fields));
handles.user_input.options.runADAPT.interpStyle(:) = {'spline'};

[idd, ids] = getInterpData(handles.data, handles.data.idt, handles.user_input);
handles.data.idd = idd;
handles.data.ids = ids;

set(handles.currentDataGroupText, 'string', ['Current data group: ', dataGroupName]);
set(handles.currentDataGroupText, 'ForegroundColor', 'k');

set(handles.linkText, 'string', 'No link established!');
set(handles.linkText, 'ForegroundColor', 'r'); 

guidata(hObject, handles);

% BELOW ARE THE FUNCTIONS RELATED TO THE SIMULATE OPTIONS

% --- Executes on button press in simulateOptionsButton.
function simulateOptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to simulateOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcf);

% window creation
d = dialog('Position', [300 300 250 500], 'Name', 'Select simulation options');

% pre-processing
if handles.user_input.options.simulate.useData
    enabledOrNot = 'off';
else
    enabledOrNot = 'on';
end

results_info = {};
results_info_index = [];

for i = 1:length(handles.result_list)
    
    if strcmp(handles.result_list{i}(1).sim_type, 'fitParameters')
        
        temp_str = [handles.result_list{i}.sim_date ', model fit'];
        
        results_info{end+1} = temp_str;
        results_info_index = [results_info_index i];
    end
end

% window elements creation 
tbox1 = uicontrol('Parent', d, ...
    'Style', 'text', ...
    'Position', [30 110 210 40], ...
    'String', 'Select the upper and lower time span of the simulation');

chbox = uicontrol('Parent', d, ...
    'Style', 'checkbox', ...
    'Position', [30 200 210 40], ...
    'String', 'Use data', ...
    'Tag', 'chbox1', ...
    'Value', handles.user_input.options.simulate.useData, ...
    'Callback', @useDataForSimulation_callback);

chbox2 = uicontrol('Parent', d, ...
    'Style', 'checkbox', ...
    'Position', [30 170 210 40], ...
    'String', 'Use most recent fit parameters', ...
    'Enable', 'off', ...
    'Tag', 'chbox2', ...
    'Value', 0);

chbox3 = uicontrol('Parent', d, ...
    'Style', 'checkbox', ...
    'Position', [30 460 210 40], ...
    'String', 'Use previously calculated parameter set', ...
    'Tag', 'chbox3', ...
    'Value', handles.user_input.options.simulate.usePrevP); 
  
etxt2 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Position', [130 80 100 25], ...
    'Tag', 'edittxt2', ...
    'enable', enabledOrNot, ...
    'String', num2str(handles.user_input.options.simulate.timeSpan(end))); 

etxt1 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Position', [20 80 100 25], ...
    'Tag', 'edittxt1', ...
    'enable', enabledOrNot, ...
    'String', num2str(handles.user_input.options.simulate.timeSpan(1))); 

listbox1 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [30 250 200 200], ...
    'Tag', 'resultListBox', ...
    'String', results_info);
    
saveButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Save', ...
    'Callback', {@saveSimulateOptions_callback, handles, results_info_index}); 

closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);

function useDataForSimulation_callback(hObject, eventdata, handles)
h1 = findobj('Tag', 'edittxt1');
h2 = findobj('Tag', 'edittxt2');

if get(hObject, 'Value')
    set(h1, 'enable', 'off')
    set(h2, 'enable', 'off')
else
    set(h1, 'enable', 'on')
    set(h2, 'enable', 'on')
end

function saveSimulateOptions_callback(hObject, eventdata, handles, results_info_index)
handles = guidata(gcf);

h1 = findobj('Tag', 'edittxt1');
h2 = findobj('Tag', 'edittxt2');
h3 = findobj('Tag', 'chbox1');
h4 = findobj('Tag', 'chbox3');
h5 = findobj('Tag', 'resultListBox');

handles.user_input.options.simulate.timeSpan = [str2num(h1.String) : str2num(h2.String)];
handles.user_input.options.simulate.useData  = h3.Value;

handles.user_input.options.simulate.usePrevP = h4.Value;

if h4.Value
    result_ind = results_info_index(h5.Value);
    
    result = handles.result_list{result_ind};
    
    pest = result.pest;
    p0 = result.p0;
    
    pidx = result.user_input.pidx;
    
    prevP = p0;
    prevP(pidx) = pest;

    handles.user_input.options.simulate.prevP = prevP;
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

function closepopup_callback(hObject, eventdata)
    delete(gcf)

% BELOW ARE ALL FUNCTIONS RELATED TO THE ADAPT OPTIONS   
    
% --- Executes on button press in adaptOptionsButton.
function adaptOptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to adaptOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% guidata(gcf, handles);

% loading handles and pre-processing
handles = guidata(gcf); 

interpObsNames = handles.interpObsNames;
simObsNames = handles.simObsNames;

% window creation
handles.d = dialog('Position',[300 300 1200 400],'Name','Select ADAPT options', 'WindowStyle', 'normal');

% window elements creation

% text
txt1 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[175 280 100 25],...
    'String','Constant parameters');

% text
txt2 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[345 280 100 25],...
    'String','Fit parameters');

% text
txt3 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[515 280 100 25],...
    'String','Variable parameters');

% text
txt4 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[50 110 100 20],...
    'String','Number of iterations');

% edit box which lets the user set the number of ADAPT iterations
editbox1 = uicontrol('Parent', handles.d, ...
    'Style', 'edit', ...
    'Tag', 'iterEdit', ...
    'Position', [50 70 100 40], ...
    'String', num2str(handles.user_input.options.runADAPT.numIter));

% text
txt5 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[50 190 100 20],...
    'String','Lambda');

% edit box which lets the user set the lambda value (no effect in this
% version)
editbox2 = uicontrol('Parent', handles.d, ...
    'Style', 'edit', ...
    'Tag', 'lambdaEdit', ...
    'Position', [50 150 100 40], ...
    'String', num2str(handles.user_input.options.runADAPT.labAValue));

% text
txt6 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[50 270 100 20],...
    'String','Seed');

% edit box to set the randomization seed for the Monte Carlo sampling of
% data and parameters
editbox3 = uicontrol('Parent', handles.d, ...
    'Style', 'edit', ...
    'Tag', 'seedEdit', ...
    'Position', [50 230 100 40], ...
    'String', num2str(handles.user_input.options.runADAPT.seed));

% check box which when checked uses initial fitting based on total time
% span simulation
checkbox1 = uicontrol('Parent', handles.d, ...
    'Style', 'checkbox', ...
    'Tag', 'altFitCheckBox', ...
    'Position', [175 310 100 40], ...
    'Value', handles.user_input.options.runADAPT.useAltInitFit, ...
    'String', 'Use Alt Init Fit');

% text
txt7 = uicontrol('Parent',handles.d,...
    'Style','text',...
    'Position',[50 350 100 20],...
    'String','Lambda Power');

% edit box to set the exponential term in the regularization function
editbox4 = uicontrol('Parent', handles.d, ...
    'Style', 'edit', ...
    'Tag', 'lambdaPowerEdit', ...
    'Position', [50 310 100 40], ...
    'String', num2str(handles.user_input.options.runADAPT.labPower));

% listbox containing the constant parameters
listbox1 = uicontrol('Parent',handles.d,...
    'Style','listbox', ...
    'Tag', 'listbox1', ...
    'Position',[175 70 100 200],...
    'String', handles.parameterNames(handles.constantParameterIndex));

% listbox containing the fit parameters
listbox2 = uicontrol('Parent',handles.d,...
    'Style', 'listbox', ...
    'Tag', 'listbox2', ...
    'Position',[345 70 100 200],...
    'String', handles.parameterNames(handles.fitParameterIndex));

% listbox containing the time dependent parameters
listbox3 = uicontrol('Parent',handles.d,...
    'Style','listbox', ...
    'Tag', 'listbox3', ...
    'Position',[515 70 100 200],...
    'String', handles.parameterNames(handles.variableParameterIndex));

% pushbutton used to change constant parameter to a fit parameter
pushbut1 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [295 180 30 30], ...
    'String', '>', ...
    'Callback', @constantToFitButton_callback);

% pushbutton used to change fit parameter to a constant parameter
pushbut2 = uicontrol('Parent', handles.d, ... % setting parent
    'Style', 'pushbutton', ... % setting element type
    'Position', [295 140 30 30], ... % sets position
    'String', '<', ... % sets string
    'Callback', @fitToConstantButton_callback); % sets function to be called when button is pressed .... etc etc etc

pushbut3 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [465 140 30 30], ...
    'String', '<', ...
    'Callback', @variableToFitButton_callback);

pushbut4 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [465 180 30 30], ...
    'String', '>', ...
    'Callback', @fitToVariableButton_callback);

pushbut5 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [295 220 30 30], ...
    'String', '>>', ...
    'Callback', @constantToFitAllButton_callback);

pushbut6 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [295 100 30 30], ...
    'String', '<<', ...
    'Callback', @fitToConstantAllButton_callback);

pushbut7 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [465 100 30 30], ...
    'String', '<<', ...
    'Callback', @variableToFitAllButton_callback);

pushbut8 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [465 220 30 30], ...
    'String', '>>', ...
    'Callback', @fitToVariableAllButton_callback);

listbox4 = uicontrol('Parent', handles.d, ...
    'Style', 'listbox', ...
    'Position', [700 70 100 200], ...
    'Tag', 'interpListBox', ...
    'String', interpObsNames);

listbox5 = uicontrol('Parent', handles.d, ...
    'Style', 'listbox', ...
    'Position', [870 70 100 200], ...
    'Tag', 'simListBox', ...
    'String', simObsNames);

pushbut9 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [820 140 30 30], ...
    'String', '<', ...
    'Callback', @simToInterpButton_callback);

pushbut10 = uicontrol('Parent', handles.d, ...
    'Style', 'pushbutton', ...
    'Position', [820 180 30 30], ...
    'String', '>', ...
    'Callback', @interpToSimButton_callback);

lambdaButton = uicontrol('Parent', handles.d, ...
    'Position', [1100 70 50 25], ...
    'Style', 'pushbutton', ...
    'String', 'set Lambda', ...
    'callback', @setLambda);

weightButton = uicontrol('Parent', handles.d, ...
    'Position', [1100 120 50 25], ...
    'Style', 'pushbutton', ...
    'String', 'set weights', ...
    'callback', @setWeights);

stepButton = uicontrol('Parent', handles.d, ...
    'Position', [1100 170 50 25], ...
    'Style', 'pushbutton', ...
    'String', 'set steps', ...
    'callback', @setSteps);

saveButton = uicontrol('Parent',handles.d,...
    'Position',[50 20 70 25],...
    'String','Save',...
    'Callback',{@saveAdaptOptions_callback, handles}); 

closeButton = uicontrol('Parent', handles.d,...
    'Position',[140 20 70 25],...
    'String', 'Close',...
    'Callback',@closepopup_callback);

% align([saveButton closeButton], 'distribute', 'bottom');

guidata(gcf, handles);

function interpToSimButton_callback(hObject, eventdata, handles)
% gets handles structure
handles = guidata(gcf);

% loads data from listboxes setting the "simulation as interpolation"
% method
h1 = findobj('Tag', 'interpListBox');
h2 = findobj('Tag', 'simListBox');

% load currently selected observable
selectedParNum = h1.Value;

% find observable name and find observable index
temp_str = handles.interpObsNames(selectedParNum);
temp_par_num = find(strcmp(handles.obsNames, temp_str));

% add observable index to index list with "sim" observables and delete it
% from "interp" observables
handles.simObsIndex = [handles.simObsIndex temp_par_num];
handles.interpObsIndex = handles.interpObsIndex(handles.interpObsIndex ~= temp_par_num);

% sort lists
handles.simObsIndex = sort(handles.simObsIndex);
handles.interpObsIndex = sort(handles.interpObsIndex);

% refresh "sim" and "interp" names
handles.simObsNames = handles.obsNames(handles.simObsIndex);
handles.interpObsNames = handles.obsNames(handles.interpObsIndex);

% set selected observable back to first in list
h1.Value = 1;

% update string of lists
if isempty(handles.interpObsIndex)
    h2.String = handles.obsNames(handles.simObsIndex);
    h1.String = 'no observables selected'; % set string to default when no observables are left in list
else
    h2.String = handles.obsNames(handles.simObsIndex);
    h1.String = handles.obsNames(handles.interpObsIndex);
end

% update ADAPT options
handles.user_input.options.runADAPT.simAsInterpList = handles.simObsNames;

% save handles structure to parent and main GUI
guidata(gcf, handles);
guidata(handles.figure1, handles);

function simToInterpButton_callback(hObject, eventdata, handles)
% data loading
handles = guidata(gcf);

h1 = findobj('Tag', 'interpListBox');
h2 = findobj('Tag', 'simListBox');

selectedParNum = h2.Value;

% processing changes
temp_str = handles.simObsNames(selectedParNum);
temp_par_num = find(strcmp(handles.obsNames, temp_str));

handles.interpObsIndex = [handles.interpObsIndex temp_par_num];
handles.simObsIndex = handles.simObsIndex(handles.simObsIndex ~= temp_par_num);

handles.simObsIndex = sort(handles.simObsIndex);
handles.interpObsIndex = sort(handles.interpObsIndex);

handles.simObsNames = handles.obsNames(handles.simObsIndex);
handles.interpObsNames = handles.obsNames(handles.interpObsIndex);

% updating lists
h2.Value = 1;

if isempty(handles.simObsIndex)
    h1.String = handles.obsNames(handles.interpObsIndex);
    h2.String = 'no observables selected';
else
    h2.String = handles.obsNames(handles.simObsIndex);
    h1.String = handles.obsNames(handles.interpObsIndex);
end

handles.user_input.options.runADAPT.simAsInterpList = handles.simObsNames;

% saving handles to parent and GUI window
guidata(gcf, handles);
guidata(handles.figure1, handles);

% --------------------------------------------
% BELOW ARE ALL ADAPT LAMBDA RELATED FUNCTIONS
% --------------------------------------------

function setLambda(hObject, eventdata, handles)
% SET LAMBDA OF PARAMETERS WHILE COMPARING TO DATA, INTERPOLATION AND INPUTS

handles = guidata(gcf);

obs_names = {handles.data.fields([handles.link.oxdi, handles.link.ofdi]).name};
input_names = {handles.model.inputs.name};
par_names = {handles.model.parameters.name};

cur_id = handles.data.ref.(obs_names{1}).index;
cur_inp_id = handles.data.ref.(input_names{1}).index;
cur_par_id = 1;

d = dialog('Position', [300 300 800 500], 'Name', 'Customize lambda values');

% Axes to show data points and interpolated data
ax1 = axes('Parent',d,'Units','pixels','Position',[200 200 250 250], 'Tag', 'obsAx');

xi = handles.data.ref.(obs_names{1}).src.time;    
yi = handles.data.ref.(obs_names{1}).src.val;

xxi = handles.data.idt;
yy = handles.data.idd(:, cur_id);

yyaxis left
plot(xi,yi,'x')
hold on
plot(xxi,yy)
hold off

yyaxis right
plot(xxi, handles.user_input.options.runADAPT.labArray(:, cur_par_id))

% Axes to show inputs
ax2 = axes('Parent',d,'Units','pixels','Position',[500 200 250 250], 'Tag', 'inpAx');

xi_input = handles.data.ref.(input_names{1}).src.time;     
yi_input = handles.data.ref.(input_names{1}).src.val;

xxi_input = handles.data.idt;
yy_input = handles.data.idd(:, cur_inp_id);

yyaxis left
plot(xi_input,yi_input,'--')
yyaxis right
plot(xxi, handles.user_input.options.runADAPT.labArray(:, cur_par_id))


% Dropdown box to select observable data 
popup = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'lambdaObsPopUp', ...
    'Position', [30 430 100 25], ...
    'String', obs_names, ...
    'Callback', @setLambdaObs_callback);

popup2 = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'lambdaInputPopUp', ...
    'Position', [30 330 100 25], ...
    'String', input_names, ...
    'Callback', @setLambdaInputs_callback); 

popup3 = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'lambdaParameterPopUp', ...
    'Position', [30 380 100 25], ...
    'String', par_names, ...
    'Callback', @setLambdaParameters_callback); 

edit1 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'lambdaValueEdit', ...
    'Position', [200 120 70 25], ...
    'String', '0.1');

edit2 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'lambdaTime1Edit', ...
    'Position', [300 120 70 25], ...
    'String', '0');

edit3 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'lambdaTime2Edit', ...
    'Position', [400 120 70 25], ...
    'String', '100');

setWeight = uicontrol('Parent', d, ...
    'Position', [200 70 70 25], ...
    'String', 'Set lambda', ...
    'Callback', @setLambda_callback);

setWeightAll = uicontrol('Parent', d, ...
    'Position', [300 70 70 25], ...
    'String', 'Copy to all', ...
    'Callback', @copyLambdaToAll_callback);

% Save button that saves smoothness of current observable data
saveButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Save', ...
    'Callback', @saveLambda_callback); 

% Close button
closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);
guidata(handles.figure1, handles);

function saveLambda_callback(hObject, eventdata, handles)

handles = guidata(gcf);

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function setLambdaObs_callback(hObject, eventdata, handles)
handles = guidata(gcf);

left_axes = findobj('Tag', 'obsAx');

cur_id = handles.data.ref.(hObject.String{hObject.Value}).index;

xi = handles.data.ref.(hObject.String{hObject.Value}).src.time;     
yi = handles.data.ref.(hObject.String{hObject.Value}).src.val;

xxi = handles.data.idt;
yy = handles.data.idd(:, cur_id);

axes(left_axes)

yyaxis left
plot(xi, yi, 'x')
hold on
plot(xxi, yy, '-')
hold off

guidata(gcf, handles);
guidata(handles.figure1, handles);

function setLambdaParameters_callback(hObject, eventdata, handles)
handles = guidata(gcf);

left_axes = findobj('Tag', 'obsAx');
right_axes = findobj('Tag', 'inpAx');

cur_id = hObject.Value;

axes(left_axes)

yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.labArray(:, cur_id));

axes(right_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.labArray(:, cur_id));

guidata(gcf, handles);
guidata(handles.figure1, handles);

function setLambdaInputs_callback(hObject, eventdata, handles)
handles = guidata(gcf);
right_axes = findobj('Tag', 'inpAx');

xi_input = handles.data.ref.(hObject.String{hObject.Value}).src.time;    
yi_input = handles.data.ref.(hObject.String{hObject.Value}).src.val;

axes(right_axes)

yyaxis left
plot(xi_input, yi_input, '-')

guidata(gcf, handles);
guidata(handles.figure1, handles);

function setLambda_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'lambdaParameterPopUp');
h2 = findobj('Tag', 'lambdaValueEdit');
h3 = findobj('Tag', 'lambdaTime1Edit');
h4 = findobj('Tag', 'lambdaTime2Edit');

cur_id = h1.Value;
val = str2num(h2.String);
t1 = str2num(h3.String);
t2 = str2num(h4.String);

handles.user_input.options.runADAPT.labArray(t1:t2, cur_id) = val;

left_axes = findobj('Tag', 'obsAx');
right_axes = findobj('Tag', 'inpAx');

axes(left_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.labArray(:, cur_id));

axes(right_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.labArray(:, cur_id));

guidata(gcf, handles);
guidata(handles.figure1, handles);

function copyLambdaToAll_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'lambdaParameterPopUp');
cur_id = h1.Value;

for i = 1:size(handles.user_input.options.runADAPT.labArray, 2)
    handles.user_input.options.runADAPT.labArray(:, i) = handles.user_input.options.runADAPT.labArray(:, cur_id);
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

% --------------------------------------------
% BELOW ARE ALL ADAPT WEIGHT RELATED FUNCTIONS
% --------------------------------------------

function setWeights(hObject, eventdata, handles)

% SET WEIGHTS OF OBSERVABLE WHILE COMPARING TO RESPECTIVE DATA, INTERPOLATION AND INPUTS

handles = guidata(gcf);

obs_names = {handles.data.fields([handles.link.oxdi, handles.link.ofdi]).name};
input_names = {handles.model.inputs.name};

cur_id = handles.data.ref.(obs_names{1}).index;
cur_inp_id = handles.data.ref.(input_names{1}).index;

d = dialog('Position', [300 300 800 500], 'Name', 'Customize weight values', 'WindowStyle', 'normal');

% Axes to show data points and interpolated data
ax1 = axes('Parent',d,'Units','pixels','Position',[200 200 250 250], 'Tag', 'obsAx');

xi = handles.data.ref.(obs_names{1}).src.time;     
yi = handles.data.ref.(obs_names{1}).src.val;

xxi = handles.data.idt;
yy = handles.data.idd(:, cur_id);

yyaxis left
plot(xi,yi,'x')
hold on
plot(xxi,yy)
hold off

yyaxis right
plot(xxi, handles.user_input.options.runADAPT.weight(:, cur_id))

% Axes to show inputs
ax2 = axes('Parent',d,'Units','pixels','Position',[500 200 250 250], 'Tag', 'inpAx');

xi_input = handles.data.ref.(input_names{1}).src.time;     % fields(idx).src.time;
yi_input = handles.data.ref.(input_names{1}).src.val;

xxi_input = handles.data.idt;
yy_input = handles.data.idd(:, cur_inp_id);

yyaxis left
plot(xi_input,yi_input,'--')
yyaxis right
plot(xxi, handles.user_input.options.runADAPT.weight(:, cur_id))

% Dropdown box to select observable data 
popup = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'weightObsPopUp', ...
    'Position', [30 430 100 25], ...
    'String', obs_names, ...
    'Callback', @setWeightObs_callback);

popup2 = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'weightInputPopUp', ...
    'Position', [30 330 110 25], ...
    'String', input_names, ...
    'Callback', @setWeightInputs_callback); 

edit1 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'weightValueEdit', ...
    'Position', [200 120 70 25], ...
    'String', '1');

edit2 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'weightTime1Edit', ...
    'Position', [300 120 70 25], ...
    'String', '0');

edit3 = uicontrol('Parent', d, ...
    'Style', 'edit', ...
    'Tag', 'weightTime2Edit', ...
    'Position', [400 120 70 25], ...
    'String', '100');

setWeight = uicontrol('Parent', d, ...
    'Position', [200 70 70 25], ...
    'String', 'Set weight', ...
    'Callback', @setWeight_callback);

setWeightAll = uicontrol('Parent', d, ...
    'Position', [300 70 70 25], ...
    'String', 'Copy to all', ...
    'Callback', @copyWeightToAll_callback);

% Save button that saves smoothness of current observable data
saveButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Save', ...
    'Callback', @saveWeights_callback); 

% Close button
closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

% redundant, but needed to save to respective figure handles
guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function saveWeights_callback(hObject, eventdata, handles)
handles = guidata(gcf);

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function setWeightObs_callback(hObject, eventdata, handles)
handles = guidata(gcf);

left_axes = findobj('Tag', 'obsAx');
right_axes = findobj('Tag', 'inpAx');

cur_id = handles.data.ref.(hObject.String{hObject.Value}).index;

xi = handles.data.ref.(hObject.String{hObject.Value}).src.time;     
yi = handles.data.ref.(hObject.String{hObject.Value}).src.val;

xxi = handles.data.idt;
yy = handles.data.idd(:, cur_id);

axes(left_axes)

yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.weight(:, cur_id));

yyaxis left
plot(xi, yi, 'x')
hold on
plot(xxi, yy, '-')
hold off

axes(right_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.weight(:, cur_id));

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function setWeightInputs_callback(hObject, eventdata, handles)
handles = guidata(gcf);
right_axes = findobj('Tag', 'inpAx');

xi_input = handles.data.ref.(hObject.String{hObject.Value}).src.time;     % fields(idx).src.time;
yi_input = handles.data.ref.(hObject.String{hObject.Value}).src.val;

axes(right_axes)

yyaxis left
plot(xi_input, yi_input, '--')

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function setWeight_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'weightObsPopUp');
h2 = findobj('Tag', 'weightValueEdit');
h3 = findobj('Tag', 'weightTime1Edit');
h4 = findobj('Tag', 'weightTime2Edit');

cur_id = handles.data.ref.(h1.String{h1.Value}).index;
val = str2num(h2.String);
t1 = str2num(h3.String);
t2 = str2num(h4.String);

handles.user_input.options.runADAPT.weight(t1:t2, cur_id) = val;

left_axes = findobj('Tag', 'obsAx');
right_axes = findobj('Tag', 'inpAx');

axes(left_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.weight(:, cur_id));

axes(right_axes)
yyaxis right
plot(handles.data.idt, handles.user_input.options.runADAPT.weight(:, cur_id));

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function copyWeightToAll_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'weightObsPopUp');
cur_id = handles.data.ref.(h1.String{h1.Value}).index;

for i = 1:size(handles.user_input.options.runADAPT.weight, 2)
    handles.user_input.options.runADAPT.weight(:, i) = handles.user_input.options.runADAPT.weight(:, cur_id);
end

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

% BELOW ARE ALL FUNCTIONS RELATED TO SETTING THE POSSIBLE SECOND STEP IN
% THE ADAPT ALGORITHM. Currently it is not advisable to use this function
% due to poor performance!

function setSteps(hObject, eventdata, handles)
handles = guidata(gcf);

d = dialog('Position',[400 400 400 550],'Name','Select steps');

listbox1 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [100 320 100 200], ...
    'Tag', 'obsStep1ListBox', ... 
    'String', handles.obsStep1Names);

listbox2 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [270 320 100 200], ...
    'Tag', 'obsStep2ListBox', ...
    'String', handles.obsStep2Names);

pushbut1 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [220 390 30 30], ...
    'String', '<', ...
    'Callback', @obsStep2to1Button_callback);

pushbut2 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [220 430 30 30], ...
    'String', '>', ...
    'Callback', @obsStep1to2Button_callback);

listbox3 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [100 70 100 200], ...
    'Tag', 'parStep1ListBox', ...
    'String', handles.parStep1Names);

listbox4 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [270 70 100 200], ...
    'Tag', 'parStep2ListBox', ...
    'String', handles.parStep2Names);

pushbut3 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [220 140 30 30], ...
    'String', '<', ...
    'Callback', @parStep2to1Button_callback);

pushbut4 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [220 180 30 30], ...
    'String', '>', ...
    'Callback', @parStep1to2Button_callback);

saveButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Save', ...
    'Callback', @saveSteps_callback); 

guidata(gcf, handles);
guidata(handles.figure1, handles);

function saveSteps_callback(hObject, eventdata, handles)
handles = guidata(gcf);

oxdi_step1 = [];
ofdi_step1 = [];
oxmi_step1 = [];
ofmi_step1 = [];

for obs = handles.obsStep1Names
    if isa(handles.model.ref.(obs{1}), 'AMF.ModelState')
        oxdi_step1 = [oxdi_step1 handles.data.ref.(obs{1}).index];
        oxmi_step1 = [oxmi_step1 handles.model.ref.(obs{1}).index];
    elseif isa(handles.model.ref.(obs{1}), 'AMF.ModelReaction')
        ofdi_step1 = [ofdi_step1 handles.data.ref.(obs{1}).index];
        ofmi_step1 = [ofmi_step1 handles.model.ref.(obs{1}).index];
    end
end   

handles.user_input.options.runADAPT.oxdi_step1 = oxdi_step1;
handles.user_input.options.runADAPT.ofdi_step1 = ofdi_step1;
handles.user_input.options.runADAPT.oxmi_step1 = oxmi_step1;
handles.user_input.options.runADAPT.ofmi_step1 = ofmi_step1;
handles.user_input.options.runADAPT.traj_step1 = handles.parStep1Index;
handles.user_input.options.runADAPT.traj_step2 = handles.parStep2Index;

guidata(handles.d, handles);
guidata(gcf, handles);
guidata(handles.figure1, handles);

function obsStep2to1Button_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'obsStep1ListBox');
h2 = findobj('Tag', 'obsStep2ListBox');

selectedObsNum = h2.Value;

temp_str = handles.obsStep2Names(selectedObsNum);
temp_obs_num = find(strcmp(handles.obsNames, temp_str));

handles.obsStep1Index = [handles.obsStep1Index temp_obs_num];
handles.obsStep2Index = handles.obsStep2Index(handles.obsStep2Index ~= temp_obs_num);

handles.obsStep1Index = sort(handles.obsStep1Index);
handles.obsStep2Index = sort(handles.obsStep2Index);

handles.obsStep1Names = handles.obsNames(handles.obsStep1Index);
handles.obsStep2Names = handles.obsNames(handles.obsStep2Index);

h2.Value = 1;

if isempty(handles.obsStep2Index)
    h1.String = handles.obsNames(handles.obsStep1Index);
    h2.String = 'no observables selected';
else
    h2.String = handles.obsNames(handles.obsStep2Index);
    h1.String = handles.obsNames(handles.obsStep1Index);
end

handles.user_input.options.runADAPT.obsStep1Names = handles.obsStep1Names;
handles.user_input.options.runADAPT.obsStep2Names = handles.obsStep2Names;

guidata(gcf, handles);
guidata(handles.figure1, handles);

function obsStep1to2Button_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'obsStep1ListBox');
h2 = findobj('Tag', 'obsStep2ListBox');

selectedObsNum = h1.Value;

temp_str = handles.obsStep1Names(selectedObsNum);
temp_obs_num = find(strcmp(handles.obsNames, temp_str));

handles.obsStep2Index = [handles.obsStep2Index temp_obs_num];
handles.obsStep1Index = handles.obsStep1Index(handles.obsStep1Index ~= temp_obs_num);

handles.obsStep1Index = sort(handles.obsStep1Index);
handles.obsStep2Index = sort(handles.obsStep2Index);

handles.obsStep1Names = handles.obsNames(handles.obsStep1Index);
handles.obsStep2Names = handles.obsNames(handles.obsStep2Index);

h1.Value = 1;

if isempty(handles.obsStep1Index)
    h2.String = handles.obsNames(handles.obsStep2Index);
    h1.String = 'no observables selected';
else
    h2.String = handles.obsNames(handles.obsStep2Index);
    h1.String = handles.obsNames(handles.obsStep1Index);
end

handles.user_input.options.runADAPT.obsStep1Names = handles.obsStep1Names;
handles.user_input.options.runADAPT.obsStep2Names = handles.obsStep2Names;

guidata(gcf, handles);
guidata(handles.figure1, handles);

function parStep2to1Button_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'parStep1ListBox');
h2 = findobj('Tag', 'parStep2ListBox');

selectedParNum = h2.Value;

temp_str = handles.parStep2Names(selectedParNum);
temp_par_num = find(strcmp(handles.parNames, temp_str));

handles.parStep1Index = [handles.parStep1Index temp_par_num];
handles.parStep2Index = handles.parStep2Index(handles.parStep2Index ~= temp_par_num);

handles.parStep1Index = sort(handles.parStep1Index);
handles.parStep2Index = sort(handles.parStep2Index);

handles.parStep1Names = handles.parNames(handles.parStep1Index);
handles.parStep2Names = handles.parNames(handles.parStep2Index);

h2.Value = 1;

if isempty(handles.parStep2Index)
    h1.String = handles.parNames(handles.parStep1Index);
    h2.String = 'no parameters selected';
else
    h2.String = handles.parNames(handles.parStep2Index);
    h1.String = handles.parNames(handles.parStep1Index);
end

handles.user_input.options.runADAPT.parStep1Names = handles.parStep1Names;
handles.user_input.options.runADAPT.parStep2Names = handles.parStep2Names;

guidata(gcf, handles);
guidata(handles.figure1, handles);

function parStep1to2Button_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'parStep1ListBox');
h2 = findobj('Tag', 'parStep2ListBox');

selectedParNum = h1.Value;

temp_str = handles.parStep1Names(selectedParNum);
temp_par_num = find(strcmp(handles.parNames, temp_str));

handles.parStep2Index = [handles.parStep2Index temp_par_num];
handles.parStep1Index = handles.parStep1Index(handles.parStep1Index ~= temp_par_num);

handles.parStep1Index = sort(handles.parStep1Index);
handles.parStep2Index = sort(handles.parStep2Index);

handles.parStep1Names = handles.parNames(handles.parStep1Index);
handles.parStep2Names = handles.parNames(handles.parStep2Index);

h1.Value = 1;

if isempty(handles.parStep1Index)
    h2.String = handles.parNames(handles.parStep2Index);
    h1.String = 'no parameters selected';
else
    h2.String = handles.parNames(handles.parStep2Index);
    h1.String = handles.parNames(handles.parStep1Index);
end

handles.user_input.options.runADAPT.parStep1Names = handles.parStep1Names;
handles.user_input.options.runADAPT.parStep2Names = handles.parStep2Names;

guidata(gcf, handles);
guidata(handles.figure1, handles);

% BELOW ARE ALL THE FUNCTIONS THAT CHANGE THE PARAMETER SETTINGS

% The following function structures repeat multiple times throughout the
% code. General idea: Obtain selected index -> obtain corresponding name -> 
% set name to correct list -> remove name from old list -> update lists and
% indices

function constantToFitButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'listbox1');
h2 = findobj('Tag', 'listbox2');

selectedParNum = h1.Value;

temp_str = handles.constantParameterNames(selectedParNum);
temp_par_num = find(strcmp(handles.parameterNames, temp_str));

handles.fitParameterIndex = [handles.fitParameterIndex temp_par_num];
handles.constantParameterIndex = handles.constantParameterIndex(handles.constantParameterIndex ~= temp_par_num);

handles.fitParameterIndex = sort(handles.fitParameterIndex);
handles.constantParameterIndex = sort(handles.constantParameterIndex);

handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
handles.constantParameterNames = handles.parameterNames(handles.constantParameterIndex);

h1.Value = 1;

if isempty(handles.constantParameterIndex)
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h1.String = 'no parameter selected';
else
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h1.String = handles.parameterNames(handles.constantParameterIndex);
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

    
function fitToConstantButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'listbox1');
h2 = findobj('Tag', 'listbox2');

selectedParNum = h2.Value;

temp_str = handles.fitParameterNames(selectedParNum);
temp_par_num = find(strcmp(handles.parameterNames, temp_str));

handles.constantParameterIndex = [handles.constantParameterIndex temp_par_num];
handles.fitParameterIndex = handles.fitParameterIndex(handles.fitParameterIndex ~= temp_par_num);

handles.fitParameterIndex = sort(handles.fitParameterIndex);
handles.constantParameterIndex = sort(handles.constantParameterIndex);

handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
handles.constantParameterNames = handles.parameterNames(handles.constantParameterIndex);

h2.Value = 1;

if isempty(handles.fitParameterIndex)
    h1.String = handles.parameterNames(handles.constantParameterIndex);
    h2.String = 'no parameter selected';
else
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h1.String = handles.parameterNames(handles.constantParameterIndex);
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

function variableToFitButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h3 = findobj('Tag', 'listbox3');
h2 = findobj('Tag', 'listbox2');

selectedParNum = h3.Value;

temp_str = handles.variableParameterNames(selectedParNum);
temp_par_num = find(strcmp(handles.parameterNames, temp_str));

handles.fitParameterIndex = [handles.fitParameterIndex temp_par_num];
handles.variableParameterIndex = handles.variableParameterIndex(handles.variableParameterIndex ~= temp_par_num);

handles.fitParameterIndex = sort(handles.fitParameterIndex);
handles.variableParameterIndex = sort(handles.variableParameterIndex);

handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
handles.variableParameterNames = handles.parameterNames(handles.variableParameterIndex);

h3.Value = 1;

if isempty(handles.variableParameterIndex)
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h3.String = 'no parameter selected';
else
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h3.String = handles.parameterNames(handles.variableParameterIndex);
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

function fitToVariableButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h3 = findobj('Tag', 'listbox3');
h2 = findobj('Tag', 'listbox2');

selectedParNum = h2.Value;

temp_str = handles.fitParameterNames(selectedParNum);
temp_par_num = find(strcmp(handles.parameterNames, temp_str));

handles.variableParameterIndex = [handles.variableParameterIndex temp_par_num];
handles.fitParameterIndex = handles.fitParameterIndex(handles.fitParameterIndex ~= temp_par_num);

handles.fitParameterIndex = sort(handles.fitParameterIndex);
handles.variableParameterIndex = sort(handles.variableParameterIndex);

handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
handles.variableParameterNames = handles.parameterNames(handles.variableParameterIndex);

h2.Value = 1;

if isempty(handles.fitParameterIndex)
    h3.String = handles.parameterNames(handles.variableParameterIndex);
    h2.String = 'no parameter selected';
else
    h2.String = handles.parameterNames(handles.fitParameterIndex);
    h3.String = handles.parameterNames(handles.variableParameterIndex);
end

guidata(gcf, handles);
guidata(handles.figure1, handles);

function constantToFitAllButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'listbox1');
h2 = findobj('Tag', 'listbox2');

for pName = handles.constantParameterNames
    temp_par_num = find(strcmp(handles.parameterNames, pName));

    handles.fitParameterIndex = sort([handles.fitParameterIndex temp_par_num]);
    handles.constantParameterIndex = sort(handles.constantParameterIndex(handles.constantParameterIndex ~= temp_par_num));
    
    handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
    handles.constantParameterNames = handles.parameterNames(handles.constantParameterIndex);
end

h1.Value = 1;

h2.String = handles.parameterNames(handles.fitParameterIndex);
h1.String = 'no parameter selected';

guidata(gcf, handles);
guidata(handles.figure1, handles);

    
function fitToConstantAllButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'listbox1');
h2 = findobj('Tag', 'listbox2');

for pName = handles.fitParameterNames
    temp_par_num = find(strcmp(handles.parameterNames, pName));

    handles.constantParameterIndex = sort([handles.constantParameterIndex temp_par_num]);
    handles.fitParameterIndex = sort(handles.fitParameterIndex(handles.fitParameterIndex ~= temp_par_num)); % Do I need sort? Don't think so.
    
    handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
    handles.constantParameterNames = handles.parameterNames(handles.constantParameterIndex);
end

h1.Value = 1;

h2.String = 'no parameter selected';
h1.String = handles.parameterNames(handles.constantParameterIndex);

guidata(gcf, handles);
guidata(handles.figure1, handles);


function variableToFitAllButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h3 = findobj('Tag', 'listbox3');
h2 = findobj('Tag', 'listbox2');

for pName = handles.variableParameterNames
    temp_par_num = find(strcmp(handles.parameterNames, pName));

    handles.fitParameterIndex = sort([handles.fitParameterIndex temp_par_num]);
    handles.variableParameterIndex = sort(handles.variableParameterIndex(handles.variableParameterIndex ~= temp_par_num));
    
    handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
    handles.variableParameterNames = handles.parameterNames(handles.variableParameterIndex);
end

h3.Value = 1;

h2.String = handles.parameterNames(handles.fitParameterIndex);
h3.String = 'no parameter selected';

guidata(gcf, handles);
guidata(handles.figure1, handles);


function fitToVariableAllButton_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h3 = findobj('Tag', 'listbox3');
h2 = findobj('Tag', 'listbox2');

for pName = handles.fitParameterNames
    temp_par_num = find(strcmp(handles.parameterNames, pName));

    handles.variableParameterIndex = sort([handles.variableParameterIndex temp_par_num]);
    handles.fitParameterIndex = sort(handles.fitParameterIndex(handles.fitParameterIndex ~= temp_par_num)); % Do I need sort? Don't think so.
    
    handles.fitParameterNames = handles.parameterNames(handles.fitParameterIndex);
    handles.variableParameterNames = handles.parameterNames(handles.variableParameterIndex);
end

h2.Value = 1;

h2.String = 'no parameter selected';
h3.String = handles.parameterNames(handles.variableParameterIndex);

guidata(gcf, handles);
guidata(handles.figure1, handles);

% saves all ADAPT options

function saveAdaptOptions_callback(hObject, eventdata, handles)
handles = guidata(gcf);

seed = findobj('Tag', 'seedEdit');
iter = findobj('Tag', 'iterEdit');
lamb = findobj('Tag', 'lambdaEdit');
altFit = findobj('Tag', 'altFitCheckBox');
labPower = findobj('Tag', 'lambdaPowerEdit');

handles.user_input.options.runADAPT.seed = str2num(seed.String);
handles.user_input.options.runADAPT.numIter = str2num(iter.String);
handles.user_input.options.runADAPT.labAValue = str2num(lamb.String); % has no effect in current version
handles.user_input.options.runADAPT.useAltInitFit = altFit.Value; 
handles.user_input.options.runADAPT.labPower = str2num(labPower.String);

handles.user_input.options.runADAPT.labA(:) = handles.user_input.options.runADAPT.labAValue;

guidata(handles.figure1, handles);

% Structure needed for PSA options. No extra options are available in
% current version

% --- Executes on button press in psaOptionsButton.
function psaOptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to psaOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcf);

d = dialog('Position',[300 300 250 150],'Name','Select One');

txt = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[20 80 210 40],...
    'String','No options to choose from at the moment!');

saveButton = uicontrol('Parent',d,...
    'Position',[89 20 70 25],...
    'String','Save',...
    'Enable', 'off', ...
    'Callback', @savePsaOptions_callback); 

closeButton = uicontrol('Parent', d,...
    'Position',[160 20 70 25],...
    'String', 'Close',...
    'Callback',@closepopup_callback);

guidata(gcf, handles);

function savePsaOptions_callback(hObject, eventdata, handles)
handles = guidata(gcf);

guidata(handles.figure1, handles);

% Structure needed for PLA options. Only parameter selection available at
% the moment. 

% --- Executes on button press in plaOptionsButton.
function plaOptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to plaOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcf);

d = dialog('Position',[300 300 250 150],'Name','Select PLA options');

txt = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[20 80 210 40],...
    'String','Select a parameter for the PLA');

popup = uicontrol('Parent',d,...
    'Style','popup',...
    'Position',[75 70 100 25],...
    'Tag', 'plaPopUp', ...
    'Value', handles.user_input.options.PLA.pNum, ...
    'String',{handles.model.parameters.name}); 

saveButton = uicontrol('Parent', d, ...
    'Position', [89 20 70 25], ...
    'String', 'Save', ...
    'Callback', @savePlaOptions_callback); 

closeButton = uicontrol('Parent', d, ...
    'Position', [160 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);

function savePlaOptions_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'plaPopUp');

idx = h1.Value;

handles.user_input.options.PLA.pNum = idx;

guidata(handles.figure1, handles);

% FIT OPTIONS, overlaps with parameter fit options in ADAPT options, thus
% also the "traj" options

% --- Executes on button press in fitOptionsButton.
function fitOptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to fitOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcf);

d = dialog('Position',[300 300 700 250],'Name','Select fitting options');

txt1 = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[75 180 100 40],...
    'String','Constant parameters');

txt2 = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[245 180 100 40],...
    'String','Fit parameters');

txt3 = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[415 180 100 40],...
    'String','Variable parameters');

listbox1 = uicontrol('Parent',d,...
    'Style','listbox', ...
    'Tag', 'listbox1', ...
    'Position',[75 70 100 100],...
    'String', handles.parameterNames(handles.constantParameterIndex));

listbox2 = uicontrol('Parent',d,...
    'Style', 'listbox', ...
    'Tag', 'listbox2', ...
    'Position',[245 70 100 100],...
    'String', handles.parameterNames(handles.fitParameterIndex));

listbox3 = uicontrol('Parent',d,...
    'Style','listbox', ...
    'Tag', 'listbox3', ...
    'Position',[415 70 100 100],...
    'String', handles.parameterNames(handles.variableParameterIndex));

pushbut1 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [195 140 30 30], ...
    'String', '>', ...
    'Callback', @constantToFitButton_callback);

pushbut2 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [195 100 30 30], ...
    'String', '<', ...
    'Callback', @fitToConstantButton_callback);

pushbut3 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [365 100 30 30], ...
    'String', '<', ...
    'Callback', @variableToFitButton_callback);

pushbut4 = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Position', [365 140 30 30], ...
    'String', '>', ...
    'Callback', @fitToVariableButton_callback);

saveButton = uicontrol('Parent',d,...
    'Position',[89 20 70 25],...
    'String','Save',...
    'Callback',@saveFitOptions_callback); 

closeButton = uicontrol('Parent', d,...
    'Position',[160 20 70 25],...
    'String', 'Close',...
    'Callback',@closepopup_callback);

txt4 = uicontrol('Parent',d,...
    'Style','text',...
    'Position',[300 20 300 25],...
    'String','NOTE: For model fitting purposes there is no difference between the "fit" or "variable" list!');

guidata(gcf, handles);



function saveFitOptions_callback(hObject, eventdata, handles)
handles = guidata(gcf);

guidata(handles.figure1, handles);


% --- Executes on button press in emptyButton.
function emptyButton_Callback(hObject, eventdata, handles)
% hObject    handle to emptyButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if ~handles.saved
    choice = questdlg('You have not saved your current results, are you sure you want to empty the current results?', ...
        'Continue emptying results?', ...
        'Yes','No','No');
    % Handle response
    switch choice
        case 'Yes'
            handles.result_list = {};
            
            fprintf('Result list has been emptied.\n')
            handles.saved = 1;
        case 'No'
            return
    end
else
    handles.result_list = {};
    
    fprintf('Result list has been emptied.\n')
    handles.saved = 1;
end

guidata(hObject, handles);

function smoothnessEdit_Callback(hObject, eventdata, handles)
% hObject    handle to smoothnessEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of smoothnessEdit as text
%        str2double(get(hObject,'String')) returns contents of smoothnessEdit as a double


% --- Executes during object creation, after setting all properties.
function smoothnessEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to smoothnessEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% USED TO INSPECT CURRENT HANDLES STRUCTURE

% --- Executes on button press in inspectButton.
function inspectButton_Callback(hObject, eventdata, handles)
% hObject    handle to inspectButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% This button directs you to the MFI code so you can view the handles
% structure in the workspace. 

answer = 42; % The answer!

assignin('base', 'handles', handles)

% Start of help function, can be easily expanded.

% --- Executes on button press in helpButton.
function helpButton_Callback(hObject, eventdata, handles)
% hObject    handle to helpButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

msgbox({'Below you can find a brief explanation of the different GUI components and how to use them. \n', ...
    '\n Select model: This button will open a window where you can select the model file you want to load.\n', ...
    'Select data: This button will open a window where you can select the data file you want to load.\n', ...
    'Load selected datagroup: Clicking here will load the data from the currently selected datagroup from the listbox above the button.'})

% FOLLOWING ARE FUNCTIONS TO PLOT RESULTS WITH INTERPOLATED DATA

% --- Executes on button press in variable0OptionsButton.
function variable0OptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to simulateOptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles = guidata(gcf);

d = dialog('Position', [300 300 250 500], 'Name', 'Select result to plot');

results_info = {};

for i = 1:length(handles.result_list)
    temp_str = [handles.result_list{i}(1).sim_type ',  ' handles.result_list{i}(1).sim_date];
    
    results_info{end+1} = temp_str;
end

listbox1 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [30 250 200 200], ...
    'Tag', 'resultListBox', ...
    'String', results_info);
    
plotButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Plot', ...
    'Callback', @PlotWithIDD); 

closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);

function PlotWithIDD(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'resultListBox');

result = handles.result_list{h1.Value};

model = result.model;
data = result.data;
link = result.link;
user_input = result.user_input;

no_obs_states = length(link.oxdi);

if no_obs_states > 0
    
    figure
    hold on
    
    no_it = user_input.options.runADAPT.numIter;
    
    for it = 1:no_it
        
        for x = 1:no_obs_states
            subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
            hold on
            
            cur_state = link.oxmi(x);
            cur_data = link.oxdi(x);
            
            plot(result(it).time, result(it).x(:, cur_state), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])
            plot(result(it).idt, result(it).idd(:, cur_data), 'color', [0, 1, 1])
            
            x1 = data.dd(:, cur_data);
            x2 = x1(~isnan(x1));
            t1 = data.time;
            t2 = t1(~isnan(x1));
            s1 = data.ds(:, cur_data);
            s2 = s1(~isnan(x1));
            s2(isnan(s2)) = 0;
            errorbar(t2,x2,s2,'ok')
            
            title(model.states(cur_state).name)
            xlabel('Time [-]')
            ylabel('Concentration')
        end
    end
end

% PLOT OBSERVABLE REACTIONS
no_obs_reactions = length(link.ofdi);

if no_obs_reactions > 0
    
    figure
    hold on
    
    for it = 1:no_it
        
        for v = 1:no_obs_reactions
            subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
            hold on
            
            cur_reaction = link.ofmi(v);
            cur_data = link.ofdi(v);
            
            plot(result(it).time, result(it).v(:, cur_reaction), 'color', [(0.5 + (it / no_it) * 0.5), 0, 0])
            plot(result(it).idt, result(it).idd(:, cur_data), 'color', [0, 1, 1])
            
            v1 = data.dd(:, cur_data);
            v2 = v1(~isnan(v1));
            t1 = data.time;
            t2 = t1(~isnan(v1));
            s1 = data.ds(:, cur_data);
            s2 = s1(~isnan(v1));
            s2(isnan(s2)) = 0;
            errorbar(t2,v2,s2,'ok')
            
            title(model.reactions(cur_reaction).name)
            xlabel('Time [-]')
            ylabel('Concentration')
        end
    end
end

% FOLLOWING FUNCTIONS ARE USED FOR SMOOTHNESS EVALUATION

% --- Executes on button press in variable1OptionsButton.
function variable1OptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to variable1OptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% SMOOTHNESS EVALUATION

for idx = handles.link.oxdi
    xi = handles.data.fields(idx).src.time;
    yi = handles.data.fields(idx).src.val;

    xxi = handles.data.idt;

    epsilon = ((xi(end)-xi(1))/(numel(xi)-1))^3/16
    p = 1/(1+epsilon)

    figure()
    plot(xi,yi,'x')
    hold on
    labels = cell(1,5);
    for j=1:5
       p = 1/(1+epsilon*10^(j-3));
       yy(j,:) = csaps(xi,yi,p,xxi);
       labels{j} = ['1-p= ',num2str(1-p)];
    end
    plot(xxi,yy)
    title(['Parameter: ' handles.data.fields(idx).name ', Smoothing Splines for different smoothness "p"'])
    legend( [{'Measured data'}, labels], 'Location', 'NorthWest' )
    hold off
end

for idx = handles.link.ofdi
    xi = handles.data.fields(idx).src.time;
    yi = handles.data.fields(idx).src.val;

    xxi = handles.data.idt;

    epsilon = ((xi(end)-xi(1))/(numel(xi)-1))^3/16
    p = 1/(1+epsilon)

    figure()
    plot(xi,yi,'x')
    hold on
    labels = cell(1,5);
    for j=1:5
       p = 1/(1+epsilon*10^(j-3));
       yy(j,:) = csaps(xi,yi,p,xxi);
       labels{j} = ['1-p= ',num2str(1-p)];
    end
    plot(xxi,yy)
    title(['Parameter: ' handles.data.fields(idx).name ', Smoothing Splines for different smoothness "p"'])
    legend( [{'Noisy'}, labels], 'Location', 'NorthWest' )
    hold off
end

% FOLLOWING FUNCTIONS ARE FOR THE INTERPOLATION CUSTOMIZATION

% --- Executes on button press in variable2OptionsButton.
function variable2OptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to variable2OptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% ADJUST SPLINE SMOOTHNESS
handles = guidata(gcf);

handles.user_input.smoothness_temp_h = handles.user_input.smoothness_h;

obs_names = {handles.data.fields([handles.link.oxdi, handles.link.ofdi]).name};

cur_id = handles.data.ref.(obs_names{1}).index;


d = dialog('Position', [300 300 500 500], 'Name', 'Customize interpolation options');

% Axes to show data points and interpolated data

ax = axes('Parent',d,'Units','pixels','Position',[200 200 250 250]);

xi = handles.data.ref.(obs_names{1}).src.time;    
yi = handles.data.ref.(obs_names{1}).src.val;

xxi = handles.data.idt;

epsilon = handles.user_input.smoothness_eps(cur_id);

plot(xi,yi,'x')
hold on
j = handles.user_input.smoothness_h(cur_id);

p = 1/(1+epsilon*10^(j-3));
yy = csaps(xi,yi,p,xxi);

plot(xxi,yy)
hold off
 
% Slider to adjust smoothness
S = uicontrol('Parent', d,...
                 'style','slide',...
                 'unit','pixel',...
                 'Tag', 'smoothnessSlider', ...
                 'position',[200 100 250 20],...
                 'min', 1, 'value', handles.user_input.smoothness_h(cur_id),'max',5,...
                 'callback', @sl_call);

% Dropdown box to select observable data 
popup = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'smoothnessPopUp', ...
    'Position', [30 430 100 25], ...
    'String', obs_names, ...
    'Callback', @popup_callback);

popup2 = uicontrol('Parent', d, ...
    'Style', 'popup', ...
    'Tag', 'interpMethodPopUp', ...
    'Position', [30 330 110 25], ...
    'String', {'Linear' 'Spline' 'Hermite' 'Auto'}, ...
    'Callback', @popup2_callback); 

% Save button that saves smoothness of current observable data
saveButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Save', ...
    'Callback', @saveSmoothness_callback); 

% Close button
closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

% Reset button

resetButton = uicontrol('Parent', d, ...
    'Position', [210 20 70 25], ...
    'String', 'Reset', ...
    'Callback', @resetSmoothness_callback);

guidata(gcf, handles);

function resetSmoothness_callback(hObject, eventdata, handles)

handles = guidata(gcf);

handles.user_input.smoothness_h = handles.user_input.smoothness_temp_h;

h1 = findobj('Tag', 'smoothnessPopUp');
h2 = findobj('Tag', 'smoothnessSlider');

cur_id = handles.data.ref.(h1.String{h1.Value}).index;

set(h2, 'Value', handles.user_input.smoothness_h(cur_id));

xi = handles.data.ref.(h1.String{h1.Value}).src.time;     
yi = handles.data.ref.(h1.String{h1.Value}).src.val;

xxi = handles.data.idt;

epsilon = handles.user_input.smoothness_eps(cur_id);

plot(xi,yi,'x')
hold on

j = h2.Value;

p = 1/(1+epsilon*10^(j-3));
yy = csaps(xi,yi,p,xxi);

plot(xxi,yy)

hold off

guidata(gcf, handles)
guidata(handles.figure1, handles)

function saveSmoothness_callback(hObject, eventdata, handles)

handles = guidata(gcf);

for i = 1:length(handles.data.fields)
    
    epsilon = handles.user_input.smoothness_eps(i);
    j = handles.user_input.smoothness_h(i);
    
    p = 1/(1+epsilon*10^(j-3));
    
    handles.data.fields(i).smooth = p;
end

[idd, ids] = getInterpData(handles.data, handles.data.idt, handles.user_input);
handles.data.idd = idd;
handles.data.ids = ids;

guidata(gcf, handles)
guidata(handles.figure1, handles)

function sl_call(hObject, eventdata, handles) 
% Callback for the slider.
handles = guidata(gcf);

h1 = findobj('Tag', 'smoothnessPopUp');

xi = handles.data.ref.(h1.String{h1.Value}).src.time;     % fields(idx).src.time;
yi = handles.data.ref.(h1.String{h1.Value}).src.val;

xxi = handles.data.idt;

cur_id = handles.data.ref.(h1.String{h1.Value}).index;

epsilon = handles.user_input.smoothness_eps(cur_id);

plot(xi,yi,'x')
hold on

j = hObject.Value;
handles.user_input.smoothness_h(cur_id) = j;

p = 1/(1+epsilon*10^(j-3));
    
handles.data.fields(cur_id).smooth = p;

field = handles.data.fields(cur_id);
[yy, ~] = interp(field, xxi, handles.user_input);

plot(xxi,yy)

hold off

% Calculate interpolated data with smoothness of slider
% Plot new interpolated graph in axes together with true data

guidata(gcf, handles)
guidata(handles.figure1, handles);

function popup_callback(hObject, eventdata, handles)
handles = guidata(gcf);

% Set data to be that of selected data
% Plot interpolated graph with smoothness of slider
xi = handles.data.ref.(hObject.String{hObject.Value}).src.time;     
yi = handles.data.ref.(hObject.String{hObject.Value}).src.val;

xxi = handles.data.idt;

cur_id = handles.data.ref.(hObject.String{hObject.Value}).index;

epsilon = handles.user_input.smoothness_eps(cur_id);


plot(xi,yi,'x')
hold on

j = handles.user_input.smoothness_h(cur_id);

p = 1/(1+epsilon*10^(j-3));

handles.data.fields(cur_id).smooth = p;

field = handles.data.fields(cur_id);
[yy, ~] = interp(field, xxi, handles.user_input);

plot(xxi,yy)
hold off

h1 = findobj('Tag', 'smoothnessSlider');

set(h1, 'Value', j);

guidata(gcf, handles)
guidata(handles.figure1, handles);

function popup2_callback(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'smoothnessPopUp');

% Set data to be that of selected data
% Plot interpolated graph with smoothness of slider
xi = handles.data.ref.(h1.String{h1.Value}).src.time;    
yi = handles.data.ref.(h1.String{h1.Value}).src.val;

xxi = handles.data.idt;

cur_id = handles.data.ref.(h1.String{h1.Value}).index;

epsilon = handles.user_input.smoothness_eps(cur_id);

% figure()
plot(xi,yi,'x')
hold on

field = handles.data.ref.(h1.String{h1.Value});

handles.user_input.options.runADAPT.interpStyle{field.index} = hObject.String{hObject.Value};

[yy, ~] = interp(field, xxi, handles.user_input);

plot(xxi,yy)

hold off

guidata(gcf, handles)
guidata(handles.figure1, handles);

% --- Executes on button press in variable3OptionsButton.
function variable3OptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to variable3OptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Change parameters and immediately see plot
handles = guidata(gcf);

model = handles.model;
data = handles.data;
user_input = handles.user_input;
link = handles.link;

results_info = {};
results_info_index = [];

for i = 1:length(handles.result_list)
    
    if strcmp(handles.result_list{i}(1).sim_type, 'fitParameters')
        
        temp_str = [handles.result_list{i}.sim_date ', model fit'];
        
        results_info{end+1} = temp_str;
        results_info_index = [results_info_index i];
    end
end

par_names = {model.parameters.name};

d = dialog('Position', [100 100 1750 1000], 'Name', 'Analyze parameters', 'WindowStyle', 'normal');

% Axes to show data points and interpolated data

handles.panel1 = uipanel('Parent',d,'Units','pixels','Position',[950 100 750 850]);

t = data.idt;
x0 = [model.states.init];
x0(link.oxi) = data.dd(1, link.oxdi);
p = [model.parameters.init];
handles.user_input.temp_p = p;
uvec = model.uvec;

x = computeStates(model, t, x0, p, uvec, user_input);
v = computeReactions(model, t, x, p, uvec);

oxi = find(handles.link.oxi);
ofi = find(handles.link.ofi);

dim = ceil(sqrt(length(handles.link.oxdi) + length(handles.link.ofdi)));

for n = 1 : length(handles.link.oxdi)
    
    x1 = handles.data.dd(:, handles.link.oxdi(n));
    x2 = x1(~isnan(x1));
    t1 = handles.data.time;
    t2 = t1(~isnan(x1));
    s1 = handles.data.ds(:, handles.link.oxdi(n));
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    
    subplot(dim, dim, n, 'Parent', handles.panel1)
    hold on
    plot(t, x(:, oxi(n)))
    errorbar(t2,x2,s2,'o')
    title(handles.model.states(handles.link.oxmi(n)).name)
    hold off
end

for m = 1 : length(handles.link.ofdi)
    
    x1 = handles.data.dd(:, handles.link.ofdi(m));
    x2 = x1(~isnan(x1));
    t1 = handles.data.time;
    t2 = t1(~isnan(x1));
    s1 = handles.data.ds(:, handles.link.ofdi(m));
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    
    subplot(dim, dim, m+n, 'Parent', handles.panel1)
    hold on
    plot(t, v(:, ofi(m)))
    errorbar(t2,x2,s2,'o')
    title(handles.model.reactions(handles.link.ofmi(m)).name)
    hold off
end

listbox1 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [30 150 200 200], ...
    'Tag', 'resultListBox', ...
    'String', results_info);

loadbutton = uicontrol('Parent', d, ...
    'Style', 'pushbutton', ...
    'Tag', 'loadParameters', ...
    'String', 'Use fitted parameters', ...
    'Position', [30 100 200 20], ...
    'UserData', results_info_index, ...
    'callback', @useFitP);

% Slider to adjust smoothness
for q = 1:length(p)
    uicontrol('Parent', d,...
        'style','slide',...
        'unit','pixel',...
        'Tag', ['parameterSlider' num2str(q)], ...
        'UserData', q, ...
        'position',[250 -50+50*q 250 20],...
        'min',0,'value', handles.user_input.temp_p(q), 'max', handles.user_input.temp_p(q) * 10,...
        'callback',@s2_call);
    
    uicontrol('Parent', d, ...
        'style', 'text', ...
        'Tag', ['parameter' num2str(q) 'name'], ...
        'position', [250 -25+50*q 250 20], ...
        'string', model.parameters(q).name);
    
    uicontrol('Parent', d, ...
        'style', 'text', ...
        'Tag', ['parameter' num2str(q) 'value'], ...
        'position', [625 -50+50*q 50 20], ...
        'string', handles.user_input.temp_p(q));
end

% Close button
closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);

function useFitP(hObject, eventdata, handles)
handles= guidata(gcf);

h1 = findobj('Tag', 'resultListBox');

results_info_index = hObject.UserData;

result_ind = results_info_index(h1.Value);

result = handles.result_list{result_ind};

pest = result.pest;
p0 = result.p0;

pidx = result.user_input.pidx;

allP = p0;
allP(pidx) = pest;

for q = 1:length(allP)
    
    hVar = findobj('Tag', ['parameterSlider' num2str(q)]);
    
    if allP(q) > hVar.Max
        set(hVar, 'Max', 2*allP(q));
    elseif allP(q) < hVar.Min
        set(hVar, 'Min', 0.1*allP(q));
    end
    
    set(hVar, 'Value', allP(q));
    
end

handles.user_input.temp_p = allP;

guidata(gcf, handles)
guidata(handles.figure1, handles);

function s2_call(hObject, eventdata, handles) 
% Callback for the slider.
handles = guidata(gcf);

p_ind = hObject.UserData; 

model = handles.model;
data = handles.data;
user_input = handles.user_input;
link = handles.link;

% t = data.time;
t = data.idt;
x0 = [model.states.init];
x0(link.oxi) = data.dd(1, link.oxdi);

handles.user_input.temp_p(p_ind) = hObject.Value;
p = handles.user_input.temp_p;

uvec = model.uvec;

x = computeStates(model, t, x0, p, uvec, user_input);
v = computeReactions(model, t, x, p, uvec);


oxi = find(handles.link.oxi);
ofi = find(handles.link.ofi);

dim = ceil(sqrt(length(handles.link.oxdi) + length(handles.link.ofdi)));

for n = 1 : length(handles.link.oxdi)
    
    x1 = handles.data.dd(:, handles.link.oxdi(n));
    x2 = x1(~isnan(x1));
    t1 = handles.data.time;
    t2 = t1(~isnan(x1));
    s1 = handles.data.ds(:, handles.link.oxdi(n));
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    
    subplot(dim, dim, n, 'Parent', handles.panel1)
    plot(t, x(:, oxi(n)))
    hold on
    errorbar(t2,x2,s2,'o')
    title(handles.model.states(handles.link.oxmi(n)).name)
    hold off
end

for m = 1 : length(handles.link.ofdi)
    
    x1 = handles.data.dd(:, handles.link.ofdi(m));
    x2 = x1(~isnan(x1));
    t1 = handles.data.time;
    t2 = t1(~isnan(x1));
    s1 = handles.data.ds(:, handles.link.ofdi(m));
    s2 = s1(~isnan(x1));
    s2(isnan(s2)) = 0;
    
    subplot(dim, dim, m+n, 'Parent', handles.panel1)
    plot(t, v(:, ofi(m)))
    hold on
    errorbar(t2,x2,s2,'o')
    title(handles.model.reactions(handles.link.ofmi(m)).name)
    hold off
end

h1 = findobj('Tag', ['parameter' num2str(p_ind) 'value']);

set(h1, 'string', hObject.Value);

guidata(gcf, handles)
guidata(handles.figure1, handles);


% --- Executes on button press in variable4OptionsButton.
function variable4OptionsButton_Callback(hObject, eventdata, handles)
% hObject    handle to variable4OptionsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

d = dialog('Position', [300 300 250 250], 'Name', 'Dialogception');

button1 = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'New window', ...
    'Callback', @newWindow); 

guidata(gcf, handles);
    
% used as test window, can easily adjust and experiment GUI functions and
% additional options using this
function newWindow(hObject, eventdata, handles)

handles = guidata(gcf);

d = dialog('Position', [400 400 250 250], 'Name', 'It worked!');

text1 = uicontrol('Parent', d, ...
    'Position', [50 100 70 25], ...
    'Style', 'edit', ...
    'Tag', 'lambdaBox1', ...
    'String', num2str(handles.user_input.options.runADAPT.labAValue)) ;

button1 = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'Style', 'pushbutton', ...
    'String', 'Save', ...
    'Callback', @saveLab); 

guidata(gcf, handles);
guidata(handles.figure1, handles);

function saveLab(hObject, eventdata, handles)

handles = guidata(gcf);

h1 = findobj('Tag', 'lambdaBox1');

handles.user_input.options.runADAPT.labAValue = str2num(h1.String);

guidata(gcf, handles);
guidata(handles.figure1, handles);

% --- Executes on button press in plotResultButton.
function plotResultButton_Callback(hObject, eventdata, handles)
% hObject    handle to plotResultButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles = guidata(gcf);

d = dialog('Position', [300 300 250 500], 'Name', 'Select result to plot');

results_info = {};

for i = 1:length(handles.result_list)
    temp_str = [handles.result_list{i}(1).sim_type ',  ' handles.result_list{i}(1).sim_date];
    
    results_info{end+1} = temp_str;
end

listbox1 = uicontrol('Parent', d, ...
    'Style', 'listbox', ...
    'Position', [30 250 200 200], ...
    'Tag', 'resultListBox', ...
    'String', results_info);
    
plotButton = uicontrol('Parent', d, ...
    'Position', [50 20 70 25], ...
    'String', 'Plot', ...
    'Callback', @mfiPlot); 

closeButton = uicontrol('Parent', d, ...
    'Position', [130 20 70 25], ...
    'String', 'Close', ...
    'Callback', @closepopup_callback);

guidata(gcf, handles);

% All below is used to REPLOT data, either from current result-list or
% loaded result-list

function mfiPlot(hObject, eventdata, handles)
handles = guidata(gcf);

h1 = findobj('Tag', 'resultListBox');

result = handles.result_list{h1.Value};

model = result.model;
data = result.data;
link = result.link;
user_input = result.user_input;

switch result(1).sim_type
    case 'simulate'
        
        figure;
        plot(result.time, result.x)
        title('Model states')
        xlabel('Time [-]')
        ylabel('Concentration [-]')
        legend('show')
        
        figure;
        plot(result.time, result.v)
        title('Model reactions')
        xlabel('Time [-]')
        ylabel('Reaction rate [-]')
        legend('show')
        
        for i = 1:length(model.states)
            figure;
            plot(result.time, result.x(:,i))
            title(['State ' num2str(i)])
            xlabel('Time [min]')
            ylabel('Concentration [mM])')
        end
        
        for i = 1:length(model.reactions)
            figure;
            plot(result.time, result.v(:,i))
            title(['Variable ' num2str(i)])
            xlabel('Time [min]')
            ylabel('Concentration or Flux [])')
        end
        
        if user_input.options.simulate.useData
            
            oxi = find(link.oxi);
            ofi = find(link.ofi);
            
            dim = ceil(sqrt(length(link.oxdi) + length(link.ofdi)));
            
            figure;
            hold on
            
            for n = 1 : length(link.oxdi)
                
                x1 = data.dd(:, link.oxdi(n));
                x2 = x1(~isnan(x1));
                t1 = data.time;
                t2 = t1(~isnan(x1));
                s1 = data.ds(:, link.oxdi(n));
                s2 = s1(~isnan(x1));
                s2(isnan(s2)) = 0;
                
                subplot(dim, dim, n)
                hold on
                plot(result.time, result.x(:, oxi(n)))
                plot(t2,x2,'o')
                title(model.states(link.oxmi(n)).name)
            end
            
            for m = 1 : length(link.ofdi)
                
                x1 = data.dd(:, link.ofdi(m));
                x2 = x1(~isnan(x1));
                t1 = data.time;
                t2 = t1(~isnan(x1));
                s1 = data.ds(:, link.ofdi(m));
                s2 = s1(~isnan(x1));
                s2(isnan(s2)) = 0;
                
                subplot(dim, dim, m+n)
                hold on
                plot(result.time, result.v(:, ofi(m)))
                plot(t2,x2,'o')
                title(model.reactions(link.ofmi(m)).name)
            end
        end
        
    case 'ADAPT'
        
        numIter = user_input.options.runADAPT.numIter;
        
        sse_list = zeros(size(result));
        
        for it = 1:numIter
            sse_list(it) = sum(result(it).sse);
        end
        
        max_sse_list = max(sse_list);
        min_sse_list = min(sse_list);
        diff_sse_list = max_sse_list - min_sse_list;
        
        [sorted_sse_list, I] = sort(sse_list); 
        
        plot_color = cell(size(sse_list));
                
        for it = 1:numIter
            pos = find(I == it);
            
            r_c = pos / numIter;
            g_c = 1 - r_c;
            
            w = 1 / max([r_c g_c]);
            
            r_c = r_c * w;
            g_c = g_c * w;
            
            plot_color{it} = [r_c g_c 0];
        end
        
        % Experimental part for alternative trajectory analysis
        % ----------------------------------------------------------------
        
        sse_list_weighted = zeros(size(result));
        
        for it = 1:numIter
            
            temp_resid = result(it).resid;
            temp_resid(:,1:(length(link.oxdi)+length(link.ofdi))) = result(it).resid(:,[link.oxdi link.ofdi]).*user_input.options.runADAPT.weight;
            
            sse_list_weighted(it) = sum(sum(real(temp_resid),2));
        end
        
        [sorted_sse_weighted_list, I_weighted] = sort(sse_list_weighted);
        
        plot_color_weighted = cell(size(sse_list_weighted));
        
        for it = 1:numIter
              pos = find(I_weighted == it);
              
              r_c = pos / numIter;
              g_c = 1 - r_c;
              
              w = 1 / max([r_c g_c]);
              
              r_c = r_c * w;
              g_c = g_c * w;
              
              plot_color_weighted{it} = [r_c g_c 0];
        end
        
        % Einde experimenteel stuk
        % ---------------------------------------------------------------
        
        
        % Plot gedeelte gebaseerd op normale SSE
        % --------------------------------------
        for p = 1:length(model.parameters)
            figure()
            hold on
            
            for it = 1:numIter
                              
                plot(result(it).time, result(it).p(:,p), 'color', plot_color{it})
            end
            
            title(['Parameter value over time (', model.parameters(p).name, ' [-])'])
            xlabel('Time [-]')
            ylabel('Parameter value')
        end
        
        % PLOT ALL STATES
            
        figure
        hold on
        
        no_states = length(model.states);
        
        for it = 1:numIter
            
            for x = 1:no_states
                subplot(ceil(sqrt(no_states)), ceil(sqrt(no_states)), x)
                hold on
                
                cur_state = x;
                           
                plot(result(it).time, result(it).x(:, cur_state), 'color', plot_color{it})
                

                title(model.states(x).name)
                xlabel('Time [-]')
                ylabel('Concentration')
            end
        end

        
        % PLOT OBSERVABLE STATES
        no_obs_states = length(link.oxdi);
        
        if no_obs_states > 0
            
            figure
            hold on
            
            for it = 1:numIter
                
                for x = 1:no_obs_states
                    subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
                    hold on
                    
                    cur_state = link.oxmi(x);
                    cur_data = link.oxdi(x);
                    
                    plot(result(it).time, result(it).x(:, cur_state), 'color', plot_color{it})
                    
                    x1 = data.dd(:, cur_data);
                    x2 = x1(~isnan(x1));
                    t1 = data.time;
                    t2 = t1(~isnan(x1));
                    s1 = data.ds(:, cur_data);
                    s2 = s1(~isnan(x1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,x2,s2,'ok')
                    
                    title(model.states(cur_state).name)
                    xlabel('Time [-]')
                    ylabel('Concentration')
                end
            end
        end
        
        % PLOT ALL STATES
        
        figure
        hold on
        
        no_reactions = length(model.reactions);
        
        for it = 1:numIter
            
            for v = 1:no_reactions
                subplot(ceil(sqrt(no_reactions)), ceil(sqrt(no_reactions)), v)
                hold on
                
                cur_reaction = v;
                
                plot(result(it).time, result(it).v(:, cur_reaction), 'color', plot_color{it})
                
                title(model.reactions(cur_reaction).name)
                xlabel('Time [-]')
                ylabel('Concentration')
            end
        end

        
        % PLOT OBSERVABLE REACTIONS
        no_obs_reactions = length(link.ofdi);
        
        if no_obs_reactions > 0
            
            figure
            hold on
            
            for it = 1:numIter
                
                for v = 1:no_obs_reactions
                    subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
                    hold on
                    
                    cur_reaction = link.ofmi(v);
                    cur_data = link.ofdi(v);
                    
                    plot(result(it).time, result(it).v(:, cur_reaction), 'color', plot_color{it})
                    
                    v1 = data.dd(:, cur_data);
                    v2 = v1(~isnan(v1));
                    t1 = data.time;
                    t2 = t1(~isnan(v1));
                    s1 = data.ds(:, cur_data);
                    s2 = s1(~isnan(v1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,v2,s2,'ok')
                    
                    title(model.reactions(cur_reaction).name)
                    xlabel('Time [-]')
                    ylabel('Concentration')
                end
            end
        end
        % Plot gedeelte gebaseerd op gewogen SSE
        % --------------------------------------
        for p = 1:length(model.parameters)
            figure()
            hold on
            
            for it = 1:numIter
                              
                plot(result(it).time, result(it).p(:,p), 'color', plot_color_weighted{it})
            end
            
            title(['Parameter value over time (', model.parameters(p).name, ' [-])'])
            xlabel('Time [-]')
            ylabel('Parameter value')
        end
        
        % PLOT ALL STATES
            
        figure
        hold on
        
        no_states = length(model.states);
        
        for it = 1:numIter
            
            for x = 1:no_states
                subplot(ceil(sqrt(no_states)), ceil(sqrt(no_states)), x)
                hold on
                
                cur_state = x;
                plot(result(it).time, result(it).x(:, cur_state), 'color', plot_color_weighted{it})
                
                title(model.states(x).name)
                xlabel('Time [-]')
                ylabel('Concentration')
            end
        end

        
        % PLOT OBSERVABLE STATES
        no_obs_states = length(link.oxdi);
        
        if no_obs_states > 0
            
            figure
            hold on
            
            for it = 1:numIter
                
                for x = 1:no_obs_states
                    subplot(ceil(sqrt(no_obs_states)), ceil(sqrt(no_obs_states)), x)
                    hold on
                    
                    cur_state = link.oxmi(x);
                    cur_data = link.oxdi(x);
                    
                    plot(result(it).time, result(it).x(:, cur_state), 'color', plot_color_weighted{it})
                    
                    x1 = data.dd(:, cur_data);
                    x2 = x1(~isnan(x1));
                    t1 = data.time;
                    t2 = t1(~isnan(x1));
                    s1 = data.ds(:, cur_data);
                    s2 = s1(~isnan(x1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,x2,s2,'ok')
                    
                    title(model.states(cur_state).name)
                    xlabel('Time [-]')
                    ylabel('Concentration')
                end
            end
        end
        
        % PLOT ALL STATES
        
        figure
        hold on
        
        no_reactions = length(model.reactions);
        
        for it = 1:numIter
            
            for v = 1:no_reactions
                subplot(ceil(sqrt(no_reactions)), ceil(sqrt(no_reactions)), v)
                hold on
                
                cur_reaction = v;
                plot(result(it).time, result(it).v(:, cur_reaction), 'color', plot_color_weighted{it})
 
                title(model.reactions(cur_reaction).name)
                xlabel('Time [-]')
                ylabel('Concentration')
            end
        end
        
        % PLOT OBSERVABLE REACTIONS
        no_obs_reactions = length(link.ofdi);
        
        if no_obs_reactions > 0
            
            figure
            hold on
            
            for it = 1:numIter
                
                for v = 1:no_obs_reactions
                    subplot(ceil(sqrt(no_obs_reactions)), ceil(sqrt(no_obs_reactions)), v)
                    hold on
                    
                    cur_reaction = link.ofmi(v);
                    cur_data = link.ofdi(v);
                    
                    plot(result(it).time, result(it).v(:, cur_reaction), 'color', plot_color_weighted{it})
                    
                    v1 = data.dd(:, cur_data);
                    v2 = v1(~isnan(v1));
                    t1 = data.time;
                    t2 = t1(~isnan(v1));
                    s1 = data.ds(:, cur_data);
                    s2 = s1(~isnan(v1));
                    s2(isnan(s2)) = 0;
                    errorbar(t2,v2,s2,'ok')
                    
                    title(model.reactions(cur_reaction).name)
                    xlabel('Time [-]')
                    ylabel('Concentration')
                end
            end
        end
        
    case 'fitParameters'
        result.pest
        result.sse
        result.resid

    case 'PSA'
        figure;
        bar(result.sens);
        title('Parameter Sensitivity Analysis')
        xlabel('Parameters')
        ylabel('Sensitivity Coefficient')
        xlim([0 length({model.parameters.name})+1])
        xticks(1:length({model.parameters.name}))
        xticklabels({model.parameters.name})
        
    case 'PLA'
        figure;
        plot(result.plPar, result.plRes);
        title(['Profile likelihood of parameter ' num2str(user_input.options.PLA.pNum)])
        xlabel('Parameter value')
        ylabel('Fit residual')
end
