% create bar graphs
weight_array_1 = ones(10,3);
weight_array_2 = weight_array_1 .* [0.5 1 1.5];
weight_arrat_3 = 0.1 + weight_array_2 .* [-sin(pi*(1:0.1:1.9))]'; 

figure(1)
bar3(weight_array_1)
title('Weight values for observables')
zlabel('Weight')
ylabel('Time step')
xlabel('Observables')
xticklabels({'Glucose', 'Glycerol', 'Insulin'})
zlim([0 2])

figure(2)
bar3(weight_array_2)
title('Weight values for observables')
zlabel('Weight')
ylabel('Time step')
xlabel('Observables')
xticklabels({'Glucose', 'Glycerol', 'Insulin'})
zlim([0 2])

figure(3)
bar3(weight_arrat_3)
title('Weight values for observables')
zlabel('Weight')
ylabel('Time step')
xlabel('Observables')
xticklabels({'Glucose', 'Glycerol', 'Insulin'})
zlim([0 2])

% create bar graphs
weight_array_1 = 0.1*ones(10,3);
weight_array_2 = weight_array_1 .* [0.5 1 1.5];
weight_arrat_3 = 0.01 + weight_array_2 .* [-sin(pi*(1:0.1:1.9))]'; 

figure(4)
bar3(weight_array_1)
title('Lambda values for parameters')
zlabel('Lambda value')
ylabel('Time step')
xlabel('Parameters')
xticklabels({'p0' 'p2' 'k1'})
zlim([0 .2])

figure(5)
bar3(weight_array_2)
title('Lambda values for parameters')
zlabel('Lambda value')
ylabel('Time step')
xlabel('Parameters')
xticklabels({'p0' 'p2' 'k1'})
zlim([0 .2])

figure(6)
bar3(weight_arrat_3)
title('Lambda values for parameters')
zlabel('Lambda value')
ylabel('Time step')
xlabel('Parameters')
xticklabels({'p0' 'p2' 'k1'})
zlim([0 .2])