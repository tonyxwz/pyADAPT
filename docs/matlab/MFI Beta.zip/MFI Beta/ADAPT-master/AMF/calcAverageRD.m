clear all
close all

dat = load('BC003_pre_400it_ADAPT_version4.mat');
% dat = load('BC003_pre_400it_ADAPT_version4.mat');

model = dat.result_list{1}(1).model;
data = dat.result_list{1}(1).data;
link = dat.result_list{1}(1).link;
user_input = dat.result_list{1}(1).user_input;

result = dat.result_list{1};

arr = [];
% 30 = RA , 31 = RD
% 17 = infusion 18 = infusion
for i = 1:user_input.options.runADAPT.numIter
    arr(:,i) = result(i).v(:,31);
end

mean_arr = mean(arr,2);
mean_arr = mean_arr / 120 * 1000 * result(1).v(1,1);

% [35 37 40] = end initial step
% 64:67 = end step 1
% end-3:end = end step 2

arr_RA = [];
% 30 = RA , 31 = RD
% 17 = infusion 18 = infusion
for i = 1:user_input.options.runADAPT.numIter
    arr_RA(:,i) = result(i).v(:,30)+result(i).v(:,17)+result(i).v(:,18);
end

mean_arr_RA = mean(arr_RA,2);
mean_arr_RA = mean_arr_RA / 120 * 1000 * result(1).v(1,1);

arr_EGP = [];
% 30 = RA , 31 = RD
% 17 = infusion 18 = infusion
for i = 1:user_input.options.runADAPT.numIter
    arr_EGP(:,i) = result(i).v(:,30);
end

mean_arr_EGP = mean(arr_EGP,2);
mean_arr_EGP = mean_arr_EGP / 120 * 1000 * result(1).v(1,1);

arr_gly = [];
% 30 = RA , 31 = RD
% 17 = infusion 18 = infusion
for i = 1:user_input.options.runADAPT.numIter
    arr_gly(:,i) = result(i).v(:,33);
end

mean_arr_gly = mean(arr_gly,2);
mean_arr_gly = mean_arr_gly / 120 * 1000 * result(1).v(1,3);
    