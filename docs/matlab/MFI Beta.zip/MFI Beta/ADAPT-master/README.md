ADAPT
=====

ADAPT toolbox for Matlab - Analysis of Dynamic Adaptations in Parameter Trajectories
