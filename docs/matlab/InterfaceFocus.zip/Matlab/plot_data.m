%plot_data Plot data and stdev in data struct d.
% First run [c,d,m,lab] = initVars_toy;
% Calls plotErrorBar
%
% To add a bar plot:
% h1=bar(xx,dm, 'FaceColor',[0.3,0.3,0.3]); hold on

xx = 0:4;
dNames = fieldnames(d);
for loopindex = 1:2:(numel(dNames)-1)
    %array = d{loopindex}
    dm = d.(dNames{loopindex});         %mean value of data
    ds = d.(dNames{loopindex+1});   %stdev of data
    subplot(2,2,(loopindex+1)/2)
    %errorbar(dm, ds, 'LineWidth',2)
    h1=bar(xx,dm, 'FaceColor',[0.3,0.3,0.3]); hold on
    %h1=bar(xx,dm, 'b'); hold on
    plotErrorBar(xx,0.1,dm,ds,'k',1.5);
    set(gca, 'FontSize',14, 'FontName', 'Times New Roman')
    set(gca, 'XTick', [0:4], 'XTickLabel', {'1', '2', '3', '4', '5'}, 'FontSize',14)
    title(lab.state((loopindex+1)/2))
    assen=axis; axis([-1 5 assen(3:4)])
end

