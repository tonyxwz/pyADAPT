%getDataSplines_toy A bootstrap approach for spline interpolation of
%experimental data, sampling from a Gaussian distribution with mean and
%stdev of the data
%
% splines = getDataSplines_toy(d)
%
%input:
% d: struct with original data and standard deviations
%output
% splines: struct of a cubic smoothing spline in ppform 
% ppval can be used to evaluate the spline polynomial (e.g. for plotting)

function splines = getDataSplines_toy(d)

%introduce a (mock) time vector for the experimental data
%assume time vector is the same for all data
%make sure begin and end match the simulation time in runPTA_toy.m
tdata = linspace(0,5,length(d.S1)); %

%get data from the struct d
splines = cell(4,1);

for i = 1 : numel(splines)
    smooth = [];
    switch i
    case 1
        dm = d.S1;
        ds = d.S1_std;
    case 2
        dm = d.S2;
        ds = d.S2_std;
    case 3
        dm = d.S3;
        ds = d.S3_std;
    case 4
        dm = d.S4;
        ds = d.S4_std;
    end
    
    %add Normal distributed noise with mean dm and standard deviation ds
    dd = dm + randn(size(ds)).*ds;

    splines{i} = csaps(tdata,dd);
    %splines{i} = csaps(t,dd, smooth,[]);    % returns the ppform of a cubic smoothing spline

end
