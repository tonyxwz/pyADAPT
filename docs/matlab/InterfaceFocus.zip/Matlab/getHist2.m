function [N,C] = getHist2(t,v,r,ny)
%getHist2 A 2-dimensional histogram (for example of time-series data).
%
%   [N,C] = getHist2(t,v,r,ny)
%
% t:  time vector
% v:  ensemble (marix) of trajectories. 
%Deze moet de volgende vorm hebben: matrix van Np rijen en Nt kolommen. Waarbij Np het aantal paden voor desbetreffende parameter/flux/state is, en Nt het aantal tijdspunten.
% r:  optional. r is een vector van 2 elementen die de onder en bovengrens van het histogram voorstellen. Als je [] meestuurt bepaald Matlab zelf de grenzen.
% ny: is het aantal punten voor de y-as van de histogram
%
% N: a matrix containing the number of elements of X that fall in each bin of the grid
% C: the positions of the bin centers in a 1-by-2 cell array of numeric vectors

a = repmat(t,1,size(v,1)).';
b = reshape(v.',numel(v),1);

if numel(r) > 0
    [N C] = hist3([a,b],{t,[r(1) : (r(2)-r(1))/(ny-1) : r(2)]});
else
    [N C] = hist3([a,b],[numel(t) ny]);
end
N = log10(N);
N = N./max(max(N));
