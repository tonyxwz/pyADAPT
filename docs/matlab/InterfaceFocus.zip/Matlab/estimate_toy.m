%estimate_toy Case study 2: Estimate lumped parameter k1 for each dataset
%separately using a Monte Carlo approach.
%Transform data provided as a mean value with a standard deviation into a
%Gaussian distribution, from which samples are generated.
%pEst is a matrix with k1 at the 5 different stages in the rows 

close all; clear all

[c,d,m,lab] = initVars_toy; %d: data as a struct
load('data_toy.mat')    %the data in matrices

dNames = fieldnames(d);
%for loopindex = 1:2:(numel(dNames)-1)
%    data.(dNames{loopindex}) = d.(dNames{loopindex})(1);         %1st datapoint of mean value of data
%    data.(dNames{loopindex+1}) = d.(dNames{loopindex+1})(1);   %stdev of data
%end

tspan=[-1000 0];
k60 = 0.01; %wild-type value
p0 = k60;
pprev = p0;
pEst = [];
lb = 0;
ub = [];
optimOptions = [];  %default values TolX = TolFun = 1e-6
if 0%
%for k=1:5   %loop through different days/snapshots
    x0 =  concdata(k,:);
    k
    for loopindex = 1:100   %estimate parameter from different samples of data distribution
        %p0 = 10.^(2*rand(1,1)-1)    
        for i = 1:2:(numel(dNames)-1)
            %generate sample from data distribution
            dm = d.(dNames{i})(k);         %1st datapoint of mean value of data
            ds = d.(dNames{i+1})(k);
            data.(dNames{i}) = dm + randn(1,1).*ds;
            data.(dNames{i+1}) = ds;   %stdev of data
        end
        %optimFunc = @(p)optimFunc_true(p,x0,ydata,stddata(loopindex,1:4));
        optimFunc = @(p)obj_toy(p, pprev,p0,c,m,tspan,x0,data,0);

        [pest,resnorm,residual,exitflag,OUTPUT,LAMBDA,Jacobian] = lsqnonlin( optimFunc,p0,lb,ub,optimOptions);

        %pEst = pest;
        pEst(k,loopindex) = pest;
    end
    clc
    save snapshot.mat pEst
end
if 0    
    %Estimated parameter (co)variance
    Jacobian = full(Jacobian);  %lsqnonlin returns the Jacobian as a sparse matrix
    varp = resnorm*inv(Jacobian'*Jacobian)/length(x0);
    stdp = sqrt(diag(varp))    %standard deviation is square root of variance
    stdp = 100*stdp'./pest;        %[%]
end

load snapshot.mat
pNames = fieldnames(c.p); 
for k=1:5
    figure(1); subplot(3,5,k); bar(pEst(k,:), 'k')
    assen=axis; axis([0 size(pEst,2) assen(3:4)])
    %title(['Parameter ', pNames{1}, ', day ', num2str(k)])
    figure(2); subplot(3,5,k); hist(pEst(k,:)) 
    axis([0 ceil( max(max(pEst)) ) 0 30])
    title(['Parameter ', pNames{1}, ', day ', num2str(k-1)]) %title(['Parameter ', pNames(1)]) 
    %mean(pEst(k,:))
    %std(pEst(k,:))
 
    %figure(3); subplot(3,5,k); hist(v(k,:)) 
    %title(['day ', num2str(k)]) 

end
break

%simulate with mean of pEst 
for loopindex = 1:5 
    x0 =  concdata(loopindex,:);
    pest =  mean(pEst(loopindex,:));
    [tt,xx,yy,ff] = simulate_toy(tspan,x0,pest,c,m);
    yest(loopindex,:) = yy;
end
%figure; bar([concdata; yest]')
figure; %plot_data
for j = 1 : 4
    subplot(2,2,j); hold on; box on;
    tplot = [1         2
             2.01      3
             3.01      4
             4.01      5
             5.01      6 ];
    yplot = [yest(1,j) yest(1,j) 
             yest(2,j) yest(2,j) 
             yest(3,j) yest(3,j) 
             yest(4,j) yest(4,j) 
             yest(5,j) yest(5,j)];
    for loopindex = 1:5
        plot(tplot(loopindex,:),yplot(loopindex,:), 'Color',[0.7,0.7,0.7], 'LineWidth',1.5);
        plot(tplot(loopindex,1),yplot(loopindex,1),'.k')
    end
    assen=axis; axis([assen(1:2), 0 1.6])
    set(gca, 'XTick', [1:5], 'XTickLabel', {'1', '2', '3', '4', '5'})
    set(gca, 'FontSize',14, 'FontName','Times New Roman')
    title(lab.state(j))
end
subplot(2,2,3); xlabel('Time (days)')
subplot(2,2,4); xlabel('Time (days)')


%the truth
%v1 = k1*u1*x(2,:)./(Km+x(5,:)) 
%v1 = 1*1*S2/(0.1+R1)
%Basal / reference steady-state
%v1 = k1� *S2
%with k1� = 1/(0.1+R1)  and R1 = 0.52
%=> k1� = 1.61
%and S2 = 0.38 => v1 = 0.61
k1prime = 1.61
