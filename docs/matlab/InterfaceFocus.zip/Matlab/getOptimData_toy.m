%getOptimData_toy Interpolates data (both mean and stdev) using an 
% interpolating spline.
%
% data = getOptimData_toy(d,t,splData)
%
%input:
% d: struct with original data and standard deviations
% t: current time point
% splData: interpolating spline
%output:
% data: struct containing interpolated data for {S1, S2, S3, S4} and
% corresponding standard deviation

function data = getOptimData_toy(d,t,splData)

tdata = 1:5;

data.S1 = ppval(splData{1},t);
data.S1_std = sqrt( interp1(tdata, d.S1_std.^2, t, 'linear','extrap') );
%data.S1_std = d.S1_std;

data.S2 = ppval(splData{2},t);
data.S2_std = sqrt( interp1(tdata, d.S2_std.^2, t, 'linear','extrap') );

data.S3 = ppval(splData{3},t);
data.S3_std = sqrt( interp1(tdata, d.S3_std.^2, t, 'linear','extrap') );

data.S4 = ppval(splData{4},t);
data.S4_std = sqrt( interp1(tdata, d.S4_std.^2, t, 'linear','extrap') );
