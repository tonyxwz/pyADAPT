%plotErrorBar Plot error bars. Before calling a figure should have been
%created which is in 'hold on' mode.
%
%   plotErrorBar(x,dx,d,d_std,col,lw,h,up)
%
% x    : x-axis values
% dx   : width
% d    : y-axis
% d_std: standard deviation
% col: color, optional, default col = 'k'
% lw:  line width, optional, default lw = 1
% h:   optional, default h = 0;
% up:  0,1,2 optional, default up = 0

function plotErrorBar(x,dx,d,d_std,col,lw,h,up)

if nargin < 5, col = 'k'; end;
if nargin < 6, lw = 1; end;
if nargin < 7, h = 0; end;
if nargin < 8, up = 0; end;


for i = 1 : numel(x)

    if d_std(i) >= 0 

        if h==0
%             plot(x(i),d(i),'.','Color',col);
            if up==1
                plot([x(i)-dx x(i)+dx],[d(i) + d_std(i), d(i) + d_std(i)],'Color',col,'LineWidth',lw);
                plot([x(i)    x(i)   ],[d(i), d(i) + d_std(i)],'Color',col,'LineWidth',lw);
            elseif up==2
                plot([x(i)-dx x(i)+dx],[d(i) - d_std(i), d(i) - d_std(i)],'Color',col,'LineWidth',lw);
                plot([x(i)    x(i)   ],[d(i) - d_std(i), d(i) ],'Color',col,'LineWidth',lw);
            else
                plot([x(i)-dx x(i)+dx],[d(i) + d_std(i), d(i) + d_std(i)],'Color',col,'LineWidth',lw);
                plot([x(i)-dx x(i)+dx],[d(i) - d_std(i), d(i) - d_std(i)],'Color',col,'LineWidth',lw);
                plot([x(i)    x(i)   ],[d(i) - d_std(i), d(i) + d_std(i)],'Color',col,'LineWidth',lw);
            end
        else
%             plot(d(i),x(i),'.','Color',col);
            if up==1
                plot([d(i) + d_std(i), d(i) + d_std(i)],[x(i)-dx x(i)+dx],'Color',col,'LineWidth',lw);
                plot([d(i), d(i) + d_std(i)],[x(i)    x(i)   ],'Color',col,'LineWidth',lw);
            elseif up==2
                plot([d(i) - d_std(i), d(i) - d_std(i)],[x(i)-dx x(i)+dx],'Color',col,'LineWidth',lw);
                plot([d(i) - d_std(i), d(i)],[x(i)    x(i)   ],'Color',col,'LineWidth',lw);
            else
                plot([d(i) + d_std(i), d(i) + d_std(i)],[x(i)-dx x(i)+dx],'Color',col,'LineWidth',lw);
                plot([d(i) - d_std(i), d(i) - d_std(i)],[x(i)-dx x(i)+dx],'Color',col,'LineWidth',lw);
                plot([d(i) - d_std(i), d(i) + d_std(i)],[x(i)    x(i)   ],'Color',col,'LineWidth',lw);
            end
        end
    end
    
end