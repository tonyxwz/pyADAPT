readme ADAPT (Analysis of Dynamic Adaptations in Parameter Trajectories) for toy example

Matlab code for paper
'Applications of Analysis of Dynamic Adaptations in Parameter Trajectories'
Natal A.W. van Riel, Christian A. Tiemann, Joep Vanlier, Peter A.J. Hilbers
Interface Focus

Note, method was temporaly also known as PTA (Parameter Trajectory Analysis). 

---------------------------------------------
* runADAPT_toy    main file      

On lines 48 and 49 a parameter (plt) can be set to control plotting of intermediate results.
Plotting can be useful to tune the algorithm, but slows down the computation.
Uncomment line 48 (remove %) and comment line 49 (add % in front) to set plt = 0 to suppress plotting.

calls:
- toy_model.png model scheme
- initVars_toy.m
	- loads data_toy.mat experimental data (as matrices)
- getDataSplines_toy.m
	- calls csaps from Curvefit Tlbx
- getOptimData_toy.m
- obj_toy.m
- lsqnonlin from Optimization Tlbx


* obj_toy.m	Objective function (cost function) to optimize parameters.
calls:
- simulate_toy


* simulate_toy.m	Simulate the model, either with Matlab solver (ode15s) or with CVode suite (compiled mex file)
calls:
- ode_toy.m
- fluxes_toy.m

For information on the CVode package and to download it, see http://bmi.bmt.tue.nl/sysbio/software/pua.html

-----------------------------------------------
* postProcessData 
Collect and merge data files
calls:
- initVars_toy.m

-----------------------------------------------
* estimate_toy 
Case study 2: Estimate lumped parameter k1 for each dataset separately using a Monte Carlo approach.

calls:
- initVars_toy.m
- obj_toy.m
- lsqnonlin from Optimization Tlbx

-----------------------------------------------
* InterfaceFocus2.m
To generate plots for the Interface Focus paper

calls:
- initVars_toy.m
- plot_data.m
- plotErrorBar.m
- results_tot.mat
- snapshot.mat
- getDataSplines_toy.m
- getHist2.m
