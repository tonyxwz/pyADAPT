%postProcessData Collect and merge data files

clear all; close all;

lab1 = 0.1; %can be a vector if multiple lab1 values have been used
maxfilenr = 200;

[c,d,m,lab] = initVars_toy;

for xx1 = 1 : numel(lab1)

    N = 0;
    for i = 1 : maxfilenr
        %fn = [fullpath,'paths_50pt_lab1_',num2str(lab1(xx1)),'_',num2str(i),'.mat'];
        fn = ['paths_50pt_lab1_',num2str(lab1(xx1)),'_',num2str(i),'.mat'];
        if exist(fn,'file') > 0
            N = N + 1;
        end
    end
    disp(num2str(N));
    
    %allocate cell arrays
    p  = cell(m.parameters,1);    
    x  = cell(m.states,1);    
    y  = cell(m.states,1);
    f  = cell(m.fluxes,1);
    pd = cell(m.parameters,1);
    tp = 50;%length(result.t);  %no of (time) points in trajectories
    for i = 1 : numel(p), p{i} = zeros(N,tp); end;
    for i = 1 : numel(x), x{i} = zeros(N,tp); end;
    for i = 1 : numel(y), y{i} = zeros(N,tp); end;
    for i = 1 : numel(f), f{i} = zeros(N,tp); end;
    for i = 1 : numel(pd), pd{i} = zeros(N,tp); end;

    t = [];
    it = 0;
    for i = 1 : maxfilenr
        fn = ['paths_50pt_lab1_',num2str(lab1(xx1)),'_',num2str(i),'.mat'];

        if exist(fn,'file') > 0
            
            if it < N
            
                load(fn)
                    
                it = it + 1;
                if numel(t)==0, t = result.t; end;
                for j = 1 : numel(p), p{j}(it,:) = result.p(j,:); end;
                for j = 1 : numel(x), x{j}(it,:) = result.x(j,:); end;
                for j = 1 : numel(y), y{j}(it,:) = result.y(j,:); end;
                for j = 1 : numel(f), f{j}(it,:) = result.f(j,:); end;
                for j = 1 : numel(pd), pd{j}(it,:) = [0, (diff(result.p(j,:)) ./ result.p(j,1)) ./ diff(t) ]; end;
                 
            end            
            
        end
    end


    if N > 0
        save('results_tot.mat','t','p','x','y','f','pd','lab1');
        disp('present')
    else
        disp('not present')
    end

end
