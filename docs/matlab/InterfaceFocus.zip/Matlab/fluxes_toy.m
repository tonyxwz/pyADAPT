%fluxes_toy
%with a 1 sec pulse in u1 at t=5 sec.
%
%   v = fluxes_toy(x,p,c)
%
%input:
% x: matrix with time course of the state variables in the columns 
% p: struct with parameters
% c: struct with parameter indices and general constants
%output:
% v: matrix with time course of the fluxes in the columns

function v = fluxes_toy(x,p,c)
%input fluxes
u1 = 1;
u2 = u1;
% if t>5 & t<6    %nvr 14-Dec-12
%     u1 = 2;
% end

% parameters
k1 = p(c.p.k1);
%k2 = p(c.p.k2);
%k3 = p(c.p.k3);
%k4 = p(c.p.k4);
%k5 = p(c.p.k5);
k2 = c.c.k2;
k3 = c.c.k3;
k4 = c.c.k4;
k5 = c.c.k5;

% state variables
S1 = x(c.s.S1);
S2 = x(c.s.S2);
S3 = x(c.s.S3);
S4 = x(c.s.S4);

%internal fluxes (rates) 
v1 = k1*u1*x(:,2);
v2 = k2*u2*x(:,3);
v3 = k3*x(:,1);
v4 = k4*x(:,1);
v5 = k5*x(:,4);

v = [v1 v2 v3 v4 v5];
