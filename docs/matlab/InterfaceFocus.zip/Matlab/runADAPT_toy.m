%runADAPT_toy Main file for Analysis of Dynamic Adaptations in Parameter
%Trajectories (ADAPT)for toy model
% Results are stored in the struct 'result', which is saved as mat file.

%Christian Tiemann & Natal van Riel, TU/e
%09-Jan-2013

close all; clear; clc

rr2 = 200; %no. of repeats/samples of the parameter trajectories
sseThres = 1e3;%1e4;    %threshold for SSE to accept or reject parameter values
lab1 = 0.1;%1;%0%0.01;% lab1: Lagrange multiplier, weighting regularization of parameter changes vs datafit

fullpath = mfilename('fullpath');
[dum, fullpath] = strtok( fliplr(fullpath), '/\' );
fullpath = fliplr(fullpath);

%ima = imread('toy_model.jpg','jpg'); 
ima = imread('toy_model.png','png', 'BackgroundColor',[1 1 1]);
h=figure; image(ima); axis off;
%position rectangle with a four-element vector of the form 
%rect = [left, bottom, width, height]
set(h,'Position',[10 450 500 220]); drawnow; pause(2)


[c,d,m,lab] = initVars_toy;
%  c: struct with parameter indices and constants
%  d: struct with experimental data and standard deviation
%  m: struct with settings / options for simulation and optimization
%  lab: struct containing string labels for states, parameters and fluxes
figure; plot_data; drawnow
disp('press key to continue'); pause

rr1 = 1;
rand('state',rr1);
randn('state',rr1);
ntimesteps = 50;    %time steps in the trajectory
tend = 4;
t = 0 : (tend / (ntimesteps - 1)) : tend; %time vector for simulation
%here arbitrary range and unit, e.g. 5 days
t = [-1000 t];  %add additional negative time point to make sure model is in steady-state

lb = zeros(m.parameters,1);
ub = [];

%Plotting intermediate results can be useful to tune the algorithm to the
%problem:
%plt = 0; %no plotting of intermediate results - uncomment to increase speed 
plt = 1; load('data_toy.mat');  %uncomment this line to plot intermediate results, see below
i = rr1;
while i <= rr2

    try
    if plt  %plot the data
        close
        subplot(321), plot([0:4],concdata(:,1), 'r^'), hold on
        subplot(322), plot([0:4],concdata(:,2), 'r^'), hold on
        subplot(323), plot([0:4],concdata(:,3), 'r^'), hold on
        subplot(324), plot([0:4],concdata(:,4), 'r^'), hold on, drawnow
        subplot(325), axis([0 4 0 sseThres]), hold on, drawnow
    end
        disp(' ');disp('--------------------------------------');
        disp(['iteration ',num2str(i),' / ',num2str(rr2)]);
        disp('fitting data splines'); 
        splData = getDataSplines_toy(d);    %struct of a cubic smoothing spline in ppform
        result.t       = t(2:end);  %time vector
        result.p       = [];        %parameter trajectories
        result.x       = [];
        result.y       = [];
        result.f       = [];
        result.resid   = [];
        result.sse     = [];        %Sum of Squared Errors per time point
        result.splData = splData;   %interpolated data
        result.lab1    = lab1;      %Lagrange multiplier, weighting regularization of parameter changes vs datafit
        
        conest2=0;  %flag which becomes 1 once the current trajectory should be aborted
        disp('starting optimization');
        for j = 2 : (ntimesteps + 1)

            if conest2==0
                
                tcurr = [t(j-1), mean([t(j), t(j-1)]) , t(j)];
                data = getOptimData_toy(d,tcurr(end),splData);     % get data (struct) for current time point

                if j == 2   % wild-type/stage 1 estimation
                %first try to find a good fit for the basal data
                    pinit = [];
                    finit = [];
                    conest = 0; %flag which is 0 as long as no good fit of the basal data (stage 1) has been obtained
					nnoacc = 0; %counter for number of non-acceptable parameters
                    while conest == 0   
                        x0curr = [ data.S1; data.S2; data.S3; data.S4 ];
                        %pcurr  = 10.^(4*rand(m.parameters,1)-2);
                        pcurr  = 10.^(2*rand(m.parameters,1)-1);
                        
                        [pest, sse, resid] = lsqnonlin(@obj_toy,(pcurr),lb,ub,m.min_options, pcurr,pinit,c,m,tcurr,x0curr,data,lab1);
                        if sse < sseThres
                            conest=1;
                            disp('acceptable parameter set for t0');
                            %pest
                        else
							nnoacc = nnoacc + 1;
                            disp(['not an acceptable parameter set for t0 (sse=',num2str(sse), '), trying with new initial parameter set']);
                            
							if nnoacc >= 5
								error('aborting')
							end
                        end;
                    end %while conest == 0
                    
                else % determine full trajectory
                    
                    pinit = result.p(:,1);
                    finit = result.f(:,1);
                    [pest, sse, resid] = lsqnonlin(@obj_toy,(pcurr),lb,ub,m.min_options, pcurr,pinit,c,m,tcurr,x0curr,data,lab1);
                    if sse > sseThres
                        conest2=1;
                        disp(['At time ' num2str(tcurr(1)), ' error too large (',num2str(sse), '), aborting current trajectory']);
                    %else %a successful step in the trajectory
                    %    sse
                    end
                    
                end
                %simulate and store results
                [tt,xx,yy,ff] = simulate_toy(tcurr,x0curr,pest,c,m);
                %if j>2, plot(tt,xx); draw now; hold on, end
                pcurr = pest;
                x0curr = xx(end,:);
                result.p(:,j-1) = pcurr;
                result.x(:,j-1) = xx(end,:);
                result.y(:,j-1) = yy(end,:);
                result.f(:,j-1) = ff(end,:);
                result.resid(:,j-1) = resid;
                result.sse(j-1) = sse;
                if plt %plot ADAPT simulation and spline interpolant for current time window
                    %red triangle: data, black x: spline, blue o: ADAPT,
                    %red .: sum of squared errors
                      subplot(321), plot(tcurr(end),yy(1),'ob', tcurr(end),data.S1,'xk'), hold on
                      subplot(322), plot(tcurr(end),yy(2),'ob', tcurr(end),data.S2,'xk'), hold on
                      subplot(323), plot(tcurr(end),yy(3),'ob', tcurr(end),data.S3,'xk'), hold on
                      subplot(324), plot(tcurr(end),yy(4),'ob', tcurr(end),data.S4,'xk'), hold on
                      subplot(325), plot(tcurr(end),sse,'.r'), hold on, drawnow
                end
            end

        end %for loop moving through time vector
        
        if conest2==0 %fitting of trajectory successful
        
            disp('optimization finished');
            disp('parameter set is acceptable');
            save([fullpath,'paths_',num2str(ntimesteps),'pt_lab1_',num2str(lab1),'_','sseThres_',num2str(sseThres),'_',num2str(i),'.mat'],'result','m','lab');
            i = i + 1;
            
        end
        disp('--------------------------------------');

        
    catch exception
        
        disp('error, trying another initial parameter set')
        disp('--------------------------------------');
        
    end     %of try loop
    
end     %while loop

%testing of functions
%dxdt = ode_toy(tcurr(1),x0curr,pcurr,c)
%[t,x,y,flux] = simulate_toy(tcurr,x0curr,pcurr,c,m);
%f = obj_toy(pcurr,pcurr,pinit,c,m,tcurr,x0curr,data,lab1)

%load('paths_50pt_lab1_0.01_1.mat')
%plotResults

