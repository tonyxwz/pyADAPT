%initVars_toy
%
%   [c,d,m,lab] = initVars_toy
%
% c: struct with parameter indices and constants
% d: struct with experimental data and standard deviation
% m: struct with settings / options for simulation and optimization
% lab: struct containing string labels for states, parameters and fluxes
%
% loads data_toy.mat
% Note: fieldnames(d) Field names of a structure

function [c,d,m,lab] = initVars_toy


% string labels for states, parameters and fluxes
lab.state           = {'S_1','S_2','S_3','S_4'};
lab.state_unity_abs = {'[\mu mol/L]'};
lab.par             = {'k_1','k_2','k_3','k_4','k_5'};
%lab.flux            = {'v1','v2','v3','v4','v5'};
lab.flux            = {'f_1','f_2','f_3','f_4','f_5'};

% constants
%T = 310;   %[K]
%known kinetic parameters
c.c.k2 = 1;
c.c.k3 = 0.1;
c.c.k4 = 0.5;
c.c.k5 = 1;


% obtain data
%d. = getData_toy
load('data_toy.mat')
d.S1 = concdata(:,1);
d.S1_std = stddata(:,1);
d.S2 = concdata(:,2);
d.S2_std = stddata(:,2);
d.S3 = concdata(:,3);
d.S3_std = stddata(:,3);
d.S4 = concdata(:,4);
d.S4_std = stddata(:,4);


% state indices
c.s.S1 = 1;
c.s.S2 = 2;
c.s.S3 = 3;
c.s.S4 = 4;


% model constants / variables
m.parameters           = 1;                      % number of parameters in the PTA
m.states               = 4;                      % number of states
m.fluxes               = 5;                      % number of fluxes
m.lb                   = zeros(m.parameters,1);  % lower bounds parameters
m.ub                   = [];                     % upper bounds parameters
m.ode_tolerances       = [1e-12 1e-12 100];      % tolerances for ODE solver
%m.min_options          = optimset('MaxIter',1e3,'Display','off','MaxFunEvals',1e5,'TolX',1e-8,'TolFun',1e-8);              % options for lsqnonlin minimizer
m.min_options          = optimset('Display','off');


% parameter indices
c.p.k1 = 1;
%c.p.k2 = 2;
%c.p.k3 = 3;
%c.p.k4 = 4;
%c.p.k5 = 5;
