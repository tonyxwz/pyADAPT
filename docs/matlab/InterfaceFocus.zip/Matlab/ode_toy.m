%ode_toy
%
%   dxdt = ode_toy(t,x,p,c)
%
%input
% t: time 
% x: vector of state variables
% p: struct with parameters
% c: struct with parameter indices and general constants

%the structure required by the parser:
% mStruct.s.x1 = 1;
% mStruct.s.x2 = 2;
% mStruct.s.x3 = 3;
% mStruct.s.x4 = 4;
% 
% mStruct.p.k1 = 1;
% mStruct.p.k2 = 2;
% mStruct.p.k3 = 3;
% mStruct.p.k4 = 4;
% mStruct.p.k5 = 5;

function dxdt = ode_toy(t,x, p,c)

% parameters
k1 = p(c.p.k1);
%k2 = p(c.p.k2);
%k3 = p(c.p.k3);
%k4 = p(c.p.k4);
%k5 = p(c.p.k5);
k2 = c.c.k2;
k3 = c.c.k3;
k4 = c.c.k4;
k5 = c.c.k5;

% state variables
S1 = x(c.s.S1);
S2 = x(c.s.S2);
S3 = x(c.s.S3);
S4 = x(c.s.S4);

%input fluxes
u1 = 1;
u2 = u1;

% fluxes
v1 = k1*u1*x(2,:);
v2 = k2*u2*x(3,:);
v3 = k3*x(1,:);
v4 = k4*x(1,:);
v5 = k5*x(4,:);
v = [v1; v2; v3; v4; v5];

%Stoichiometry matrix
N = [ 1  0 -1 -1  0;
     -1  1  0  0  0;
      1 -1  0  0  0;
      0  0  0  1 -1];

% differential equations
%for state variables x = [S1 S2 S3 S4]

% dx = zeros(model.states,1);
dxdt = zeros(length(x),1);

dxdt(1:4) = N*v;

%dx = dx(:);
