% InterfaceFocus2 Generate plots for Interface Focus paper. The results
% should be available in a struct result, containing the fields
%  't': time vector
%  'p': matrix of the parameter trajectories
%  'x': 
%  'y':
%  'f': matrix containing the fluxes (different rows) as function of time
%  (columns)
%  'resid': matrix
%  'sse': vector with Sum of Squared Errors per time point
%  'splData': struct with interpolated data
%  'lab1': Lagrange multiplier, weighting regularization of parameter changes vs datafit
%
% Struct lab contains string labels for states, parameters and fluxes.

%close all; clear all

[c,d,m,lab] = initVars_toy;

%A single trajectory:
%load('paths_50pt_lab1_1_1.mat')

%A collection of trajectories:
load('results_tot.mat')
%load('results_tot_lab1_1.mat')
%load('results_tot_lab1_0.01.mat')

%resultNames = fieldnames(result);

%% figure 3
%figure(3)
%Plot the data
%plot_data

%% figure 4
%See InterfaceFocus1.m

%% figure 5
if 0
figure(5)
load snapshot.mat
pNames = fieldnames(c.p); 
for k=1:5
    subplot(3,5,k); bar(pEst(k,:), 'k')
    %assen=axis; axis([0 size(pEst,2) assen(3:4)])
    axis([0 size(pEst,2) 0 10])
    set(gca, 'FontSize',14, 'FontName','Times New Roman')
    title(['parameter ', pNames{1}, ', stage ', num2str(k)])
    %title(['parameter ', lab.par(1), ', stage ', num2str(k)])
   
    subplot(3,5,k+5); hist(pEst(k,:))
    h = findobj(gca,'Type','patch');
    set(h,'FaceColor','k')
    set(gca, 'FontSize',14, 'FontName','Times New Roman')
    set(gca, 'YTick', [])
    axis([0 ceil( max(max(pEst)) ) 0 30])
    set(gca, 'XTick', [0:2:10], 'XTickLabel', [0:2:10])
    title([num2str(k)])
    %mean(pEst(k,:))
    %std(pEst(k,:))
end
end
%% figure 6
%See estimate_toy
%figure(6)
%load snapshot.mat

%break
%% figure 7 Data interpolants
figure(7)
plot_data
tt = 0:0.1:4;   %time vector in days
for i = 1 : 20 %no of smooting splines generated
    splData = getDataSplines_toy(d);
    for j = 1 : 4
        subplot(2,2,j); hold on; box on;
        plot(tt,ppval(splData{j},tt), 'Color',[0.7,0.7,0.7], 'LineWidth',2);
        %set(gca, 'FontSize',14, 'FontName','Times New Roman')
        assen=axis; axis([-1 5 assen(3:4)])
    end
end
subplot(2,2,3); xlabel('Time (days)')
subplot(2,2,4); xlabel('Time (days)')

if 1
%Or using 2D histogram
figure
tt = 0:0.1:4;   %time vector in days
for j = 1 : 4
    for i = 1 : 100 %no of smooting splines generated
        splData = getDataSplines_toy(d);    % struct of a cubic smoothing spline in ppform
        interpolant(i,:) = ppval(splData{j},tt);
    end
    subplot(2,2,j);
    %plot(tt,interpolant);
    [Na,Ca] = getHist2(tt,interpolant,[],20); 
    %imagesc(Ca{1}/24,Ca{2},(Na.')); %Scale data and display as image.
    imagesc(Ca{1},Ca{2},(Na.')); %Scale data and display as image
    hold on
    cmap = flipud(hot(255));
    %cmap = flipud(gray(255));
    colormap(cmap);
    set(gca,'YDir','normal');
    %set(gca, 'layer', 'top');
    assen=axis; axis([-1 5 0 assen(4)])
    
    %20 samples
    plot(tt,interpolant([1:20],:), 'Color',[0.7,0.7,0.7], 'LineWidth',1.5);
    
    %the data
    plot([0:4],concdata(:,j),'.k')
    plotErrorBar([0:4],0.1,concdata(:,j),stddata(:,j),'k',1.5);

    set(gca, 'FontSize',14, 'FontName','Times New Roman')
    set(gca, 'XTick', [0:4], 'XTickLabel', {'1', '2', '3', '4', '5'}, 'FontSize',14)
    title(lab.state(j))

end  
subplot(2,2,3); xlabel('Time (days)')
subplot(2,2,4); xlabel('Time (days)')
%plot_data
end

%break
%% figure 8
%plot parameter trajectory and fluxes

%figure(8)
figure
%parameter trajectory
for loopindex = 1 : m.parameters 
    subplot(2,3,loopindex)
    
    [Na,Ca] = getHist2(t,p{loopindex,1},[],20); 
    %imagesc(Ca{1}/24,Ca{2},(Na.')); %Scale data and display as image.
    imagesc(Ca{1},Ca{2},(Na.')); %Scale data and display as image
    hold on
    cmap = flipud(hot(255));
    %cmap = flipud(gray(255));
    colormap(cmap);
    set(gca,'YDir','normal');

    %plot(result.t, result.p(loopindex,:) ); hold on
    %plot(t, p{loopindex,1}, 'k', 'LineWidth',1.5); hold on
    plot(t, p{loopindex,1}([100:120],:), 'k', 'LineWidth',1); hold on 
    set(gca, 'FontSize',14, 'FontName', 'Times New Roman')
    set(gca, 'XTick', [0:4], 'XTickLabel', {'1','2','3','4','5'})
    title(lab.par(loopindex))
    assen=axis; axis([assen(1) 3.9 0 assen(4)])
end

%fluxes
%and the true fluxes for comparison
load data_toy.mat
for loopindex = 1 : m.fluxes 
    subplot(2,3,loopindex+1)
    
    [Na,Ca] = getHist2(t,f{loopindex,1},[],20); 
    %imagesc(Ca{1}/24,Ca{2},(Na.')); %Scale data and display as image.
    imagesc(Ca{1},Ca{2},(Na.')); %Scale data and display as image
    hold on
    cmap = flipud(hot(255));
    %cmap = flipud(gray(255));
    colormap(cmap);
    set(gca,'YDir','normal');
    
    %plot(result.t, result.f(loopindex,:) ); hold on
    %plot(t, f{loopindex,1}, 'Color',[0.5,0.5,0.5], 'LineWidth',1.5); hold on
    plot(t, f{loopindex,1}([100:120],:), 'Color',[0.5,0.5,0.5], 'LineWidth',1); hold on
    if loopindex > 1
        plot([0:4],.9*fluxes(:,loopindex),'*k')  %the true fluxes at the 5 stages
    end
    set(gca, 'FontSize',14, 'FontName', 'Times New Roman')
    set(gca, 'XTick', [0:4], 'XTickLabel', {'1','2','3','4','5'})
    title(lab.flux(loopindex))
    assen=axis; axis([assen(1) 3.9 0 assen(4)])
end


%%
%plot state variables
figure
%include the data
plot_data
for loopindex = 1 : m.states 
    subplot(2,2,loopindex)
    %plot(result.t, result.x(loopindex,:), 'r', 'LineWidth',2); hold on
    h2=plot(t, x{loopindex,1}, 'r', 'LineWidth',1); hold on
    title(lab.state(loopindex))
end
%set(gca,'Children',[h2 h1]); %pull the first line to the front:
