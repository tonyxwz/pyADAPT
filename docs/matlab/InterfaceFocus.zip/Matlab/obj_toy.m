% obj_toy Objective function (cost function) to optimize parameters.
% Multi-objective optimization: 1) fit to data (SSE), 2) regularization
% with penalty on parameter changes.
%
%   f = obj_toy(p,pprev,p0,c,m,t,x0,data,lab1)
%
%input:
% p:    vector with current values for the parameters included in PTA
% pprev: vector with previous parameter values
% p0:   
% c:    struct with parameter indices and constants
% m:    struct with settings / options for simulation and optimization
% t:    vector with simulation times of which the last value corresponds to an experimental time
% x0:   vector with initial conditions for model simulation
% data: struct with experimental data (mean and stdev) for the current time
%       interval
% lab1: Lagrange multiplier, weighting regularization of parameter changes vs datafit
%output:
% f: vector of residuals and regularization

function f = obj_toy(p,pprev,p0,c,m,t,x0,data,lab1)

if t(end) == 0  %the first simulation interval
    pprev = p;
    p0 = p;
end

[t,x,y,flux] = simulate_toy(t,x0,p(1:m.parameters),c,m);

%vector of residuals
e = [ ( y(1) - data.S1 ) / data.S1_std;
      ( y(2) - data.S2 ) / data.S2_std;
      ( y(3) - data.S3 ) / data.S3_std;
      ( y(4) - data.S4 ) / data.S4_std];
% e = [ ( y(1) - data.S1 );
%       ( y(2) - data.S2 );
%       ( y(3) - data.S3 );
%       ( y(4) - data.S4 )];

%regularization
if t(end) == 0
    reg = zeros(m.parameters+1-1,1);
else
    p_diff = ( ((p-pprev) ./ p0) / (t(end)-t(1)) );
    p_diff = p_diff(1:m.parameters);
    %a = ( (( p(7) + p(10) - pprev(7) - pprev(10)) ./ (p0(7) + p0(10))) / (t(end)-t(1)) );
    %p_diff(end+1) = a;
    reg = lab1 * p_diff;
end

f = [e; reg];
