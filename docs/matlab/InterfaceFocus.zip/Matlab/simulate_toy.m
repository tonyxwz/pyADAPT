%simulate_toy Simulate the model, either with Matlab solver (ode15s) or
%with CVode suite (compiled mex file)
%
%   [t,x,y,flux] = simulate_toy(t0,x0,p,c,m)
%
%input
% t0: simulation time vector
% x0: initial conditions for [S1 S2 S3 S4]
% p : parameter vector
% c: struct with parameter indices and general constants
% m: struct with settings / options for simulation and optimization
%    m.ode_tolerances
%output
% t: time vector (column) 
% x: time course of state variables (matrix with different time samples
% in the different rows and the different state variables in the columns) 
% y: steady-state outputs (row vector) 
% flux: matrix with time course of the fluxes in the columns

function [t,x,y,flux] = simulate_toy(t0,x0,p,c,m)

[t,x] = ode15s(@ode_toy,t0,x0,[], p,c);
%x = [S1 S2 S3 S4]
flux = fluxes_toy(x,p,c);

y = x(end,:);
