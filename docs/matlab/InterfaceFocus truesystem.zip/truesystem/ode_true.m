%ode_true ODE model of the true system.
%
%   dxdt = ode_true(t,x,p)
%
%p: parameter k6
%
%Calls fluxes_true.m

function dxdt = ode_true(t,x,p)

%fluxes based on kinetics
v = fluxes_true(t,x);

%parameters gene/protein expression
k6 = p;     %k6 = 1e-2;
kd = 0.01;  %degration rate

%Stoichiometry matrix
N = [ 1  0 -1 -1  0;
     -1  1  0  0  0;
      1 -1  0  0  0;
      0  0  0  1 -1];
  
%ODE model
%state variables
%x = [S1 S2 S3 S4 R1];
dxdt = zeros(length(x),1);

dxdt(1:4) = N*v;

%Catabolite repression 
dxdt(5) = k6*x(4)-kd*x(5);  %transcription / translation
