function v = fluxes_true(t,x)
%fluxes_true Rate equations.
%with a 1 sec pulse in u1 at t=5 sec.
%
%   v = fluxes_true(t,x)
%
% t: time for which the fluxes are calculated
% x: a COLUMN vector with the concentrations of the 5 species 
%   OR a matrix in which the COLUMNS contain the concentrations at subsequent
%   times

%input fluxes
u1 = 1;
u2 = u1;
if t>5 & t<6
    u1 = 2;
end
%parameters
k1 = 1;
Km = 0.1;
k2 = 1;
k3 = 0.1;
k4 = 0.5;
k5 = 1;

%internal fluxes (rates) 
v1 = k1*u1*x(2,:)./(Km+x(5,:));
v2 = k2*u2*x(3,:);
v3 = k3*x(1,:);
v4 = k4*x(1,:);
v5 = k5*x(4,:);
v = [v1; v2; v3; v4; v5];
