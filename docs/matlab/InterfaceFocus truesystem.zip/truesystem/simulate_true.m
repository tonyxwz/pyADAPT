%simulate_true Simulate true system for 5 stages and generate mock data.
%calls: true_system.png, ode_true.m, which calls fluxes_true.m
close all; clear all

ima = imread('true_system.png','png');
h=figure; image(ima); axis off
%position rectangle with a four-element vector of the form 
%rect = [left, bottom, width, height]
set(h,'Position',[10 450 450 250]);

%parameters
%p = [];

%state variables
%x = [S1 S2 S3 S4 R1];
x0 = [.5 .5 .5 .5 .5];

tspan = [-1e3 0];

%change parameter for gene/protein expression
%k6range = 1e-2 
k6range = logspace(-2, -3.5, 5);  %nvr 14-dec-12
k60 = k6range(1);

for i = 1:length(k6range)
    p = k6range(i);
    %[t,x] = ode45(@ode_true,tspan,x0);
    [t,x] = ode15s(@ode_true,tspan,x0,[],p);
    ydata(i,:) = x(end,:);  %the different rows in ydata represent the subsequent stages
    v(i,:) = fluxes_true(0,ydata(i,:)');
end
%fluxes
%v = fluxes_true(0,ydata');
figure; plot([1:5],v, '-*')
legend('v1', 'v2', 'v3', 'v4', 'v5')
title('fluxes')

rand('state',1);
randn('state',1);
%generate standard deviation of data from a uniform distribution between 0
%and 10% of the value of the output for the wild-type (day 0) situation
stddata = .2*diag(ydata(1,:))*rand(size(ydata));
%add noise to simulated data with zero mean Normal distribution with stdev
%as
ydataNoisy = ydata + stddata.*randn(size(ydata));   

concdata = ydataNoisy(:,1:4);
proteindata = abs( ydataNoisy(:,5) );
fluxes = v;

figure; bar(concdata','b');
set(gca, 'XTickLabel', {'S1', 'S2', 'S3', 'S4'}, 'FontSize',14)
figure; bar(proteindata','b');
set(gca, 'XTickLabel', [0:4], 'FontSize',14)
title('R1')

%save data_toy.mat concdata stddata fluxes

%Simulate a short-term kinetic response
set(0,'DefaultAxesColorOrder',[0 0 0],...
      'DefaultAxesLineStyleOrder','-|-.|--|:')
for i = 1:length(k6range)
    p = k6range(i);%p = k6range(5);
    tspan1 = [-1e3 5];
    [t1,x1] = ode15s(@ode_true,tspan1,x0,[],p);
    tspan2 = [5 15];
    [t2,x2] = ode15s(@ode_true,tspan2,x1(end,:),[],p);
    y = [x1(:,1:4); x2([2:end],1:4)];
    figure; plot([t1; t2(2:end)],y, 'LineWidth',4)
    assen=axis; axis([0, t2(end), assen(3:4)])
    set(gca, 'LineWidth',2, 'FontSize',18, 'FontName','Times New Roman')
    xlabel('Time (sec)')
    legend('S1', 'S2', 'S3', 'S4')
    %legend('S1', 'S2', 'S3', 'S4', 'R1')
    title(['k_6 = ',num2str(p)])
end

if 0    %plot results of 1 simulation
%concentrations
figure; subplot(211); plot(t,x)
legend('S1', 'S2', 'S3', 'S4', 'R1')

%mock data
data = x(end,1:4);
figure; bar(data);
set(gca, 'XTickLabel', {'S1', 'S2', 'S3', 'S4', 'R1'}, 'FontSize',14)
end
